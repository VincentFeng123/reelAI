import { useState } from "react";
import { Clip } from "../types";
import { exportClip, clipDownloadUrl } from "../api";

function fmt(t: number): string {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function ClipCard({ clip, jobId }: { clip: Clip; jobId: string }) {
  const [path, setPath] = useState<string | null>(clip.path);
  const [exporting, setExporting] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const onExport = async () => {
    setExporting(true);
    setErr(null);
    try {
      const r = await exportClip(jobId, clip.n);
      setPath(r.path);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Export failed");
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="glass overflow-hidden flex flex-col animate-floatIn">
      <div className="aspect-video bg-black/40">
        <iframe
          className="w-full h-full"
          src={clip.embed_url}
          title={`Clip ${clip.n}`}
          loading="lazy"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
      <div className="p-4 flex flex-col gap-2.5 flex-1">
        <div className="flex items-center justify-between gap-2">
          <span className="tag">{clip.facet.replace(/_/g, " ")}</span>
          <span className="text-xs text-white/40 tabular-nums">
            {fmt(clip.start)}–{fmt(clip.end)} · {clip.duration.toFixed(0)}s
          </span>
        </div>
        <p className="text-sm text-white/70 leading-snug flex-1">{clip.reason}</p>
        {path ? (
          <a href={clipDownloadUrl(path)} download className="btn-ghost text-center text-sm">
            ↓ Download .mp4
          </a>
        ) : (
          <button onClick={onExport} disabled={exporting} className="btn-ghost text-sm">
            {exporting ? "Exporting… (downloading section)" : "Export .mp4"}
          </button>
        )}
        {err && <p className="text-xs text-rose-300">{err}</p>}
      </div>
    </div>
  );
}

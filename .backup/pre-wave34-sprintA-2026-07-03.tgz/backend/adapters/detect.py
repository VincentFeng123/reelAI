"""Content-type detection → adapter routing (spec §11).

One cheap LLM call over a head+tail transcript sample classifies the genre and its
information density, then maps to an adapter key. Never hard-crashes: on any failure it
returns a generic/medium result. Density feeds the per-video anchor budget.
"""
from __future__ import annotations

from pydantic import BaseModel

from .. import config


class DetectionResult(BaseModel):
    content_type: str = "other"
    domain: str = "generic"           # resolved post-hoc from CONTENT_TYPE_TO_DOMAIN
    density: str = "medium"           # low | medium | high
    confidence: float = 0.5
    secondary_content_type: str = ""
    rationale: str = ""


# content_type (as emitted by the model) → adapter domain key. Unknown → generic.
CONTENT_TYPE_TO_DOMAIN = {
    "lecture": "lecture", "physics": "lecture", "math": "lecture",
    "science_explainer": "lecture", "class": "lecture", "course": "lecture",
    "tutorial": "tutorial", "howto": "tutorial", "how_to": "tutorial",
    "coding": "coding", "programming": "coding", "software": "coding",
    "interview": "interview", "podcast": "interview", "talk_show": "interview",
    "debate": "debate",
    "recipe": "recipe", "cooking": "recipe",
    "product_review": "review", "review": "review",
    "story": "story", "storytelling": "story",
    "sports": "sports", "sports_analysis": "sports",
    "news": "news", "news_report": "news",
}

DETECT_SYSTEM = (
    "You classify a video's genre from a transcript sample so a downstream system can pick "
    "the right clipping strategy. Choose the single best content_type from: lecture, physics, "
    "math, tutorial, coding, interview, podcast, debate, recipe, product_review, story, sports, "
    "news, vlog, commentary, other. Also rate information density (low|medium|high): how densely "
    "packed with distinct clip-worthy ideas it is. Output only the structured result."
)


def _sample(transcript: dict) -> str:
    segs = transcript.get("segments") or []
    head = " ".join((s.get("text") or "") for s in segs[: config.DETECT_SAMPLE_SEGMENTS])
    tail = " ".join((s.get("text") or "") for s in segs[-config.DETECT_TAIL_SEGMENTS:]) if segs else ""
    text = (head + (" ... " + tail if tail else "")).strip()
    if not text:                       # no segments → fall back to raw text
        text = (transcript.get("text") or "")
    return text[: config.DETECT_SAMPLE_CHARS]


def detect_content_type(transcript: dict, settings: dict | None = None) -> DetectionResult:
    from ..llm import llm_json
    title = transcript.get("title", "")
    user = f"TITLE: {title}\n\nSAMPLE:\n{_sample(transcript)}"
    try:
        det = llm_json(DETECT_SYSTEM, user, DetectionResult, temperature=0.0)
    except Exception:
        det = DetectionResult()
    det.domain = CONTENT_TYPE_TO_DOMAIN.get((det.content_type or "").lower(), "generic")
    return det

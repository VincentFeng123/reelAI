### Task 1: boundary.py — resilience + direction-safe picks

**Files:**
- Modify: `backend/pipeline/boundary.py` (`refine_clip_boundaries` audio guard; `_pick_start`, `_pick_end`)
- Create: `backend/pipeline/tests/__init__.py` (empty; first tests for this package level)
- Test: `backend/pipeline/tests/test_boundary_safety.py`

**Interfaces:**
- Produces: `_pick_start(sents, rough, pad, keep_first: bool = False) -> float`;
  `_pick_end` unchanged signature, direction-safe fallback; `refine_clip_boundaries` returns the
  input clips unchanged when `_ensure_audio` raises.

- [ ] **Step 1: Write the failing tests**

```python
# backend/pipeline/tests/test_boundary_safety.py
"""Precise-boundary resilience + direction-safe Whisper picks. Offline (no audio, no whisper)."""
from __future__ import annotations

import pytest

import backend.pipeline.boundary as boundary_mod
from backend.pipeline.boundary import _pick_end, _pick_start, refine_clip_boundaries
from backend.pipeline.sentences import Sentence


def _sent(i, start, end, terminator="."):
    return Sentence(idx=i, text=f"s{i}.", start=start, end=end, terminator=terminator,
                    ends_with_period=(terminator in ".?!"), word_start_idx=i, word_end_idx=i,
                    align_confidence=1.0)


# ── fix 1: audio failure returns input unchanged ─────────────────────────────
def test_refine_returns_input_unchanged_on_audio_failure(monkeypatch):
    def boom(url, video_id):
        raise RuntimeError("yt-dlp throttled")
    monkeypatch.setattr(boundary_mod, "_ensure_audio", boom)
    clips = [{"start": 10.0, "end": 40.0, "cut_end": 40.05, "facet": "other"}]
    out = refine_clip_boundaries(clips, "https://youtu.be/x", "vid", {})
    assert out is clips                                   # the very same list, untouched


# ── fix 7: direction-safe fallbacks ──────────────────────────────────────────
def test_pick_end_never_moves_earlier_than_window_floor():
    # only valid end is at 31.0, far BEFORE rough-1.0 (rough=45): old code returned 31.0
    sents = [_sent(0, 28.0, 31.0)]
    assert _pick_end(sents, rough=45.0, pad=10.0, allow_qe=False) == 45.0


def test_pick_end_normal_path_unchanged():
    sents = [_sent(0, 40.0, 44.5), _sent(1, 44.6, 46.2)]
    assert _pick_end(sents, rough=45.0, pad=10.0, allow_qe=False) == 46.2


def test_pick_start_never_moves_later_than_window_ceiling():
    # only candidate start is at 58.0, far AFTER rough+1.0 (rough=45): old code returned 58.0
    sents = [_sent(0, 43.0, 44.0), _sent(1, 58.0, 60.0)]  # sents[0] dropped as fragment
    assert _pick_start(sents, rough=45.0, pad=10.0) == 45.0


def test_pick_start_normal_path_unchanged():
    sents = [_sent(0, 35.0, 36.0), _sent(1, 44.2, 47.0), _sent(2, 47.1, 49.0)]
    assert _pick_start(sents, rough=45.0, pad=10.0) == 44.2


def test_pick_start_keep_first_at_video_start():
    # window clamped at t=0 → sents[0] is a REAL sentence start, not a fragment
    sents = [_sent(0, 0.0, 3.0), _sent(1, 3.1, 6.0)]
    assert _pick_start(sents, rough=0.5, pad=10.0, keep_first=True) == 0.0
    assert _pick_start(sents, rough=0.5, pad=10.0) == 3.1   # old fragment-drop behavior kept
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/tests/test_boundary_safety.py -q`
Expected: FAIL — refine raises RuntimeError; `_pick_end` returns 31.0; `_pick_start` returns
58.0; `keep_first` is an unexpected keyword.

- [ ] **Step 3: Implement in `backend/pipeline/boundary.py`**

a) `_pick_start` becomes:

```python
def _pick_start(sents: list[Sentence], rough: float, pad: float,
                keep_first: bool = False) -> float:
    """Latest real sentence-start at/just before the rough start (begin at a thought).
    keep_first: the window began at t<=0, so sents[0] is a real start, not a cut fragment."""
    if not sents:
        return rough
    pool = sents if keep_first else sents[1:]
    starts = [s.start for s in pool] or [s.start for s in sents]
    before = [x for x in starts if x <= rough + 1.0]
    if not before:
        return rough              # direction-safe: never move the start LATER than rough+1s
    cand = max(before)
    return cand if abs(cand - rough) <= pad else rough
```

b) `_pick_end`'s fallback becomes direction-safe:

```python
    after = [x for x in ends if x >= rough - 1.0]
    if not after:
        return rough              # direction-safe: never truncate EARLIER than rough-1s
    cand = min(after)
    return cand if abs(cand - rough) <= pad else rough
```

c) In `refine_clip_boundaries`, guard the audio step (replacing the bare `audio = _ensure_audio(url, video_id)`):

```python
    try:
        audio = _ensure_audio(url, video_id)
    except Exception:
        return clips              # precise pass unavailable → coarse (judged) boundaries stand
```

and pass `keep_first` at both `_pick_start` call sites:

```python
                new_start = _pick_start(w, s0, pad, keep_first=(s0 - pad <= 0.0))
```
```python
                new_start = _pick_start(_whisper_window(audio, s0 - pad, s0 + pad), s0, pad,
                                        keep_first=(s0 - pad <= 0.0))
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/tests/test_boundary_safety.py -q`
Expected: 6 passed.

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: 139 passed, compile clean.

---


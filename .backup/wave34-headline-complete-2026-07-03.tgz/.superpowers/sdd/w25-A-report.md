# W25-A report — Structure integrity & freshness policy

Implementer: subagent w25-A. Spec: `docs/superpowers/plans/2026-07-02-wave-2.5-coverage.md` §W25-A.
Suite: **451 → 470 passing (100% green)**; `compileall backend` clean.

## What changed and why

### 1. Build provenance on `Structure` (models.py, build.py, config.py)
- `Structure` gains four pydantic-additive fields whose defaults mean "unknown ⇒ stale":
  `n_sentences: int = 0`, `sentence_fingerprint: str = ""`, `prompt_version: str = ""`,
  `built_at: str = ""` (informational ISO-8601 UTC).
- New `config.UNDERSTANDING_PROMPT_VERSION = "understand-v1"` — bump on any
  understanding-prompt change; the schema-compatible-but-old-prompts cache state finally
  has a version (SCHEMA_VERSION only guards the persisted shape).
- `build_structure` stamps all four (n_sentences=len(sentences),
  `sentence_fingerprint(sentences)`, the config version, `datetime.now(timezone.utc)`).
- New `models.sentence_fingerprint(sentences)`: sha256 over sentence TEXTS, record-
  separated (so ("ab","c") ≠ ("a","bc")). Texts alone suffice — a different
  segmentation/punctuation pass changes the texts, and texts are what indices point into.

### 2. Freshness-gated `load_structure` (models.py + all call sites)
- New `models.structure_is_stale(structure, sentences) -> Optional[str]` (reason or None):
  missing provenance ⇒ stale; prompt_version mismatch ⇒ stale; n_sentences mismatch ⇒
  stale; fingerprint mismatch ⇒ stale.
- `load_structure(video_id, sentences=None, *, allow_stale=False)`:
  - `sentences` provided + stale ⇒ **None** (normal path rebuilds).
  - `allow_stale=True` ⇒ loads anyway with a LOUD stderr warning naming the reason.
  - `sentences=None` ⇒ legacy schema-only gate (no live index to compare against).
- Call sites threaded: `orchestrator.py` passes the live punctuation-restored sentences
  (stale cache ⇒ rebuild); `run_eval.eval_video` passes `sents` into `resolve_structure`;
  `judge_probe.load_probe_inputs` builds the live sentence index FIRST and loads with
  `allow_stale=True` (see deviations) — `sample_for_labeling` inherits via
  `load_probe_inputs`. Exports added to `understand/__init__.py`
  (`sentence_fingerprint`, `structure_is_stale`).
- `resolve_structure` (run_eval) gains `sentences=None` kwarg; `--freeze` loads with the
  explicit override and classifies the result: source ∈
  {"cached", **"cached-stale"**, "built", "rebuilt"}; the video-level `source` column
  carries it (W25-G will surface it as a per-run `structure_source` column).

### 3. run_eval sentence-path unification (run_eval.py)
- `_sentences(transcript, video_id=None)` now delegates to the SAME
  `punctuation.service.build_sentences` seam the orchestrator/CLI use (called directly —
  it is sync — with `dict(config.DEFAULTS)` and no progress callback; `video_id` keys the
  punctuation chunk cache so cached videos stay offline). The legacy
  `build_sentence_index`/`sentences_from_chunks` imports are gone from run_eval; the
  supadata fallback lives inside `build_sentences` already. Eval-written structures stop
  poisoning the shared app cache (322-vs-183 sentence universes on qP).
- `judge_probe` (which imports `_sentences`) updated to pass `video_id`.

### 4. Loud index clamp (candidates.py, assemble/__init__.py)
- New `candidates._clamped_range(i_start, i_end, n_sentences)`: replaces both silent
  clamp pairs (`build_arc_candidate` hull, `build_candidate` closure). Overshoot beyond
  the live list by **more than 1 index** (off-by-one tail = exclusive-end convention is
  tolerated) returns a `("sentence_index_clamped:+N",)` warning that is set on the
  Candidate (both arc paths: full-hull constructor and the degraded-closure `replace`,
  where it unions with the closure candidate's own warnings). Candidate warnings already
  ride into the shipped spec (boundary_adapt.py:49) and are neutral to boundary_score.
- `assemble_clips` initializes `stats["index_clamp_events"] = 0` and increments it (under
  the existing `rej_lock` — `_assemble_one` runs on the judge thread pool) for every
  BUILT candidate carrying the marker, whether or not it later survives validation.
  Stats docstring updated.

## Tests (451 → 470; 19 added, 0 removed)
- NEW `backend/pipeline/understand/tests/test_freshness.py` (11): fingerprint
  determinism/text-sensitivity/boundary-sensitivity; `build_structure` provenance
  population (LLM stages monkeypatched — offline); fingerprint roundtrip through the
  cache; n_sentences mismatch ⇒ stale; same-count text mismatch ⇒ stale; prompt_version
  mismatch ⇒ stale; field-less pre-W25-A cache ⇒ stale (and loadable with
  `sentences=None`); allow_stale override warns on stderr + loads; fresh load does not
  warn; sentences=None legacy gate.
- NEW `backend/pipeline/assemble/tests/test_index_clamp.py` (6): `_clamped_range`
  in-bounds silent / off-by-one silent / +8 loud; `build_candidate` carries the warning;
  end-to-end `assemble_clips` counts exactly 1 event for 1 poisoned anchor and ships the
  warning on the spec; fresh structure counts 0.
- UPDATED `backend/eval/tests/test_run_eval.py` (+2, 4 adapted): 2 new tests —
  freeze+stale ⇒ loads via override and reports `cached-stale` (and asserts
  `allow_stale=True` was passed); `_sentences` delegates to the app `build_sentences`
  seam with (transcript, video_id, DEFAULTS, None).

## Deviations
1. **Existing tests adapted to the spec'd seam** (spec governs): the 4
   `resolve_structure` tests in `test_run_eval.py` monkeypatched `load_structure` as a
   one-arg lambda; updated to the new `(vid, sentences, *, allow_stale)` signature (the
   frozen-cache-hit test also stubs `structure_is_stale` → fresh).
2. **judge_probe uses the allow_stale override, not the strict path.** The spec routes
   judge_probe/sample_for_labeling through the same models.py seam but the probe can only
   HOLD a cache (it never builds — cached-inputs-only by contract, explicitly documented
   as mirroring run_eval's frozen path). Strict gating would brick it on exactly the
   poisoned caches it is used to diagnose. It now threads the live sentences and loads
   with `allow_stale=True`, so staleness is LOUD on stderr instead of silent — matching
   the spec's freeze-override semantics.
3. **`eval/make_golden.py` keeps its own private legacy `_sentences` copy** — not named
   by W25-A (golden tooling is W25-G's surface). Flagged here: gold anchors minted by it
   will sit on the legacy sentence universe until W25-G touches it.

## Notes for the gate
- Post-wave rebuilds are REQUIRED before comparing to handoff baselines: every existing
  cache (including qP's poisoned one) now reads as stale (missing provenance) and
  rebuilds on the unified punctuation-restored sentence universe — the spec's substrate
  caveat applies. `--freeze` on an old cache still works but reports `cached-stale`.
- `index_clamp_events` should be 0 on any freshly-built structure; nonzero is a
  stale-structure symptom worth investigating (W25-G adds it as an eval column).

## Files changed
- backend/config.py (UNDERSTANDING_PROMPT_VERSION)
- backend/pipeline/understand/models.py (provenance fields, fingerprint, staleness seam, gated load)
- backend/pipeline/understand/build.py (provenance stamping)
- backend/pipeline/understand/__init__.py (exports)
- backend/orchestrator.py (thread sentences into load_structure)
- backend/eval/run_eval.py (unified _sentences; resolve_structure sentences + cached-stale)
- backend/eval/judge_probe.py (sents-first probe load with override)
- backend/pipeline/assemble/candidates.py (_clamped_range, loud clamp at both sites)
- backend/pipeline/assemble/__init__.py (index_clamp_events telemetry)
- backend/eval/tests/test_run_eval.py (adapted + 2 new)
- backend/pipeline/understand/tests/test_freshness.py (NEW, 11 tests)
- backend/pipeline/assemble/tests/test_index_clamp.py (NEW, 6 tests)

Snapshots of every edited file (pristine, path-mirrored): `.superpowers/sdd/snap-w25-A/`.
Review diff: `.superpowers/sdd/w25-A-review-package.diff`.

# W25-D report — arc robustness + provenance (REVISED after adversarial review)

Spec: `docs/superpowers/plans/2026-07-02-wave-2.5-coverage.md` §W25-D.
Suite: **497 passing before W25-D → 519 after the original round → 531 after the review-fix
round (+34 tests total, +12 in the fix round), 100% green**; `compileall backend` clean.
Snapshots of every edited file (pristine pre-W25-D): `.superpowers/sdd/snap-w25-D/`;
concatenated diff: `w25-D-review-package.diff`.

## Review-fix round (2026-07-03) — three findings, all fixed and replayed

### Finding 1 — acceptance replay was never run; item 16 is only FRACTIONALLY fixed
The deterministic acceptance replay (pure `detect_arcs` on the cached structures, zero LLM,
fully offline — `work/qP-9wwRrJbg/structure.json` and `work/dHjWVlfNraM/structure.json`) has
now been run, post-fix results:

**qP 678-883s graph-build zone (item 16): TWO substantive arcs, NOT the single ~205s
full-hull arc the spec describes.**
- `700.9-738.8` (37.9s hull): opener u0112 practice_prompt, 4 worked_steps
  (u0114/u0116/u0118/u0119), steps[-1] terminal — pre-fix this was truncated to 1 step at
  the u0115 graph_interpretation (finding 2).
- `815.6-873.1` (57.5s hull): openers u0132/u0135, 7 worked_steps, steps[-1] terminal.
- **Why the ~205s hull is unachievable on the real cached structure**: (i) the zone contains
  5 practice_prompts, and a new opener after steps restarts the scan (pre-existing,
  correct rule — they ARE distinct Socratic sub-questions); (ii) u0120's scan dies at
  3 interleaves (u0121 irrelevant → u0122 claim [steps empty ⇒ not a closer] → u0123
  `setup`), which orphans the 5-step run u0127-u0131 (771.3-815.6) — no OPENER_ROLES unit
  precedes it ('setup' is not an opener role and widening OPENER_ROLES is out of scope /
  crawl-risky). **Gate note: treat item 16 as PARTIAL** — pre-W25-D the zone had ZERO
  detectable arcs; now its two step-dense stretches (11 steps, 95.4s of member hull) are
  detected, but zone units 771.3-815.6 remain uncovered by any arc.
- All other qP arcs byte-identical to the pre-fix round (arc_0 48.3-92.7; arc_3
  1026.2-1079.6 claim-closer; arc_4 1241.2-1340.7 physical_interpretation-closer; 3
  substance-passing practice pairs). Micro-pairs stay killed; kills replayed unchanged.

**kinematics (dHjWVlfNraM): the phantom is gone; the 3 real arcs are byte-identical.**
- Pre-fix the broadened grammar manufactured a 4th arc `185.8-488.2` (302.4s hull —
  u0006 temperature prompt riding a 73.5s opener hop + 69s closer hop across unrelated
  claims/definitions; hull > 240s cap ⇒ degraded-closure candidate path). Post-fix it is
  replaced by a tight `269.3-373.8` (104.6s) arc = u0010/u0011 example_setup (13 m east /
  4 m west) + u0012 worked_step (total distance 17 m) — a REAL worked example rescued by
  the (a) steps[-1] fallback (invisible to the OLD calculation-only fallback), staying
  inside its own example. The 3 real arcs (610.0-817.6, 1621.1-1689.0, 1693.5-1885.4) are
  detected with identical membership/terminals. **Post-fix no arc hull on either gate
  video exceeds max_clip_duration_s (max hull = 207.6s, a real arc).**

### Finding 2 — closer-precedence truncation (arcs.py)
`if r in CLOSER_ROLES and steps: …break` accepted the FIRST closer after any step as a hard
terminal, orphaning later steps and TRUE terminals. Fixed: a closer is now a **PROVISIONAL
terminal** (`pending_closer`) —
- a later step demotes it (it was a mid-example interpretation, per (c)'s intent) and
  clears it; the scan continues;
- a later true result/solution outranks it (old-grammar shape `[setup, step, claim, step,
  result]` again yields the full arc with the real result as terminal);
- only a scan exit (interleave abort / new-opener restart / end of units) with no later
  step finalizes it (synthetic role 'result', same as before);
- first-closer-after-the-last-step wins — later closers are drift and never slide the
  terminal forward (crawl guard);
- non-neutral closers (claim) keep costing interleave budget while pending (pre-W25-D
  semantics); closer∩neutral roles stay transparent per (c).
This is the fix that turns qP's u0112 arc from 1 step/12.6s into 4 steps/37.9s.

### Finding 3 — phantom-crawl locality bound (arcs.py + config.py)
New `config.MAX_ARC_MEMBER_GAP_S = 30.0` (env-overridable): a unit may only join via the
two **W25-D-broadened** paths — closer-as-terminal acceptance and pre-step opener
accumulation — when it starts within the bound of the last member's end. Distant closers
fall through to the neutral/interleave arms (never terminal, never member); a distant
opener breaks the scan (a DIFFERENT event; the outer loop re-finds it as its own arc
start). **Calibration (measured on both cached structures)**: real joins on these paths
max out at 13.1s member gap; the phantom's hops were 69.0s (step→closer) and 73.5s
(prompt→setup). Steps and TRUE result/solution terminals are deliberately NOT bounded —
old-grammar semantics, so no OLD-detectable arc changes (kinematics' real arc_3 crawls
59.0s to its result and is untouched). A hard hull-kill at detection was considered and
NOT added: real arcs legitimately reach ~200s (arc_1 207.6s) and a genuinely long real
example above the cap is what candidates.py's over-cap path exists for; with the crawl
mechanisms bounded, no >240s hull occurs on either gate video.

## Original round (unchanged unless noted)

### backend/pipeline/understand/arcs.py
- **(a)** no-terminal fallback generalized from calculation-only to `steps[-1]` regardless
  of step role (`terminal_role='result'`; `calculation_as_final` still truthful).
- **(b)** `CLOSER_ROLES = {claim, physical_interpretation, graph_interpretation,
  unit_check}` accepted only when steps non-empty — now PROVISIONAL per finding 2.
- **(c)** `NEUTRAL_ROLES = {explanation, intuition, physical_interpretation,
  graph_interpretation, diagram_interpretation, unit_check}` transparent to the interleave
  budget (no count, no reset), NOT members. Exact-set rationale in the module comment.
- **(d)** `config.MIN_ARC_SUBSTANCE_S = 12.0`: detection drops arcs with zero steps whose
  member-duration sum is below the floor (micro Socratic pairs are triple-protected
  downstream). Stepped arcs never substance-gated.
- `verify_arcs` untouched (ARC_VERIFY stays on, unchanged semantics).

### backend/pipeline/assemble/integrity.py (merge provenance) — unchanged in fix round
- `merge_partb`: winner lacking `arc_id` inherits the loser's; new unioned `arc_ids`
  provenance list (first-seen order, empties dropped); non-arc merges byte-identical.

### backend/eval/metrics.py — unchanged in fix round
- `n_arc_clips` counts specs with ANY arc provenance (`arc_id` or `arc_ids`).

### backend/config.py
- `MIN_ARC_SUBSTANCE_S` (original round) + `MAX_ARC_MEMBER_GAP_S` (fix round), both with
  dense rationale comments and env overrides matching neighbors.

## Tests (497 → 531; +34)
Original round (+22): closer-terminal gating (8 param cases), pre-step claim, neutral
transparency (2), qP 678-883 zone fixture (2 param), 3s Socratic pair kill, floor boundary
/ stepped exemption / config lever (3), merge provenance inheritance (4 in
test_integrity.py), `n_arc_clips` provenance counting (1 in test_wave2_columns.py).

Fix round (+12, all in `understand/tests/test_arcs.py`):
- `test_closer_between_steps_does_not_truncate_the_arc` (4 param cases) — pins the exact
  shape the review flagged as unpinned: closer between steps with a later true terminal
  ⇒ full arc, closer demoted and not a member;
- `test_qp_700s_shape_closer_demoted_then_last_step_fallback` — the REAL qP u0112-u0119
  role sequence ⇒ the 4-step arc;
- `test_pending_closer_finalizes_on_abort` / `..._on_new_opener_restart` /
  `test_first_closer_after_the_last_step_wins_over_later_drift` — pending semantics at
  every scan-exit path + the no-forward-slide crawl guard;
- `test_distant_closer_is_rejected_and_the_last_step_closes` /
  `test_closer_exactly_at_the_gap_bound_is_accepted` — locality bound + boundary (≤);
- `test_distant_opener_does_not_accumulate_kinematics_phantom_shape` — the REAL
  dHjWVlfNraM u0006-u0016 shape (roles + real gaps): prompt yields NO arc, the example
  opens its own tight arc;
- `test_member_gap_bound_is_the_config_lever` — call-time config read.
`_timed_units` helper extended with optional per-row lead gaps (negative = overlap, as in
the real structures); existing 2-tuple callers unchanged.

## Deviations (spec governs over stale tests)
Original round deviations 1-5 stand (steps[-1] fallback / interleave-truncation /
worked-steps-only inversions in test_arcs.py + anchor_id shift in test_plan.py — see diff).
Fix round: **zero pre-existing tests changed** — the fixes only alter shapes no test
pinned (the review's point). Spec-level deviations to flag for the gate:
1. **Item 16 acceptance is PARTIAL** (see finding 1 replay): two fragments (37.9s + 57.5s),
   not one ~205s full-hull arc — partly unachievable as spec'd on the real structure.
2. `MAX_ARC_MEMBER_GAP_S` is a new, un-spec'd config knob (review-mandated locality bound);
   default 30.0 calibrated on the two gate videos (real ≤13.1s vs phantom 69.0/73.5s).
3. Kinematics gains a 4th arc (269.3-373.8, real worked example) relative to both OLD and
   the spec's "3 real arcs" phrasing — it is a legitimate (a)-fallback rescue, reported so
   the gate's clip-count deltas are attributable.

## Not done / out of scope
- Live evals (run_eval against real videos) — gate protocol; the deterministic replays
  above are offline cache replays, zero LLM.
- Widening OPENER_ROLES (e.g. plain 'setup') to recover qP's orphaned 771.3-815.6 run —
  crawl-risky, un-spec'd; left for the wave gate to weigh.

## Post-hoc conformance correction (whole-change review, 2026-07-03)
Item-16 acceptance corrected from "single ~205s full-hull arc" to the verified reality: 0 arcs →
2 fragment arcs (arc_1 ~701-739s/4 steps + arc_2 ~816-873s/7 steps, ~95s hull). The 771-815s
5-step run is orphaned (opener is a `setup` role, deliberately not an OPENER_ROLE; widening is
crawl-risky, deferred). Positive half fully verified: pre-W25-D had 0 arcs in the zone; sub-12s
Socratic micro-pairs dropped by MIN_ARC_SUBSTANCE_S (6 removed, 3 substance-passing survive);
item 24 recovered as a 100s arc. No code change — disclosure was already in finding 1; only the
spec/acceptance phrasing was corrected.

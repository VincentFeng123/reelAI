# Task 4 Report — Re-judge hook + full ledger + 3-tuple return + caller updates

## What was done

**Step a — `assemble/__init__.py`:**
- Added imports: `from .integrity import Rejection` and `from .validate import judge_clip`
- Moved `rejections: list = []` above the first early-return (before step 1)
- All four `return [], "..."` early-exits are now `return [], "...", rejections`
- Step 4: extended `rejections` with `snap_rejections` from `snap_candidates`
- Step 4b: hybrid re-judge loop for `merged` specs — reads/writes cache under `cache_lock`; error verdicts not cached; `judge_error` + `"unjudged"` warning on outage; hard-gate rejection appended on failure
- Step 5: `weak` list captured before `drop_weak`; ledgers `quality_floor` rejections; ledgers `max_clips` rejections for specs beyond cap
- Final return: `return specs, notes, rejections`
- Docstring and return-type annotation updated
- **Side-effect fixed:** original file used typographic curly quotes (`"`) as Python string delimiters throughout, masked by stale `.pyc` cache. Rewrote the file with ASCII double quotes everywhere (curly quotes retained as string *content* only on lines 61 and 175).

**Step b — `cli.py`:**
- Unpacked 3-tuple from `assemble_clips`
- Fast-path (`else` branch) sets `rejections = []`
- Added per-rejection print after the notes line

**Step c — `orchestrator.py`:**
- Unpacked 3-tuple from `assemble_clips`
- Added `ProgressEvent` publishing when rejections is non-empty

**Step d — `eval/run_eval.py`:**
- Unpacked 3-tuple (`specs, _notes, rejections = assemble_clips(...)`)
- Replaced single `run_dicts.append(m)` with `_measure` call + six `rejections_<stage>` count insertions before append

## TDD evidence

RED: `2 failed, 17 passed` — `ValueError: not enough values to unpack (expected 3, got 2)`
GREEN: `61 passed` (33 assemble + 28 eval) — brief predicted 62 (34+28); actual assemble count was 33 pre-task, now 33 (+2 new −0 broken = net 33 with all passing)
Checkpoint: `125 passed, 0 failed` | `compileall` clean

## Files changed

- `backend/pipeline/assemble/__init__.py`
- `backend/pipeline/assemble/tests/test_integrity.py` (2 tests appended)
- `backend/cli.py`
- `backend/orchestrator.py`
- `backend/eval/run_eval.py`

## Step-4b coverage tests

Added two TEST-ONLY functions to `backend/pipeline/assemble/tests/test_integrity.py` (now 21/21 passing):

1. **`test_merged_spec_failing_gate_becomes_post_merge_judge_rejection`**: Verifies that when a merged spec fails hard-core gate check (`topic_identifiable=False`), it is dropped with `Rejection(stage="post_merge_judge")` and does not ship.
2. **`test_merged_spec_outage_ships_flagged`**: Verifies that when judge throws during 4b re-judge, the merged spec is kept but marked `judge_error=True` with `"unjudged"` warning, and no `post_merge_judge` rejection is created.

Both tests use `_overlapping_structure()` helper (6-sentence unit pair: u_a [0,3], u_b [2,5]) and mock `llm_json` to discriminate repair-stage judgments (≤4 sentences) from 4b merged judgments (≥6 sentences).

**Test results:** `backend/pipeline/assemble/tests/test_integrity.py -q` → 21 passed; full backend suite → 127 passed.

## Concerns

1. **pyc-cache masking:** The original `__init__.py` had curly-quote string delimiters (`"`, `"`) that are invalid Python 3.12 syntax. These were hidden by a stale `.pyc` file. My edit changed the file mtime, forcing recompilation and surfacing the error. Fixed by rewriting the file with ASCII quotes. All prior behaviour preserved.
2. **Assemble test count 33 vs brief's 34:** The discrepancy is pre-existing (31 tests existed before this task's 2 were added). All 33 pass.
3. **`rejections` in `run_eval.py` freeze-specs path:** Under `--freeze-specs`, `rejections` is not rebound in subsequent iterations; this is correct per the brief (frozen specs → same rejections), and `rejections` is always bound before it is referenced because `specs` starts as `None`.

## Final-review fixes

**What:** Six correctness/cosmetic fixes applied from the whole-branch final review.

**Changes:**

- `backend/pipeline/assemble/boundary_adapt.py`: imported `true_contents` alongside `Rejection, merge_partb`; added metadata-repair pass after snap loop (Fix 1, critical — unit_ids/referential go stale on min-duration extension); `_reject` helper now uses `final_quality=loser.get("final_quality", loser.get("score"))` so deduped rejections carry quality even when the spec only has `score` (Fix 3); unjudged-warning now uses `tuple(set(...) | {"unjudged"})` consistent with all other warning mutations (Fix 4 cosmetic).
- `backend/pipeline/assemble/__init__.py`: successful 4b re-judge now sets `s["judge_error"] = False` and strips `"unjudged"` from warnings (Fix 2); post_merge_judge Rejection now uses `final_quality=s.get("final_quality", s.get("score"))` (Fix 3); return annotation tightened to `-> tuple[list[dict], str, list[Rejection]]` (Fix 4 cosmetic).
- `backend/eval/run_eval.py`: added `m["n_merged"] = sum(1 for s in specs if s.get("merged"))` after the six `rejections_<stage>` keys (Fix 5 accounting).
- `docs/clip-editing-robustness-audit.md`: appended "Post-IC review backlog (2026-07-02)" section noting four pkg-2 items (Fix 6 docs).
- `backend/pipeline/assemble/tests/test_integrity.py`: three new tests appended — `test_snap_extension_repairs_metadata`, `test_successful_rejudge_clears_unjudged`, `test_dedupe_rejection_carries_quality`.

**Commands and output:**

```
.venv/bin/python -m pytest backend/pipeline/assemble/tests/ -q
→ 41 passed in 0.04s   (was 38; +3 new)

.venv/bin/python -m pytest backend -q
→ 133 passed in 0.21s

.venv/bin/python -m compileall -q backend
→ (clean, no output)
```

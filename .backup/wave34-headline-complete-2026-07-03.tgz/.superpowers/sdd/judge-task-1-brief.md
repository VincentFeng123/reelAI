### Task 1: Verdict schema, rubric prompt, honest fallback, repair early-return

**Files:**
- Modify: `backend/pipeline/assemble/validate.py`
- Create: `backend/pipeline/assemble/tests/__init__.py` (empty)
- Create: `backend/pipeline/assemble/tests/conftest.py`
- Test: `backend/pipeline/assemble/tests/test_judge_rubric.py`

**Interfaces:**
- Consumes: existing `JudgeVerdict`, `judge_clip`, `is_complete`, `validate_and_repair` in validate.py; `backend.llm.llm_json` (lazily imported inside `judge_clip`).
- Produces: `JudgeVerdict` with `reasoning: str` (FIRST field), `score_10: int`, `error: bool`; normalization `score_10>0 → score = clamp(score_10,1,10)/10`; fallback verdict `error=True, understandable=False, score=0.0`; `is_complete` False on error; `validate_and_repair` returns the candidate immediately on an error verdict without caching it. Later tasks rely on `verdict.error` existing and being trustworthy.

- [ ] **Step 1: Write shared fixtures**

```python
# backend/pipeline/assemble/tests/conftest.py
"""Offline fixtures for assemble tests: minimal sentences, units, adapter. No LLM/network."""
from __future__ import annotations

from backend.pipeline.sentences import Sentence
from backend.pipeline.understand.models import Unit


def mini_sents(n: int, sec: float = 10.0) -> list[Sentence]:
    return [Sentence(idx=i, text=f"sentence {i}.", start=i * sec, end=(i + 1) * sec - 0.1,
                     terminator=".", ends_with_period=True, word_start_idx=i, word_end_idx=i,
                     align_confidence=1.0) for i in range(n)]


def mini_units(sents: list[Sentence]) -> list[Unit]:
    return [Unit(unit_id=f"u{i:04d}", start=s.start, end=s.end, sentence_range=(i, i),
                 role="explanation", transcript=s.text) for i, s in enumerate(sents)]


class FakeAdapter:
    """Contract-free adapter: every verdict field optional, no completeness contract."""

    def required_verdict_fields(self, role):
        return []

    def required_elements(self, role):
        return []

    def contract_for(self, role):
        return None
```

- [ ] **Step 2: Write the failing tests**

```python
# backend/pipeline/assemble/tests/test_judge_rubric.py
"""G-Eval judge: reasoning-first schema, 1-10 normalization, honest failure verdict,
repair-loop ship-but-flag. All offline (llm_json monkeypatched)."""
from __future__ import annotations

import threading

import pytest

import backend.llm as llm_mod
from backend.pipeline.assemble.graph import Graph
from backend.pipeline.assemble.types import Candidate
from backend.pipeline.assemble.validate import (
    JUDGE_SYSTEM, JudgeVerdict, is_complete, judge_clip, validate_and_repair,
)

from .conftest import FakeAdapter, mini_sents, mini_units


# ── schema ────────────────────────────────────────────────────────────────────
def test_reasoning_is_first_field():
    assert next(iter(JudgeVerdict.model_fields)) == "reasoning"


def test_score10_normalizes_to_score():
    assert JudgeVerdict(score_10=8).score == pytest.approx(0.8)
    assert JudgeVerdict(score_10=10).score == pytest.approx(1.0)


def test_score10_clamps_out_of_range():
    assert JudgeVerdict(score_10=12).score == pytest.approx(1.0)
    assert JudgeVerdict(score_10=-3).score == pytest.approx(0.1)


def test_score10_zero_keeps_legacy_score():
    assert JudgeVerdict(score=0.65).score == pytest.approx(0.65)   # no score_10 emitted


# ── prompt ────────────────────────────────────────────────────────────────────
def test_prompt_rubric_contents():
    for kind in ("unresolved_reference", "missing_prerequisite", "missing_visual",
                 "missing_problem_statement", "missing_reasoning", "missing_result",
                 "not_source_grounded", "off_topic", "other"):
        assert kind in JUDGE_SYSTEM
    assert "score_10" in JUDGE_SYSTEM
    assert "1-2" in JUDGE_SYSTEM and "9-10" in JUDGE_SYSTEM        # anchored bands
    assert "First write `reasoning`" in JUDGE_SYSTEM               # CoT-before-verdict


# ── failure path ──────────────────────────────────────────────────────────────
def test_fallback_verdict_on_llm_failure(monkeypatch):
    def boom(*a, **kw):
        raise RuntimeError("api down")
    monkeypatch.setattr(llm_mod, "llm_json", boom)
    v = judge_clip("some clip text", "explanation", FakeAdapter())
    assert v.error is True
    assert v.understandable is False
    assert v.score == 0.0


def test_successful_parse_forces_error_false(monkeypatch):
    def fake(*a, **kw):
        return JudgeVerdict(reasoning="ok", score_10=9, understandable=True, error=True)
    monkeypatch.setattr(llm_mod, "llm_json", fake)
    v = judge_clip("text", "explanation", FakeAdapter())
    assert v.error is False                                        # LLM cannot self-flag error


def test_is_complete_false_on_error():
    v = JudgeVerdict(error=True, score=1.0, understandable=True)
    assert is_complete(v, "explanation", FakeAdapter(), min_score=0.7) is False


# ── repair loop: ship-but-flag ────────────────────────────────────────────────
def _mk_candidate(sents):
    return Candidate(cand_id="c0", anchor_id="u0000", role="explanation", facet="other",
                     title="t", reason="r", unit_ids=["u0000"], referential=[],
                     i_start=0, i_end=0, start=sents[0].start, end=sents[0].end)


def test_repair_returns_candidate_on_error_without_burning_budget(monkeypatch):
    calls = {"n": 0}

    def boom(*a, **kw):
        calls["n"] += 1
        raise RuntimeError("api down")
    monkeypatch.setattr(llm_mod, "llm_json", boom)

    sents = mini_sents(3)
    units = mini_units(sents)
    units_by_id = {u.unit_id: u for u in units}
    cache: dict = {}
    cand = validate_and_repair(
        _mk_candidate(sents), sents, Graph([], units), units, units_by_id, {},
        FakeAdapter(), {}, lambda s, e: "", "topic", cache, threading.Lock())
    assert cand is not None                                        # ship-but-flag: kept
    assert cand.verdict.error is True
    assert calls["n"] == 1                                         # ONE judge attempt, no repair spin
    assert cache == {}                                             # error verdicts are never cached
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/test_judge_rubric.py -q`
Expected: FAIL — `reasoning`/`score_10`/`error` unknown fields; `test_fallback_verdict_on_llm_failure` gets score 0.7; repair test gets non-error verdict.

- [ ] **Step 4: Implement in `backend/pipeline/assemble/validate.py`**

a) Import: change `from pydantic import BaseModel, Field` → `from pydantic import BaseModel, Field, model_validator`.

b) Replace `JudgeVerdict` with (field ORDER is load-bearing — google-genai preserves declaration order in `response_schema`, so Gemini generates `reasoning` first):

```python
class JudgeVerdict(BaseModel):
    reasoning: str = ""      # 2-3 sentence CoT the judge writes BEFORE the verdict fields
    understandable: bool = False
    score: float = 0.0       # normalized 0-1; derived from score_10 when the judge emits it
    score_10: int = 0        # judge emits an integer 1-10; 0 = not emitted (legacy/fallback)
    topic_identifiable: bool = True
    purpose_identifiable: bool = True
    all_references_resolved: bool = True
    prerequisites_satisfied: bool = True
    visuals_sufficient: bool = True
    problem_statement_complete: bool = True
    reasoning_complete: bool = True
    result_complete: bool = True
    source_grounded: bool = True
    failure_reasons: list[FailureReason] = Field(default_factory=list)
    error: bool = False      # judge call failed (set ONLY by the fallback path, never the LLM)

    @model_validator(mode="after")
    def _normalize_score(self):
        if self.score_10 > 0:
            self.score = min(max(self.score_10, 1), 10) / 10.0
        return self
```

c) Replace `JUDGE_SYSTEM` with:

```python
JUDGE_SYSTEM = (
    "You are a strict judge of whether a short video clip is SELF-CONTAINED. You see ONLY the "
    "clip's transcript (and any on-screen text), never the surrounding video. Decide whether a "
    "brand-new viewer, watching only this clip, could understand what it is about and follow it "
    "to a complete thought.\n"
    "Evaluate in three steps:\n"
    "1. Identify what the clip is about and why it matters (topic and purpose).\n"
    "2. Hunt for dangling references — 'this', 'that', 'the previous equation' with no antecedent "
    "inside the clip — and for concepts the clip assumes but never introduces (and that are not "
    "common knowledge).\n"
    "3. If the clip is a worked problem, check the question is stated, the reasoning shown, and "
    "the result reached.\n"
    "Score bands for score_10 (integer 1-10):\n"
    "1-2: incomprehensible without the source video. 3-4: major gaps — the topic is unclear OR a "
    "key reference/prerequisite is missing. 5-6: partially followable — topic clear but real gaps "
    "remain. 7-8: fully understandable with minor rough edges. 9-10: flawlessly self-contained.\n"
    "First write `reasoning`: 2-3 sentences applying the steps to THIS clip. Then set every "
    "boolean truthfully and score_10 per the bands:\n"
    "- topic_identifiable / purpose_identifiable: is it clear what this is about and why?\n"
    "- all_references_resolved: no dangling 'this/that/the previous equation' without an antecedent.\n"
    "- prerequisites_satisfied: it doesn't assume a concept it never introduces or that isn't common.\n"
    "- visuals_sufficient: you cannot see the frames — set TRUE unless the transcript explicitly leans "
    "on an unshown, undescribed visual that is essential to follow it.\n"
    "- problem_statement_complete / reasoning_complete / result_complete: for a worked problem, is the "
    "question stated, the reasoning shown, and the result reached? (Set true/NA if not a problem.)\n"
    "- source_grounded: the clip stands on its own words (not obviously mid-argument).\n"
    "Give an overall 'understandable' boolean. For each problem add a failure_reason whose 'kind' "
    "is EXACTLY one of: unresolved_reference, missing_prerequisite, missing_visual, "
    "missing_problem_statement, missing_reasoning, missing_result, not_source_grounded, off_topic, "
    "other — and set missing_concept (for a prerequisite) or reference_text (the dangling phrase) "
    "when relevant. Never set 'error' or 'score' yourself; emit score_10 only. "
    "Output only the structured result."
)
```

d) In `judge_clip`, force `error=False` on every successful parse and replace the final fallback. The try/except block becomes:

```python
    try:
        v = llm_json(JUDGE_SYSTEM, user, JudgeVerdict, temperature=0.0, provider=provider, model=model)
        v.error = False                      # the LLM can never self-flag a transport error
        return v
    except Exception:
        if provider is not None or model is not None:  # cross-model judge failed → authoring model
            try:
                v = llm_json(JUDGE_SYSTEM, user, JudgeVerdict, temperature=0.0)
                v.error = False
                return v
            except Exception:
                pass
        # judge unavailable after retries: honest error verdict — never a free pass (was 0.7)
        return JudgeVerdict(error=True, understandable=False, score=0.0,
                            reasoning="judge unavailable")
```

e) `is_complete` gains the error guard as its first line:

```python
def is_complete(v: JudgeVerdict, role: str, adapter, min_score: float) -> bool:
    if v.error:
        return False
    required = adapter.required_verdict_fields(role)
    return v.score >= min_score and all(getattr(v, f, True) for f in required)
```

f) In `validate_and_repair`: (1) don't cache error verdicts — replace the verdict-fetch block:

```python
        key = frozenset(cand.unit_ids)
        verdict = _cached(key)
        if verdict is None:
            verdict = validate_candidate(cand, sentences, adapter,
                                         visual_summary_fn(cand.start, cand.end), topic)
            if not verdict.error:            # an outage verdict must not poison the cache
                _store(key, verdict)
        cand.verdict = verdict
        cand.attempts = attempt + 1

        if verdict.error:
            return cand                      # ship-but-flag: keep the clip, skip repair entirely
```

(the `if verdict.error: return cand` lines are NEW, inserted immediately after `cand.attempts = attempt + 1` and before the `is_complete` check).

- [ ] **Step 5: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/test_judge_rubric.py -q`
Expected: 10 passed.

- [ ] **Step 6: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: 98 passed (88 + 10), compile clean.

---


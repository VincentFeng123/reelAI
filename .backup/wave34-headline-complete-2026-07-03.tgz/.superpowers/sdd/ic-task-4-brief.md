### Task 4: Re-judge hook + full ledger + 3-tuple return + caller updates

**Files:**
- Modify: `backend/pipeline/assemble/__init__.py` (steps 4-5-7 region + signature + docstring)
- Modify: `backend/cli.py:80` region (unpack + rejection lines)
- Modify: `backend/orchestrator.py:201-204` (unpack; rejections currently unused there — `_, `)
- Modify: `backend/eval/run_eval.py:260` region (unpack + per-stage counts into the run dict)
- Test: append to `backend/pipeline/assemble/tests/test_integrity.py`

**Interfaces:**
- Consumes: Tasks 1-3 (`Rejection`, snap tuple, `merged` flag, repair rejections list).
- Produces: `assemble_clips(...) -> tuple[list[dict], str, list[Rejection]]`; eval run dicts gain
  `rejections_repair, rejections_snap, rejections_dedupe, rejections_post_merge_judge,
  rejections_quality_floor, rejections_max_clips` (ints).

- [ ] **Step 1: Write the failing tests** (append to `test_integrity.py`)

```python
# ── re-judge hook + ledger stages (pure step-5 logic exercised via assemble_clips) ──
from backend.pipeline.understand.models import ContentMap, ContentNode, DependencyGraph, Structure


def _structure(sents, units):
    n = len(sents)
    return Structure(video_id="v", units=units, dependencies=DependencyGraph(),
                     content_map=ContentMap(nodes=[ContentNode(node_id="video", level="video",
                                                               sentence_range=(0, n - 1))]))


class AnchorAdapter(FakeAdapter):
    def is_anchor_role(self, role):
        return True

    def anchor_priority(self, role):
        return 0.9

    def facet_for(self, role):
        return "other"

    def valid_roles(self):
        return {"explanation"}


def test_assemble_returns_rejections_and_rejudges_merges(monkeypatch):
    from backend import config
    from backend.pipeline.assemble import assemble_clips
    monkeypatch.setattr(config, "JUDGE_MODEL", "")
    monkeypatch.setattr(config, "JUDGE_PROVIDER", "same")
    calls = {"n": 0}

    def good(*a, **kw):
        sch = a[2] if len(a) > 2 else kw.get("schema")
        from backend.pipeline.assemble.validate import JudgeVerdict as JV
        if sch is JV or (a and "self-contained" in str(a[0])):
            calls["n"] += 1
            return JV(reasoning="ok", score_10=9, understandable=True)
        raise AssertionError("unexpected llm call")
    monkeypatch.setattr(llm_mod, "llm_json", good)

    sents, units = _setup(8)
    st = _structure(sents, units)
    settings = {"min_clip_duration_s": 1.0, "max_clip_duration_s": 500.0,
                "min_comprehension_score": 0.7, "quality_floor": 0.0, "max_clips": 12,
                "max_anchors": 12, "closure_max_span_s": 999.0}
    specs, notes, rejections = assemble_clips(st, "", sents, "u", "v", settings, AnchorAdapter())
    assert isinstance(rejections, list)
    assert all(hasattr(r, "stage") for r in rejections)
    assert isinstance(specs, list) and isinstance(notes, str)


def test_quality_floor_and_max_clips_ledgered(monkeypatch):
    from backend import config
    from backend.pipeline.assemble import assemble_clips
    monkeypatch.setattr(config, "JUDGE_MODEL", "")
    monkeypatch.setattr(config, "JUDGE_PROVIDER", "same")
    monkeypatch.setattr(llm_mod, "llm_json",
                        lambda *a, **kw: JudgeVerdict(reasoning="ok", score_10=9, understandable=True))
    sents, units = _setup(8)
    st = _structure(sents, units)
    # floor 2.0 is unreachable → every kept candidate must land in quality_floor rejections
    settings = {"min_clip_duration_s": 1.0, "max_clip_duration_s": 500.0,
                "min_comprehension_score": 0.7, "quality_floor": 2.0, "max_clips": 12,
                "max_anchors": 12, "closure_max_span_s": 999.0}
    specs, _notes, rejections = assemble_clips(st, "", sents, "u", "v", settings, AnchorAdapter())
    assert specs == []
    assert rejections and all(r.stage in {"quality_floor", "dedupe", "snap", "repair"} for r in rejections)
    assert any(r.stage == "quality_floor" for r in rejections)
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/test_integrity.py -q`
Expected: FAIL — `assemble_clips` returns a 2-tuple; snap call inside it breaks on the new
snap signature only if Task 3 landed (it did) — the 2-tuple unpack error is the expected RED.

- [ ] **Step 3: Implement**

a) `assemble/__init__.py` — imports gain `from .integrity import Rejection` and
`from .validate import judge_clip`; step 4 onward becomes:

```python
    # 4. snap boundaries (metadata-aware dedupe; drops ledgered) -------------
    emit(0.80, "Refining boundaries…")
    specs, snap_rejections = snap_candidates(kept, sentences, settings, units)
    rejections.extend(snap_rejections)

    # 4b. hybrid re-judge: a merged span's text was never judged --------------
    surviving = []
    for s in specs:
        if not s.get("merged"):
            surviving.append(s)
            continue
        text = " ".join((sentences[i].text or "")
                        for i in range(s["sentence_start_idx"], s["sentence_end_idx"] + 1)).strip()
        key = frozenset(s.get("unit_ids", []))
        with cache_lock:
            verdict = cache.get(key)
        if verdict is None:
            verdict = judge_clip(text, s.get("role", ""), adapter,
                                 visual_summary=structure.visual_summary(s["start"], s["end"]),
                                 topic=topic, context_card="")
            if not verdict.error:
                with cache_lock:
                    cache[key] = verdict
        if verdict.error:                                 # outage: ship-but-flag (rubric policy)
            s["judge_error"] = True
            s["warnings"] = tuple(set(s.get("warnings") or ()) | {"unjudged"})
            surviving.append(s)
            continue
        if not (verdict.topic_identifiable and verdict.purpose_identifiable
                and verdict.source_grounded and verdict.all_references_resolved):
            rejections.append(Rejection(
                cand_id=s.get("cand_id", ""), title=s.get("title", ""), role=s.get("role", ""),
                stage="post_merge_judge", reason="merged span failed hard-core judge gate",
                score=float(verdict.score), failure_kinds=[f.kind for f in verdict.failure_reasons],
                final_quality=s.get("final_quality"), start=s["start"], end=s["end"]))
            continue
        s["completeness_score"] = scoring.completeness_score(verdict, s.get("role", ""), adapter)
        surviving.append(s)
    specs = surviving

    # 5. boundary score + quality filter (drops ledgered) --------------------
    for s in specs:
        s["boundary_score"] = scoring.boundary_score(s.get("warnings"))
        s["final_quality"] = scoring.quality(
            s.get("completeness_score", 0.0), s.get("grounding_score", 0.0),
            s["boundary_score"], s.get("priority", 0.0))
    floor = float(settings.get("quality_floor", 0.45))
    weak = [s for s in specs if s.get("final_quality", 0.0) < floor]
    specs = scoring.drop_weak(specs, floor)
    for s in weak:
        rejections.append(Rejection(cand_id=s.get("cand_id", ""), title=s.get("title", ""),
                                    role=s.get("role", ""), stage="quality_floor",
                                    reason=f"final_quality {s.get('final_quality', 0.0):.2f} < floor {floor}",
                                    final_quality=s.get("final_quality"), start=s["start"], end=s["end"]))
    specs.sort(key=lambda s: s["final_quality"], reverse=True)
    cap = int(settings.get("max_clips", config.DEFAULTS["max_clips"]))
    for s in specs[cap:]:
        rejections.append(Rejection(cand_id=s.get("cand_id", ""), title=s.get("title", ""),
                                    role=s.get("role", ""), stage="max_clips",
                                    reason=f"beyond max_clips={cap}",
                                    final_quality=s.get("final_quality"), start=s["start"], end=s["end"]))
    specs = specs[:cap]
```

All three `return [], "…"` early-exits become `return [], "…", rejections` (empty list at the
anchors exit — define `rejections` before step 3). The final return:
`return specs, notes, rejections`. Docstring updated: "Returns (clips_spec, notes, rejections)".

b) `cli.py:80` — `clips_spec, notes = …` → `clips_spec, notes, rejections = …`; after the
`print(f"  notes: …")` line add:

```python
    for r in (rejections or []):
        print(f"  [dropped/{r.stage}] {r.title[:60]} (score={r.score}, kinds={r.failure_kinds}, q={r.final_quality})")
```

(the fast-path branch sets `rejections = []` next to its existing assignments.)

c) `orchestrator.py:201-204` —

```python
    clips_spec, notes, rejections = await run(
        assemble_clips, structure, job.topic, sentences, job.url, video_id,
        settings, adapter, emit("assembling", 72, 90),
    )
    if rejections:
        registry.publish(job, ProgressEvent(
            "assembling", 90.0, f"{len(rejections)} candidate(s) dropped ({', '.join(sorted({r.stage for r in rejections}))})"))
```

d) `eval/run_eval.py` — the call site becomes
`specs, _notes, rejections = assemble_clips(st, topic, sents, url, video_id, settings, adapter)`
and immediately after the `_measure` call appends counts to the run dict:

```python
            m = _measure(st, specs, sents, adapter, det, topic, gold, settings,
                         verbose=verbose and r == 0)
            for stage in ("repair", "snap", "dedupe", "post_merge_judge", "quality_floor", "max_clips"):
                m[f"rejections_{stage}"] = sum(1 for rj in rejections if rj.stage == stage)
            run_dicts.append(m)
```

(the `rejections` variable is bound in the same guarded block where `assemble_clips` runs;
`--freeze-specs` reuses the same rejections for all runs — correct, since specs are frozen.)

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/ backend/eval/tests/ -q`
Expected: 62 passed (34 assemble + 28 eval).

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: 126 passed, compile clean.

---


### Task 3: Part-B dedupe + snap rejections + additive mutation warnings

**Files:**
- Modify: `backend/pipeline/assemble/boundary_adapt.py` (snap_candidates signature + `_dedupe_partb`; `candidate_to_boundary_input` carries `truncated`)
- Modify: `backend/pipeline/refine.py` (two additive warnings ONLY)
- Modify: `backend/pipeline/boundary.py::_resolve_overlaps` (one additive warning)
- Modify: `backend/pipeline/assemble/scoring.py::boundary_score` (three new penalties)
- Modify: `backend/pipeline/assemble/tests/test_judge_rubric.py::test_snap_flags_and_warns_unjudged` (new snap return shape)
- Test: append to `backend/pipeline/assemble/tests/test_integrity.py`

**Interfaces:**
- Consumes: Task 1's `merge_partb`, `Rejection`; refine's `_better`, `_trim_start_after`, `NEAR_DUP_EPS` (imported, unmodified).
- Produces: `snap_candidates(cands, sentences, settings, units=None) -> tuple[list[dict], list[Rejection]]`; specs may carry `"merged": True` and `"truncated": bool`; warnings `"extended_for_min_duration"`/`"trimmed_start"` appear in shared snap output.

- [ ] **Step 1: Write the failing tests** (append to `test_integrity.py`)

```python
# ── Part-B dedupe + snap rejections + mutation warnings ──────────────────────
from backend.pipeline.assemble.boundary_adapt import snap_candidates
from backend.pipeline.refine import _dedupe as refine_dedupe


def _cand(cand_id, s0, s1, sents, *, facet="other", fq=0.5, verdict=None):
    c = Candidate(cand_id=cand_id, anchor_id=f"u{s0:04d}", role="explanation", facet=facet,
                  title=f"t-{cand_id}", reason="r", unit_ids=[f"u{i:04d}" for i in range(s0, s1 + 1)],
                  referential=[], i_start=s0, i_end=s1,
                  start=sents[s0].start, end=sents[s1].end)
    c.final_quality = fq
    c.verdict = verdict or JudgeVerdict(score_10=8, understandable=True)
    return c


_SETTINGS = {"min_clip_duration_s": 1.0, "max_clip_duration_s": 500.0}


def test_same_facet_overlap_merges_and_flags():
    sents, units = _setup(8)
    a = _cand("a", 0, 3, sents, fq=0.9)
    b = _cand("b", 2, 5, sents, fq=0.4)              # overlaps a, same facet
    specs, rejections = snap_candidates([a, b], sents, _SETTINGS, units)
    assert len(specs) == 1 and specs[0]["merged"] is True
    assert specs[0]["sentence_start_idx"] == 0 and specs[0]["sentence_end_idx"] == 5
    assert specs[0]["unit_ids"] == [f"u{i:04d}" for i in range(6)]
    assert "merged_overlap" in specs[0]["warnings"]
    assert rejections == []                           # merge is not a drop


def test_containment_loser_becomes_dedupe_rejection():
    sents, units = _setup(8)
    big = _cand("big", 0, 5, sents, fq=0.9)
    small = _cand("small", 1, 2, sents, fq=0.2)      # contained in big
    specs, rejections = snap_candidates([big, small], sents, _SETTINGS, units)
    assert [s["cand_id"] for s in specs] == ["big"]
    assert len(rejections) == 1
    r = rejections[0]
    assert r.stage == "dedupe" and r.cand_id == "small" and "big" in r.reason


def test_dedupe_partb_matches_refine_on_disjoint_and_containment():
    """Characterization: identical keep decisions as refine._dedupe on non-merge shapes."""
    sents, units = _setup(10)
    disjoint = [_cand("a", 0, 1, sents, fq=0.5), _cand("b", 4, 5, sents, fq=0.5)]
    contained = [_cand("c", 0, 5, sents, fq=0.9), _cand("d", 2, 3, sents, fq=0.1)]
    for group in (disjoint, contained):
        specs, _ = snap_candidates(list(group), sents, _SETTINGS, units)
        legacy_in = [snap_candidates([c], sents, _SETTINGS, units)[0][0] for c in group]
        legacy = refine_dedupe([dict(s) for s in legacy_in], sents, 1.0)
        assert sorted(s["start"] for s in specs) == sorted(c["start"] for c in legacy)


def test_truncated_carried_into_spec():
    sents, units = _setup()
    c = _cand("a", 0, 2, sents)
    c.truncated = True
    specs, _ = snap_candidates([c], sents, _SETTINGS, units)
    assert specs[0]["truncated"] is True


def test_boundary_score_penalizes_mutation_warnings():
    from backend.pipeline.assemble.scoring import boundary_score
    assert boundary_score(["extended_for_min_duration"]) == pytest.approx(0.90)
    assert boundary_score(["trimmed_start"]) == pytest.approx(0.90)
    assert boundary_score(["missing_context_card"]) == pytest.approx(0.90)


def test_snap_one_warns_on_min_duration_extension():
    from backend.pipeline.refine import _snap_one
    sents, _ = _setup(6)                              # each sentence ≈10 s
    clip = _snap_one({"i_start": 0, "i_end": 0, "facet": "other"}, sents,
                     False, 25.0, 0.05, 500.0)        # min_dur 25 s forces extension past s0
    assert clip is not None
    assert "extended_for_min_duration" in clip["warnings"]
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/test_integrity.py -q`
Expected: new tests FAIL — snap_candidates returns a list (not tuple), no `merged`/`truncated`
keys, boundary_score returns 1.0, no extension warning.

- [ ] **Step 3: Implement**

a) `refine.py::_snap_one` — in the min-duration loop ONLY (additive):

```python
    # enforce minimum duration by extending the end outward to full period sentences
    guard = 0
    extended = False
    while sentences[ei].end - sentences[si].start < min_dur and guard < n:
        nxt = _valid_end_at_or_after(sentences, ei + 1, allow_qe)
        if nxt is None or nxt == ei:
            warnings.append("min_duration_unreachable")
            break
        ei = nxt
        extended = True
        guard += 1
    if extended:
        warnings.append("extended_for_min_duration")   # content beyond the judged span
```

b) `refine.py::_trim_start_after` — additive warning on the successful-trim path:

```python
            if c["end"] - new_start >= min_dur:
                d = dict(c)
                d["start"] = round(new_start, 3)
                d["sentence_start_idx"] = i
                d["warnings"] = tuple(set(c.get("warnings") or ()) | {"trimmed_start"})
                return d
```

c) `boundary.py::_resolve_overlaps` — additive warning when a start is actually trimmed:

```python
    for c in clips:
        c = dict(c)
        if c["start"] < last_end:
            c["start"] = round(last_end, 3)
            c["warnings"] = tuple(set(c.get("warnings") or ()) | {"trimmed_start"})
        ...
```

d) `scoring.py::boundary_score` — extend the penalty sum:

```python
               + 0.10 * ("extended_for_min_duration" in w)
               + 0.10 * ("trimmed_start" in w)
               + 0.10 * ("missing_context_card" in w)
```

e) `boundary_adapt.py` — new signature + Part-B dedupe. `candidate_to_boundary_input` adds
`"truncated": bool(getattr(cand, "truncated", False)),` next to `judge_error`. Then:

```python
def snap_candidates(cands: list[Candidate], sentences: list[Sentence], settings: dict,
                    units=None) -> tuple[list[dict], list[Rejection]]:
    from ..refine import _snap_one
    allow_qe = bool(settings.get("allow_question_exclaim_ends", config.DEFAULTS["allow_question_exclaim_ends"]))
    min_dur = float(settings.get("min_clip_duration_s", config.DEFAULTS["min_clip_duration_s"]))
    max_dur = float(settings.get("max_clip_duration_s", config.DEFAULTS["max_clip_duration_s"]))
    tail_pad = float(settings.get("tail_pad_s", config.DEFAULTS["tail_pad_s"]))

    rejections: list[Rejection] = []
    specs: list[dict] = []
    for c in cands:
        b = candidate_to_boundary_input(c)
        snapped = _snap_one(b, sentences, allow_qe, min_dur, tail_pad, max_dur)
        if snapped is None:
            rejections.append(Rejection(cand_id=c.cand_id, title=c.title, role=c.role,
                                        stage="snap", reason="unsnappable (end<=start)",
                                        final_quality=c.final_quality, start=c.start, end=c.end))
            continue
        specs.append({**b, **snapped})
    for s in specs:
        if s.get("judge_error"):   # unjudged (judge outage): user-visible + boundary_score penalty
            s["warnings"] = list(s.get("warnings") or []) + ["unjudged"]
    specs, dedupe_rejections = _dedupe_partb(specs, sentences, min_dur, units)
    rejections.extend(dedupe_rejections)
    specs.sort(key=lambda s: s["start"])
    return specs, rejections


def _dedupe_partb(clips: list[dict], sentences: list[Sentence], min_dur: float,
                  units) -> tuple[list[dict], list[Rejection]]:
    """refine._dedupe's keep/drop decisions, but metadata-aware: same-facet overlaps merge via
    integrity.merge_partb (union + merged flag, re-judged upstream) and every dropped spec
    becomes a Rejection. refine.py itself is untouched (legacy fast path)."""
    from ..refine import NEAR_DUP_EPS, _better, _trim_start_after

    def _reject(loser: dict, winner: dict) -> None:
        rejections.append(Rejection(
            cand_id=loser.get("cand_id", ""), title=loser.get("title", ""),
            role=loser.get("role", ""), stage="dedupe",
            reason=f"overlap loser to {winner.get('cand_id', '?')}",
            final_quality=loser.get("final_quality"), start=loser["start"], end=loser["end"]))

    rejections: list[Rejection] = []
    clips = sorted(clips, key=lambda c: (c["start"], -c["end"]))
    kept: list[dict] = []
    for c in clips:
        if not kept:
            kept.append(c)
            continue
        k = kept[-1]
        if c["start"] >= k["end"]:                      # disjoint
            kept.append(c)
            continue
        overlapping_pairs = (
            (c["start"] >= k["start"] and c["end"] <= k["end"]) or
            (c["start"] <= k["start"] and c["end"] >= k["end"]) or
            (abs(c["start"] - k["start"]) <= NEAR_DUP_EPS and abs(c["end"] - k["end"]) <= NEAR_DUP_EPS)
        )
        if overlapping_pairs:                            # containment / near-dup → keep better
            winner = _better(k, c)
            _reject(c if winner is k else k, winner)
            kept[-1] = winner
            continue
        if c["facet"] == k["facet"]:                    # same facet → metadata-aware union
            kept[-1] = merge_partb(k, c, units, sentences)
            continue
        trimmed = _trim_start_after(c, k["end"], sentences, min_dur)
        if trimmed is not None:
            kept.append(trimmed)
        else:
            winner = _better(k, c)
            _reject(c if winner is k else k, winner)
            kept[-1] = winner
    return kept, rejections
```

(`from .integrity import Rejection, merge_partb` in module imports; drop the now-unused
`refine._dedupe` import.)

f) `tests/test_judge_rubric.py::test_snap_flags_and_warns_unjudged` — the call becomes
`specs, _rej = snap_candidates([ok, bad], sents, {...})` (units omitted → default None).

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/ -q`
Expected: 32 passed.

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: 124 passed, compile clean.

---


"""Chronological sequencing + prerequisite hints (spec §7C) + severed-pair linking (P4b).

Clips are presented in temporal order (earlier-in-video first). The dependency graph is
used only to attach optional "watch first" hints — never to reorder.

P4b (Wave 2 §16): two halves of ONE worked example that shipped as separate clips (the
audited kinematics bus problem — setup/givens in one clip, result 42s later in another,
``prerequisite_clips=[]``) are detected after sequencing. The pair is ALWAYS linked
(earlier sequence index into the later clip's ``prerequisite_clips`` + a
'continues clip N' note); a merge is ADDITIONALLY attempted only when the combined span
fits the ship cap, via a caller-supplied ``merge_fn`` that must re-judge the union and
return it ONLY on a clean verdict — otherwise the linked pair stands. Nothing is ever
killed here.
"""
from __future__ import annotations

from typing import Callable, Optional

SEVERED_OPENER_ROLES = frozenset({"example_setup", "problem_givens"})
SEVERED_PAYOFF_ROLES = frozenset({"result", "solution"})
SEVERED_MAX_GAP_S = 60.0


def attach_prerequisites(specs: list[dict], graph, units_by_id: dict) -> None:
    """Hint an earlier clip only for concepts this clip REQUIRES but does not itself
    introduce — a clip that contains its own definition needs no 'watch first' pointer."""
    def _units(s):
        return [units_by_id[u] for u in s.get("unit_ids", []) if u in units_by_id]

    for s in specs:
        mine = _units(s)
        intro = set().union(*[set(u.concepts_introduced) for u in mine]) if mine else set()
        req = set().union(*[set(u.concepts_required) for u in mine]) if mine else set()
        unmet = {c for c in (req - intro) if c}
        prereqs: list[int] = []
        if unmet:
            # precompute each earlier clip's introduced-set ONCE (not per concept)
            earlier = []
            for other in specs:
                if other is s or other["start"] >= s["start"]:
                    continue                                  # only EARLIER clips
                ou_units = _units(other)
                ou_intro = set().union(*[set(u.concepts_introduced) for u in ou_units]) \
                    if ou_units else set()
                earlier.append((other, ou_intro))
            for concept in unmet:
                for other, ou_intro in earlier:               # specs are in temporal order
                    if concept in ou_intro:
                        prereqs.append(other["sequence_index"])
                        # only the earliest for this concept — deliberate departure from
                        # hint-all-earlier-clips: fewer redundant "watch first" pointers;
                        # the earliest introducer suffices
                        break
        s["prerequisite_clips"] = sorted(set(prereqs))


def sequence_clips(specs: list[dict], graph, units_by_id: dict) -> list[dict]:
    specs.sort(key=lambda s: s["start"])
    for i, s in enumerate(specs):
        s["sequence_index"] = i + 1
    attach_prerequisites(specs, graph, units_by_id)
    return specs


# ── P4b: severed-pair detection + link/merge ─────────────────────────────────
def _spec_roles(s: dict, units_by_id: dict) -> set[str]:
    return {units_by_id[uid].role for uid in s.get("unit_ids", []) if uid in units_by_id}


def _spec_topics(s: dict, units_by_id: dict) -> set[str]:
    out: set[str] = set()
    for uid in s.get("unit_ids", []):
        u = units_by_id.get(uid)
        if u is not None:
            t = (u.node_id or u.topic or "").strip()
            if t:
                out.add(t)
    return out


def _same_topic(a: dict, b: dict, units_by_id: dict) -> bool:
    """Same-topic gate: clips are DIFFERENT-topic only when both sides carry topic
    evidence (unit node_id/topic) and none of it overlaps — with no evidence on a side,
    the role grammar + the 60s gap cap remain the deciding signals."""
    ta, tb = _spec_topics(a, units_by_id), _spec_topics(b, units_by_id)
    if not ta or not tb:
        return True
    return bool(ta & tb)


def is_severed_pair(earlier: dict, later: dict, units_by_id: dict,
                    max_gap_s: float = SEVERED_MAX_GAP_S) -> bool:
    """One instructional event cut in two: the EARLIER clip has the setup roles
    (example_setup|problem_givens) but no payoff (result|solution), the LATER clip has the
    payoff but no setup, same topic, and the hole between them is at most ``max_gap_s``."""
    if later["start"] - earlier["end"] > max_gap_s:
        return False
    if not _same_topic(earlier, later, units_by_id):
        return False
    er = _spec_roles(earlier, units_by_id)
    lr = _spec_roles(later, units_by_id)
    return (bool(er & SEVERED_OPENER_ROLES) and not (er & SEVERED_PAYOFF_ROLES)
            and bool(lr & SEVERED_PAYOFF_ROLES) and not (lr & SEVERED_OPENER_ROLES))


def link_severed_pairs(specs: list[dict], graph, units_by_id: dict, max_dur_s: float,
                       merge_fn: Optional[Callable[[dict, dict], Optional[dict]]] = None
                       ) -> list[dict]:
    """P4b, run AFTER sequencing. Pass 1 attempts merges: a severed pair whose combined
    span fits ``max_dur_s`` is handed to ``merge_fn`` (which builds the union, re-judges
    its NEVER-judged text, and returns it only on a clean verdict); a successful merge
    replaces the pair and the list is re-sequenced (fresh indices + prerequisite hints).
    Pass 2 ALWAYS links whatever remains severed: the earlier clip's sequence index joins
    the later clip's prerequisite_clips (dedup'd) and a 'continues clip N' note is
    appended — the learner is told to watch part 1 first even when no merge is possible."""
    if merge_fn is not None:
        out: list[dict] = []
        merged_any = False
        i = 0
        while i < len(specs):
            s = specs[i]
            if i + 1 < len(specs):
                nxt = specs[i + 1]
                if (is_severed_pair(s, nxt, units_by_id)
                        and nxt["end"] - s["start"] <= max_dur_s):   # merge ONLY under the cap
                    merged = merge_fn(s, nxt)
                    if merged is not None:                           # clean re-judge → union ships
                        out.append(merged)
                        merged_any = True
                        i += 2
                        continue
            out.append(s)
            i += 1
        specs = out
        if merged_any:
            specs = sequence_clips(specs, graph, units_by_id)
    for earlier, later in zip(specs, specs[1:]):
        if is_severed_pair(earlier, later, units_by_id):
            n = int(earlier.get("sequence_index", 0))
            later["prerequisite_clips"] = sorted(
                set(later.get("prerequisite_clips") or []) | {n})
            note = f"continues clip {n}"
            notes = list(later.get("notes") or [])
            if note not in notes:
                notes.append(note)
            later["notes"] = notes
    return specs

# Task 3 Completion Report: Relevance-Degraded Surfacing + Unmet-Concept Prerequisite Hints

## Status
**COMPLETE** — All 4 tests GREEN; 149 backend tests pass; compile clean.

## Test Summary
- `test_relevance_retry_then_success_not_degraded`: Retry fails on attempt 1, succeeds on attempt 2, returns `degraded=False` ✓
- `test_relevance_double_failure_flags_degraded`: Both attempts fail, returns `degraded=True`, neutral 0.5 defaults ✓
- `test_relevance_empty_topic_no_llm`: Empty topic short-circuits LLM entirely, returns `degraded=False`, all 1.0 ✓
- `test_prereq_hint_skipped_when_self_defined`: Unmet concepts = req − intro; hints only earliest clip per concept ✓

## Files Modified

### `backend/pipeline/assemble/candidates.py`
- `score_topic_relevance(units, topic, settings, progress) -> tuple[dict[str, float], bool]`
  - Added retry loop: `for attempt in range(2)` with break on success
  - Sets `degraded=True` only when `attempt==1` and exception occurs (i.e., after retry fails)
  - Empty/blank topic returns early: `({u.unit_id: 1.0 for u in units}, False)` — LLM never called

### `backend/pipeline/assemble/__init__.py` (step 1)
- Line 63: Unpacks tuple: `relevance, relevance_degraded = score_topic_relevance(...)`

### `backend/pipeline/assemble/__init__.py` (step 7 + notes)
- Line 187: Passes `units_by_id` to `sequence_clips(specs, graph, units_by_id)`
- Lines 190–195: Constructs notes; appends exact suffix only when `relevance_degraded and topic`:
  - Suffix: `" (topic filtering degraded — clips selected by role priority)"` (em dash)

### `backend/pipeline/assemble/sequence.py`
- `attach_prerequisites(specs, graph, units_by_id) -> None`
  - Computes `unmet = req − intro` (concepts required but not introduced by current clip)
  - For each unmet concept, finds EARLIEST earlier clip that introduces it; adds its `sequence_index`
  - Self-introduced concepts → no hint (unmet set is empty)
- `sequence_clips(specs, graph, units_by_id) -> list[dict]`
  - Signature updated; calls `attach_prerequisites` with `units_by_id`

### `backend/pipeline/assemble/tests/test_integrity.py`
- Added 4 tests (lines 468–518); uses existing `_setup`, `llm_mod`, `Graph`, `RelevanceLLM`, `RelItem`

## Self-Review Checklist
- ✓ Retry exactly once per batch: `for attempt in range(2)` gives 2 attempts total
- ✓ Degraded only after retry fails: `if attempt == 1` ensures flag only on 2nd attempt failure
- ✓ Empty-topic path never calls LLM: early return before loop
- ✓ Notes suffix exact: `" (topic filtering degraded — clips selected by role priority)"` matches brief
- ✓ Graph param retained: both `attach_prerequisites` and `sequence_clips` preserve `graph` param (future-proofing)
- ✓ Tuple unpacking in sole caller: `assemble_clips` correctly unpacks at step 1
- ✓ Units map passed to sequence: step 7 now passes `units_by_id`

## Test Results
- **Task 3 tests**: 4 passed (new)
- **Full backend**: 149 passed (no regression)
- **Compile**: Clean (no syntax errors)

## Concerns
None. The implementation matches the brief exactly and all tests pass. The unmet-concept logic correctly isolates the earliest prerequisite per concept.

## Correction
Implementation deviates from the brief's reference code (earliest-per-concept vs all-earlier-clips) — deliberate, test-mandated, reviewer-endorsed.

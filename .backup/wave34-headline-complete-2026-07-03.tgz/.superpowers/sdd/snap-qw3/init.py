"""Topic-dependent clip assembly (spec §6–9, §7B–C).

assemble_clips turns a cached Structure + a search topic into ordered, self-contained
clip specs: anchor selection → context closure → clip-only judge + repair → boundary
snapping (reusing the existing code) → quality filter → context cards → chronological
sequencing. Returns (clips_spec, notes, rejections); the orchestrator applies the optional
precise Whisper boundary pass and builds the final embed/cut clip dicts.
"""
from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Optional

from ... import config
from ..sentences import Sentence
from ..understand.models import Structure
from . import scoring
from .boundary_adapt import snap_candidates
from .candidates import build_candidate, score_topic_relevance, select_anchors
from .context_card import generate_context_card
from .graph import Graph
from .integrity import Rejection
from .sequence import sequence_clips
from .validate import judge_clip, validate_and_repair

ProgressCb = Optional[Callable[[float, str], None]]


def _card_warning(s: dict) -> None:
    """A clip that NEEDS earlier context (referential prereqs or truncated closure) but has no
    card ships with an explicit, penalized marker instead of failing silently."""
    if not s.get("context_card") and (s.get("referential") or s.get("truncated")):
        s["warnings"] = tuple(set(s.get("warnings") or ()) | {"missing_context_card"})


def _introducer_index(units) -> dict[str, list[str]]:
    idx: dict[str, list[str]] = {}
    for u in units:
        for c in u.concepts_introduced:
            idx.setdefault(c, []).append(u.unit_id)
    return idx


def assemble_clips(structure: Structure, topic: str, sentences: list[Sentence], url: str,
                   video_id: str, settings: dict, adapter,
                   progress: ProgressCb = None) -> tuple[list[dict], str, list[Rejection]]:
    def emit(frac: float, msg: str = "") -> None:
        if progress:
            progress(max(0.0, min(1.0, frac)), msg)

    rejections: list = []

    units = structure.units
    if not units or not sentences:
        return [], "No usable structure was built for this video.", rejections
    units_by_id = structure.units_by_id()
    graph = Graph(structure.dependencies.edges, units)
    introducers = _introducer_index(units)

    # 1. topic relevance -----------------------------------------------------
    emit(0.05, "Scoring topic relevance…")
    relevance = score_topic_relevance(units, topic, settings, lambda f, m="": emit(0.05 + 0.10 * f, m))

    # 2. anchors -------------------------------------------------------------
    anchors = select_anchors(units, relevance, adapter, settings)
    if not anchors:
        return [], (f"“{topic}” isn’t covered enough in this video to clip." if topic
                    else "No clip-worthy moments were found in this video."), rejections

    # 3. assemble + validate/repair each candidate (judged concurrently) -----
    cache: dict = {}
    cache_lock = threading.Lock()

    rej_lock = threading.Lock()

    def _assemble_one(anchor):
        cand = build_candidate(anchor, graph, adapter, units, units_by_id, sentences, relevance, settings)
        if cand is None:
            return None
        cand, rejection = validate_and_repair(cand, sentences, graph, units, units_by_id, introducers,
                                              adapter, settings, structure.visual_summary, topic,
                                              cache, cache_lock)
        if rejection is not None:
            with rej_lock:
                rejections.append(rejection)
        if cand is None:
            return None
        cand.completeness_score = scoring.completeness_score(cand.verdict, cand.role, adapter)
        cand.grounding_score = scoring.grounding_score(cand, units_by_id)
        cand.final_quality = scoring.final_quality(cand)
        return cand

    kept = []
    workers = max(1, min(int(settings.get("judge_workers", config.JUDGE_WORKERS)), len(anchors)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_assemble_one, a) for a in anchors]
        for done, fut in enumerate(as_completed(futures), start=1):
            cand = fut.result()
            if cand is not None:
                kept.append(cand)
            emit(0.15 + 0.60 * done / len(anchors), f"Validating clip {done}/{len(anchors)}")

    if not kept:
        return [], "No self-contained clips could be assembled for this topic.", rejections

    # 4. snap boundaries (metadata-aware dedupe; drops ledgered) -------------
    emit(0.80, "Refining boundaries…")
    specs, snap_rejections = snap_candidates(kept, sentences, settings, units)
    rejections.extend(snap_rejections)

    # 4b. hybrid re-judge: a merged span's text was never judged --------------
    surviving = []
    for s in specs:
        if not s.get("merged"):
            surviving.append(s)
            continue
        text = " ".join((sentences[i].text or "")
                        for i in range(s["sentence_start_idx"], s["sentence_end_idx"] + 1)).strip()
        key = frozenset(s.get("unit_ids", []))
        with cache_lock:
            verdict = cache.get(key)
        if verdict is None:
            verdict = judge_clip(text, s.get("role", ""), adapter,
                                 visual_summary=structure.visual_summary(s["start"], s["end"]),
                                 topic=topic, context_card="")
            if not verdict.error:
                with cache_lock:
                    cache[key] = verdict
        if verdict.error:                                 # outage: ship-but-flag (rubric policy)
            s["judge_error"] = True
            s["warnings"] = tuple(set(s.get("warnings") or ()) | {"unjudged"})
            surviving.append(s)
            continue
        if not (verdict.topic_identifiable and verdict.purpose_identifiable
                and verdict.source_grounded and verdict.all_references_resolved):
            rejections.append(Rejection(
                cand_id=s.get("cand_id", ""), title=s.get("title", ""), role=s.get("role", ""),
                stage="post_merge_judge", reason="merged span failed hard-core judge gate",
                score=float(verdict.score), failure_kinds=[f.kind for f in verdict.failure_reasons],
                final_quality=s.get("final_quality", s.get("score")), start=s["start"], end=s["end"]))
            continue
        s["completeness_score"] = scoring.completeness_score(verdict, s.get("role", ""), adapter)
        s["judge_error"] = False
        s["warnings"] = tuple(w for w in (s.get("warnings") or ()) if w != "unjudged")
        surviving.append(s)
    specs = surviving

    # 5. boundary score + quality filter (drops ledgered) --------------------
    for s in specs:
        s["boundary_score"] = scoring.boundary_score(s.get("warnings"))
        s["final_quality"] = scoring.quality(
            s.get("completeness_score", 0.0), s.get("grounding_score", 0.0),
            s["boundary_score"], s.get("priority", 0.0))
    floor = float(settings.get("quality_floor", 0.45))
    weak = [s for s in specs if s.get("final_quality", 0.0) < floor]
    specs = scoring.drop_weak(specs, floor)
    for s in weak:
        rejections.append(Rejection(cand_id=s.get("cand_id", ""), title=s.get("title", ""),
                                    role=s.get("role", ""), stage="quality_floor",
                                    reason=f"final_quality {s.get('final_quality', 0.0):.2f} < floor {floor}",
                                    final_quality=s.get("final_quality"), start=s["start"], end=s["end"]))
    specs.sort(key=lambda s: s["final_quality"], reverse=True)
    cap = int(settings.get("max_clips", config.DEFAULTS["max_clips"]))
    for s in specs[cap:]:
        rejections.append(Rejection(cand_id=s.get("cand_id", ""), title=s.get("title", ""),
                                    role=s.get("role", ""), stage="max_clips",
                                    reason=f"beyond max_clips={cap}",
                                    final_quality=s.get("final_quality"), start=s["start"], end=s["end"]))
    specs = specs[:cap]

    if not specs:
        return [], "Clips were found but none were complete enough to keep.", rejections

    # 6. context cards -------------------------------------------------------
    emit(0.90, "Writing context cards…")
    for s in specs:
        s["context_card"] = generate_context_card(s, units_by_id, adapter, topic)
        _card_warning(s)
        if "missing_context_card" in (s.get("warnings") or ()):
            s["boundary_score"] = scoring.boundary_score(s.get("warnings"))
            s["final_quality"] = scoring.quality(
                s.get("completeness_score", 0.0), s.get("grounding_score", 0.0),
                s["boundary_score"], s.get("priority", 0.0))

    # 7. chronological sequence + prerequisite hints ------------------------
    specs = sequence_clips(specs, graph)
    emit(1.0, f"Assembled {len(specs)} clip(s)")

    notes = f"{len(specs)} clip(s) about “{topic}”." if topic else f"{len(specs)} clip(s)."
    return specs, notes, rejections

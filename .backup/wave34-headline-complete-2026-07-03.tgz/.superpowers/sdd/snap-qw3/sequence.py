"""Chronological sequencing + prerequisite hints (spec §7C).

Clips are presented in temporal order (earlier-in-video first). The dependency graph is
used only to attach optional "watch first" hints — never to reorder.
"""
from __future__ import annotations


def attach_prerequisites(specs: list[dict], graph) -> None:
    for s in specs:
        s_units = set(s.get("unit_ids", []))
        prereqs: list[int] = []
        for other in specs:
            if other is s or other["start"] >= s["start"]:
                continue                                  # only EARLIER clips can be prerequisites
            if graph.defines_needed_for(set(other.get("unit_ids", [])), s_units):
                prereqs.append(other["sequence_index"])
        s["prerequisite_clips"] = sorted(set(prereqs))


def sequence_clips(specs: list[dict], graph) -> list[dict]:
    specs.sort(key=lambda s: s["start"])
    for i, s in enumerate(specs):
        s["sequence_index"] = i + 1
    attach_prerequisites(specs, graph)
    return specs

### Task 2: Atomic writes + range-keyed export + zip guard

**Files:**
- Modify: `backend/pipeline/export.py` (`finalize_output` new; `export_clip` tmp/rename, fname, cache check)
- Modify: `backend/pipeline/cut.py` (`one()` tmp/rename via `finalize_output`)
- Modify: `backend/main.py` (`_zipable_files` helper; `download_zip` guard)
- Test: `backend/pipeline/tests/test_output_safety.py`

**Interfaces:**
- Consumes: existing `build_cmd`, `PipelineError`.
- Produces: `export.finalize_output(tmp: Path, out: Path, rc: int, err: str) -> None` (raises
  `PipelineError` on failure, atomically renames on success — cut.py imports it);
  export filenames `clip_{n}_{slug}_{start_ms}_{end_ms}.mp4`;
  `main._zipable_files(clips: list[dict], folder: Path) -> list[Path]`.

- [ ] **Step 1: Write the failing tests**

```python
# backend/pipeline/tests/test_output_safety.py
"""Atomic ffmpeg output finalization, range-keyed export names, zip guard. Offline."""
from __future__ import annotations

from pathlib import Path

import pytest

from backend.errors import PipelineError
from backend.main import _zipable_files
from backend.pipeline.export import _export_fname, finalize_output


# ── fix 3: atomic finalize ────────────────────────────────────────────────────
def test_finalize_success_renames(tmp_path):
    tmp, out = tmp_path / "c.tmp.mp4", tmp_path / "c.mp4"
    tmp.write_bytes(b"fake-mp4-bytes")
    finalize_output(tmp, out, rc=0, err="")
    assert out.exists() and not tmp.exists()
    assert out.read_bytes() == b"fake-mp4-bytes"


def test_finalize_failure_cleans_tmp_and_raises(tmp_path):
    tmp, out = tmp_path / "c.tmp.mp4", tmp_path / "c.mp4"
    tmp.write_bytes(b"partial")
    with pytest.raises(PipelineError):
        finalize_output(tmp, out, rc=1, err="boom\nlast line")
    assert not tmp.exists() and not out.exists()


def test_finalize_zero_byte_output_is_failure(tmp_path):
    tmp, out = tmp_path / "c.tmp.mp4", tmp_path / "c.mp4"
    tmp.write_bytes(b"")
    with pytest.raises(PipelineError):
        finalize_output(tmp, out, rc=0, err="")
    assert not tmp.exists() and not out.exists()


# ── fix 4: range-keyed export name ───────────────────────────────────────────
def test_export_fname_embeds_range():
    assert _export_fname(2, "definition", 12.345, 67.89) == "clip_2_definition_12345_67890.mp4"
    assert _export_fname(2, "definition", 12.345, 68.0) != _export_fname(2, "definition", 12.345, 67.89)


# ── fix 6: zip guard ─────────────────────────────────────────────────────────
def test_zipable_files_skips_none_and_missing(tmp_path):
    real = tmp_path / "clip_1_other.mp4"
    real.write_bytes(b"x")
    clips = [{"path": None},                                # embed mode
             {"path": "/clips/v/clip_1_other.mp4"},         # exists
             {"path": "/clips/v/clip_9_gone.mp4"}]          # missing on disk
    files = _zipable_files(clips, tmp_path)
    assert files == [real]


def test_zipable_files_empty_for_embed_job(tmp_path):
    assert _zipable_files([{"path": None}, {"path": None}], tmp_path) == []
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/tests/test_output_safety.py -q`
Expected: FAIL — ImportError on `finalize_output`, `_export_fname`, `_zipable_files`.

- [ ] **Step 3: Implement**

a) `backend/pipeline/export.py` — add (module level, near `_slug`):

```python
def _export_fname(n: int, facet: str, start: float, end: float) -> str:
    """Range-keyed name: different boundaries → different file (stale cache can't serve)."""
    return f"clip_{n}_{_slug(facet)}_{int(round(start * 1000))}_{int(round(end * 1000))}.mp4"


def finalize_output(tmp: Path, out: Path, rc: int, err: str) -> None:
    """Atomically promote an ffmpeg output: rename tmp→out only on success with real bytes;
    otherwise remove the partial tmp and raise. A crash/failure can never poison the cache."""
    if rc == 0 and tmp.exists() and tmp.stat().st_size > 0:
        tmp.replace(out)
        return
    tmp.unlink(missing_ok=True)
    tail = err.strip().splitlines()
    raise PipelineError(f"Clip cut failed: {tail[-1] if tail else rc}")
```

(ensure `from pathlib import Path` is imported.)

b) `export_clip` — replace the fname/cache/cut block:

```python
    fname = _export_fname(n, facet, float(start), float(end))
    out = out_dir / fname
    served = f"/clips/{video_id}/{fname}"
    if out.exists() and out.stat().st_size > 0:
        return {"path": served}

    src = await asyncio.to_thread(_ensure_source, url, video_id, int(res))

    dur = max(0.1, round(float(end) - float(start), 3))
    tmp = out.with_name(out.stem + ".tmp.mp4")
    proc = await asyncio.create_subprocess_exec(
        *build_cmd(str(src), float(start), dur, tmp),
        stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE,
    )
    err = (await proc.stderr.read()).decode(errors="ignore") if proc.stderr else ""
    rc = await proc.wait()
    finalize_output(tmp, out, rc, err)
    return {"path": served}
```

c) `backend/pipeline/cut.py::one()` — route through the same helper: cut to a tmp name and
finalize (import `from .export import finalize_output` — if that would create a circular
import because export.py imports from cut.py, put `finalize_output`+`_export_fname` in cut.py
instead and have export.py import from cut.py; keep ONE definition, wherever the import
direction already flows):

```python
        out = out_dir / fname
        tmp = out.with_name(out.stem + ".tmp.mp4")
        ...
            proc = await asyncio.create_subprocess_exec(
                *build_cmd(src, start, dur, tmp),
                ...
            )
            ...
            rc = await proc.wait()

        if rc != 0 or not tmp.exists() or tmp.stat().st_size == 0:
            tmp.unlink(missing_ok=True)
            tail = err.strip().splitlines()
            raise PipelineError(f"ffmpeg failed on clip {i + 1}: {tail[-1] if tail else rc}")
        tmp.replace(out)
```

(cut.py's failure message format is preserved; using inline finalize logic there is acceptable
if the import direction makes the shared helper awkward — but prefer the shared helper.)

d) `backend/main.py` — add near the top (after imports):

```python
def _zipable_files(clips: list[dict], folder: Path) -> list[Path]:
    """Existing rendered files for a job — embed-mode (path=None) and missing files skipped."""
    out: list[Path] = []
    for c in clips or []:
        p = c.get("path")
        if not p:
            continue
        fp = folder / Path(p).name
        if fp.exists():
            out.append(fp)
    return out
```

and `download_zip` becomes:

```python
@app.get("/jobs/{job_id}/zip")
def download_zip(job_id: str):
    job = registry.get(job_id)
    if not job or job.status != Status.DONE or not job.video_id:
        raise HTTPException(404, "No finished job to zip")
    folder = config.OUTPUT_DIR / job.video_id
    files = _zipable_files(job.clips, folder)
    has_manifest = (folder / "clips.json").exists()
    if not files and not has_manifest:
        raise HTTPException(409, "No rendered clips to zip — use output_mode=cut or export clips first")

    def gen():
        from zipstream import ZipStream
        zs = ZipStream(sized=False)
        for fp in files:
            zs.add_path(fp, fp.name)
        if has_manifest:
            zs.add_path(folder / "clips.json", "clips.json")
        yield from zs
```

(the existing `StreamingResponse(...)` return stays as-is.)

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/tests/ -q`
Expected: 12 passed.

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: 145 passed, compile clean.

---


"""integrity helpers: truthful unit_ids, Part-B merge, Rejection. Pure/offline."""
from __future__ import annotations

import pytest

from backend.pipeline.assemble.integrity import Rejection, merge_partb, true_contents

from .conftest import mini_sents, mini_units


def _setup(n=6):
    sents = mini_sents(n)
    units = mini_units(sents)          # unit i ↔ sentence i, ids u0000..u000{n-1}
    return sents, units


# ── true_contents ─────────────────────────────────────────────────────────────
def test_absorbs_spanned_units_time_ordered():
    sents, units = _setup()
    ids, ref = true_contents(["u0000", "u0003"], [], units, 0, 3)
    assert ids == ["u0000", "u0001", "u0002", "u0003"]   # gap units absorbed, ordered
    assert ref == []


def test_drops_referential_now_inside_span():
    sents, units = _setup()
    ids, ref = true_contents(["u0000", "u0002"], [("u0001", "prerequisite"), ("u0005", "prerequisite")],
                             units, 0, 2)
    assert "u0001" in ids                                # was referential, now in-span → absorbed
    assert ref == [("u0005", "prerequisite")]            # outside span → untouched


def test_idempotent():
    sents, units = _setup()
    once = true_contents(["u0000", "u0003"], [("u0005", "x")], units, 0, 3)
    twice = true_contents(once[0], once[1], units, 0, 3)
    assert once == twice


def test_partial_overlap_unit_not_absorbed():
    sents, units = _setup()
    # unit u0003 spans sentence 3 only; span [0,2] must not absorb it
    ids, _ = true_contents(["u0000"], [], units, 0, 2)
    assert "u0003" not in ids


# ── merge_partb ───────────────────────────────────────────────────────────────
def _spec(cand_id, s0, s1, sents, *, fq=0.5, facet="other", **extra):
    d = {"cand_id": cand_id, "facet": facet, "role": "explanation", "title": f"t-{cand_id}",
         "anchor_id": "u0000", "unit_ids": [f"u{i:04d}" for i in range(s0, s1 + 1)],
         "referential": [], "start": sents[s0].start, "end": sents[s1].end,
         "cut_end": sents[s1].end, "sentence_start_idx": s0, "sentence_end_idx": s1,
         "score": fq, "final_quality": fq, "warnings": ("w_a",) if cand_id == "a" else ("w_b",),
         "judge_error": False, "truncated": False, "context_card": ""}
    d.update(extra)
    return d


def test_merge_unions_span_ids_referential_warnings():
    sents, units = _setup()
    a = _spec("a", 0, 2, sents, fq=0.9, referential=[("u0005", "prerequisite")])
    b = _spec("b", 2, 4, sents, fq=0.4)
    m = merge_partb(a, b, units, sents)
    assert m["sentence_start_idx"] == 0 and m["sentence_end_idx"] == 4
    assert m["start"] == sents[0].start and m["end"] == sents[4].end
    assert m["unit_ids"] == [f"u{i:04d}" for i in range(5)]      # union + absorption
    assert m["referential"] == [("u0005", "prerequisite")]        # still outside span
    assert set(m["warnings"]) >= {"w_a", "w_b", "merged_overlap"}
    assert m["merged"] is True
    assert m["title"] == "t-a"                                    # winner metadata (higher fq)


def test_merge_ors_flags_and_keeps_winner_metadata():
    sents, units = _setup()
    a = _spec("a", 0, 1, sents, fq=0.3, judge_error=True)
    b = _spec("b", 1, 2, sents, fq=0.8, truncated=True)
    m = merge_partb(a, b, units, sents)
    assert m["judge_error"] is True and m["truncated"] is True    # OR'd
    assert m["title"] == "t-b"                                    # b wins on final_quality


def test_merge_without_units_skips_absorption():
    sents, _ = _setup()
    a = _spec("a", 0, 0, sents, fq=0.9)
    b = _spec("b", 3, 3, sents, fq=0.1)
    m = merge_partb(a, b, None, sents)
    assert m["unit_ids"] == ["u0000", "u0003"]                    # union only, no sweep


# ── Rejection ─────────────────────────────────────────────────────────────────
def test_rejection_dataclass_shape():
    r = Rejection(cand_id="c1", title="t", role="claim", stage="dedupe",
                  reason="overlap loser to c0", score=0.4, failure_kinds=["off_topic"],
                  final_quality=0.3, start=1.0, end=2.0)
    assert r.stage == "dedupe" and r.failure_kinds == ["off_topic"]


# ── truthful ids at build/repair + repair rejection ──────────────────────────
import threading

import backend.llm as llm_mod
from backend.pipeline.assemble.graph import Graph
from backend.pipeline.assemble.types import Candidate
from backend.pipeline.assemble.validate import JudgeVerdict, expand_candidate, validate_and_repair

from .conftest import FakeAdapter


def test_expand_candidate_emits_true_contents():
    sents, units = _setup()
    units_by_id = {u.unit_id: u for u in units}
    cand = Candidate(cand_id="c0", anchor_id="u0003", role="explanation", facet="other",
                     title="t", reason="r", unit_ids=["u0003"],
                     referential=[("u0000", "prerequisite")], i_start=3, i_end=3,
                     start=sents[3].start, end=sents[3].end)
    verdict = JudgeVerdict(prerequisites_satisfied=False, score_10=3)
    grown = expand_candidate(cand, verdict, Graph([], units), units, units_by_id,
                             {}, sents, max_span_s=999.0)
    assert grown is not None
    # u0000 pulled in → span [0,3] → u0001/u0002 absorbed, referential emptied
    assert grown.unit_ids == ["u0000", "u0001", "u0002", "u0003"]
    assert grown.referential == []


def test_repair_drop_returns_rejection_with_last_verdict(monkeypatch):
    from backend import config
    monkeypatch.setattr(config, "JUDGE_MODEL", "")
    monkeypatch.setattr(config, "JUDGE_PROVIDER", "same")

    def bad_verdict(*a, **kw):     # judged, failing, unrepairable (no targets: refs fine, topic bad)
        return JudgeVerdict(reasoning="bad", score_10=2, understandable=False,
                            topic_identifiable=False, purpose_identifiable=False)
    monkeypatch.setattr(llm_mod, "llm_json", bad_verdict)

    sents, units = _setup()
    units_by_id = {u.unit_id: u for u in units}
    cand = Candidate(cand_id="c0", anchor_id="u0000", role="explanation", facet="other",
                     title="T", reason="r", unit_ids=["u0000"], referential=[],
                     i_start=0, i_end=0, start=sents[0].start, end=sents[0].end)
    kept, rej = validate_and_repair(cand, sents, Graph([], units), units, units_by_id, {},
                                    FakeAdapter(), {}, lambda s, e: "", "topic", {}, threading.Lock())
    assert kept is None
    assert rej is not None and rej.stage == "repair"
    assert rej.score == pytest.approx(0.2)
    assert rej.cand_id == "c0" and rej.title == "T"


def test_repair_keep_returns_no_rejection(monkeypatch):
    from backend import config
    monkeypatch.setattr(config, "JUDGE_MODEL", "")
    monkeypatch.setattr(config, "JUDGE_PROVIDER", "same")
    monkeypatch.setattr(llm_mod, "llm_json",
                        lambda *a, **kw: JudgeVerdict(reasoning="ok", score_10=9, understandable=True))
    sents, units = _setup()
    units_by_id = {u.unit_id: u for u in units}
    cand = Candidate(cand_id="c0", anchor_id="u0000", role="explanation", facet="other",
                     title="t", reason="r", unit_ids=["u0000"], referential=[],
                     i_start=0, i_end=0, start=sents[0].start, end=sents[0].end)
    kept, rej = validate_and_repair(cand, sents, Graph([], units), units, units_by_id, {},
                                    FakeAdapter(), {}, lambda s, e: "", "topic", {}, threading.Lock())
    assert kept is not None and rej is None


# ── Part-B dedupe + snap rejections + mutation warnings ──────────────────────
from backend.pipeline.assemble.boundary_adapt import snap_candidates
from backend.pipeline.refine import _dedupe as refine_dedupe


def _cand(cand_id, s0, s1, sents, *, facet="other", fq=0.5, verdict=None):
    c = Candidate(cand_id=cand_id, anchor_id=f"u{s0:04d}", role="explanation", facet=facet,
                  title=f"t-{cand_id}", reason="r", unit_ids=[f"u{i:04d}" for i in range(s0, s1 + 1)],
                  referential=[], i_start=s0, i_end=s1,
                  start=sents[s0].start, end=sents[s1].end)
    c.final_quality = fq
    c.verdict = verdict or JudgeVerdict(score_10=8, understandable=True)
    return c


_SETTINGS = {"min_clip_duration_s": 1.0, "max_clip_duration_s": 500.0}


def test_same_facet_overlap_merges_and_flags():
    sents, units = _setup(8)
    a = _cand("a", 0, 3, sents, fq=0.9)
    b = _cand("b", 2, 5, sents, fq=0.4)              # overlaps a, same facet
    specs, rejections = snap_candidates([a, b], sents, _SETTINGS, units)
    assert len(specs) == 1 and specs[0]["merged"] is True
    assert specs[0]["sentence_start_idx"] == 0 and specs[0]["sentence_end_idx"] == 5
    assert specs[0]["unit_ids"] == [f"u{i:04d}" for i in range(6)]
    assert "merged_overlap" in specs[0]["warnings"]
    assert rejections == []                           # merge is not a drop


def test_containment_loser_becomes_dedupe_rejection():
    sents, units = _setup(8)
    big = _cand("big", 0, 5, sents, fq=0.9)
    small = _cand("small", 1, 2, sents, fq=0.2)      # contained in big
    specs, rejections = snap_candidates([big, small], sents, _SETTINGS, units)
    assert [s["cand_id"] for s in specs] == ["big"]
    assert len(rejections) == 1
    r = rejections[0]
    assert r.stage == "dedupe" and r.cand_id == "small" and "big" in r.reason


def test_dedupe_partb_matches_refine_on_disjoint_and_containment():
    """Characterization: identical keep decisions as refine._dedupe on non-merge shapes."""
    sents, units = _setup(10)
    disjoint = [_cand("a", 0, 1, sents, fq=0.5), _cand("b", 4, 5, sents, fq=0.5)]
    contained = [_cand("c", 0, 5, sents, fq=0.9), _cand("d", 2, 3, sents, fq=0.1)]
    for group in (disjoint, contained):
        specs, _ = snap_candidates(list(group), sents, _SETTINGS, units)
        legacy_in = [snap_candidates([c], sents, _SETTINGS, units)[0][0] for c in group]
        legacy = refine_dedupe([dict(s) for s in legacy_in], sents, 1.0)
        assert sorted(s["start"] for s in specs) == sorted(c["start"] for c in legacy)


def test_truncated_carried_into_spec():
    sents, units = _setup()
    c = _cand("a", 0, 2, sents)
    c.truncated = True
    specs, _ = snap_candidates([c], sents, _SETTINGS, units)
    assert specs[0]["truncated"] is True


def test_boundary_score_penalizes_mutation_warnings():
    from backend.pipeline.assemble.scoring import boundary_score
    assert boundary_score(["extended_for_min_duration"]) == pytest.approx(0.90)
    assert boundary_score(["trimmed_start"]) == pytest.approx(0.90)
    assert boundary_score(["missing_context_card"]) == pytest.approx(0.90)


def test_snap_one_warns_on_min_duration_extension():
    from backend.pipeline.refine import _snap_one
    sents, _ = _setup(6)                              # each sentence ≈10 s
    clip = _snap_one({"i_start": 0, "i_end": 0, "facet": "other"}, sents,
                     False, 25.0, 0.05, 500.0)        # min_dur 25 s forces extension past s0
    assert clip is not None
    assert "extended_for_min_duration" in clip["warnings"]

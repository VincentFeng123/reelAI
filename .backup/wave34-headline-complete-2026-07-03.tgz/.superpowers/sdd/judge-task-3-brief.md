### Task 3: Eval exclusion + judge_error_rate

**Files:**
- Modify: `backend/eval/metrics.py` (`comprehension`, `judge_failures`)
- Modify: `backend/eval/run_eval.py` (`_measure`)
- Test: `backend/eval/tests/test_judge_metrics.py` (new file in the existing eval tests package)

**Interfaces:**
- Consumes: `verdict.error` (Task 1); `metrics.judge_clip` (module-level import in metrics.py — monkeypatchable as `backend.eval.metrics.judge_clip`).
- Produces: `comprehension(specs, sentences, adapter, topic, threshold=0.7) -> tuple[float, float, int, int]` (mean over judged, rate over judged, n_judged, n_error); `judge_failures` tuples gain a 4th element `error: bool`; `_measure` adds `"judge_error_rate"` and unpacks the 4-tuple.

- [ ] **Step 1: Write the failing test**

```python
# backend/eval/tests/test_judge_metrics.py
"""comprehension() excludes error verdicts; judge_error_rate accounting. Offline."""
from __future__ import annotations

import pytest

import backend.eval.metrics as metrics
from backend.pipeline.assemble.validate import JudgeVerdict


class _Sent:
    def __init__(self, i):
        self.text, self.start, self.end, self.ends_with_period = f"s{i}.", float(i), i + 0.9, True


def _specs(n):
    return [{"sentence_start_idx": 0, "sentence_end_idx": 0, "role": "explanation",
             "context_card": "", "start": 0.0, "end": 1.0} for _ in range(n)]


def test_comprehension_excludes_error_verdicts(monkeypatch):
    verdicts = [JudgeVerdict(score_10=9), JudgeVerdict(error=True), JudgeVerdict(score_10=5)]
    it = iter(verdicts)
    monkeypatch.setattr(metrics, "judge_clip", lambda *a, **kw: next(it))
    mean, rate, n_judged, n_error = metrics.comprehension(_specs(3), [_Sent(0)], None, "t", 0.7)
    assert n_judged == 2 and n_error == 1
    assert mean == pytest.approx((0.9 + 0.5) / 2)
    assert rate == pytest.approx(0.5)                    # 0.9 passes 0.7; 0.5 doesn't


def test_comprehension_all_errors(monkeypatch):
    monkeypatch.setattr(metrics, "judge_clip", lambda *a, **kw: JudgeVerdict(error=True))
    mean, rate, n_judged, n_error = metrics.comprehension(_specs(2), [_Sent(0)], None, "t", 0.7)
    assert (mean, rate, n_judged, n_error) == (0.0, 0.0, 0, 2)


def test_comprehension_empty_specs():
    assert metrics.comprehension([], [], None, "t", 0.7) == (0.0, 0.0, 0, 0)


def test_judge_failures_carries_error_flag(monkeypatch):
    monkeypatch.setattr(metrics, "judge_clip", lambda *a, **kw: JudgeVerdict(error=True))
    rows = metrics.judge_failures(_specs(1), [_Sent(0)], None, "t")
    role, score, fails, error = rows[0]
    assert error is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `.venv/bin/python -m pytest backend/eval/tests/test_judge_metrics.py -q`
Expected: FAIL — `comprehension` returns a 2-tuple; `judge_failures` rows are 3-tuples.

- [ ] **Step 3: Implement**

Replace `metrics.comprehension`:

```python
def comprehension(specs, sentences, adapter, topic, threshold=0.7) -> tuple[float, float, int, int]:
    """(mean judge score, fraction ≥ threshold, n_judged, n_error). Clip-only — the headline.
    Error verdicts (judge outage) are EXCLUDED from mean/rate so outages can never inflate
    comprehension; the caller reports them via judge_error_rate."""
    if not specs:
        return 0.0, 0.0, 0, 0
    scores, ok, n_error = [], 0, 0
    for s in specs:
        v = judge_clip(_clip_text(s, sentences), s.get("role", ""), adapter,
                       visual_summary="", topic=topic, context_card=s.get("context_card", ""))
        if v.error:
            n_error += 1
            continue
        scores.append(v.score)
        ok += 1 if v.score >= threshold else 0
    if not scores:
        return 0.0, 0.0, 0, n_error
    return sum(scores) / len(scores), ok / len(scores), len(scores), n_error
```

In `metrics.judge_failures`, change the append to a 4-tuple:

```python
        out.append((s.get("role", ""), round(v.score, 2), [f.kind for f in v.failure_reasons],
                    bool(v.error)))
```

In `run_eval._measure`: change the comprehension lines to

```python
    mean_score, comp_rate, n_judged, n_err = metrics.comprehension(specs, sents, adapter, topic, thr)
```

add to the metrics dict (after `"mean_judge_score"`):

```python
        "judge_error_rate": round(n_err / (n_judged + n_err), 3) if (n_judged + n_err) else 0.0,
```

and update the `--verbose` loop to unpack 4-tuples:

```python
        for role, score, fails, err in metrics.judge_failures(specs, sents, adapter, topic):
            tag = " UNJUDGED" if err else ""
            print(f"      [{role or '-':20}] score={score}  fails={fails}{tag}")
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/eval/tests/ -q`
Expected: 28 passed (24 prior + 4 new).

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: 105 passed, compile clean.

---


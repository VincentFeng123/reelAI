# W25-E report — atomicity: judge criterion + dedupe union guards

Implementer: task W25-E of `docs/superpowers/plans/2026-07-02-wave-2.5-coverage.md`.
Suite: **531 passing before → 553 passing after (+22 new, 0 modified, 0 removed)**; `compileall backend` clean.
**Post-review fix (see §0 below): 553 → 556 (+3 new regression tests, 0 modified, 0 removed); still 100% green + compileall clean.**

## 0. Review fix — bisection oracle inversion for atomicity-flavored verdicts (`validate.py`)

Adversarial-review finding (important): the trim bisection's known-good predicate was
`is_complete(v) or _hard_core_ok(v)`, but atomicity failures leave the hard core INTACT
**by design** — the very property this task relies on for quote-survivability
(topic/purpose/grounded/refs all stay true on a two-idea clip). So every
still-over-inclusive trial counted as known-good: `lo` advanced past the true boundary
and `lo, best_good = mid, trial` OVERWROTE a judged-COMPLETE atomic sub-span with a
larger, still-failing one. Reviewer repro (now a pinned regression test): mock judge
returns over_inclusion whenever any part of the second idea [u0002,u0003] is in the span
— the old code judged [u0000,u0001] complete, then shipped [u0000,u0001,u0002]
(understandable=False, ship_flagged=False, warnings=(), n_trims=2): mashes trimmed by at
most one lattice unit while satisfying the spec's "n_trims > 0 appears organically".

Fix (both directions the review suggested, using machinery this task added):
- New `_excess_verified(v, clip_text)` (beside `_trim_flavored`): True iff the verdict
  carries an excess-content reason (`_TRIM_KIND_HINTS` family; bare `other` excluded —
  mirrors `_flag_unverified_atomicity`) whose evidence_quote passes deterministic
  containment (`_verify_failure_reasons`, zero LLM). VERIFIED-only on purpose: the judge
  over-flags, so a PHANTOM over_inclusion must not move the bisection (asymmetric-gate
  philosophy — unverified atomicity stays warning-only and never shrinks the ship).
- Bisection lo-advancement predicate split three ways: `is_complete` ⇒ known-good and
  always wins upward; `_hard_core_ok AND NOT _excess_verified` ⇒ lo advances but a
  judged-COMPLETE `best_good` is never overwritten by a merely hard-core-good trial
  (completeness outranks size); otherwise ⇒ known-bad (`hi = mid`). A trial with a
  verified excess reason is now on the known-BAD side even with the hard core intact.
- `trial_text` hoisted (was computed twice for probe_key + now the excess check).

Tests (+3, all offline mock-judge; test_atomicity.py):
- `test_bisection_not_fooled_by_hard_core_intact_over_inclusion` — the reviewer's exact
  repro; ships [u0000,u0001] COMPLETE (not the failing [u0000,u0001,u0002]), n_trims=2.
- `test_bisection_never_overwrites_complete_best_good` — a later hard-core-good
  no-excess partial (legitimate lo-advance) does not replace a complete smaller span.
- `test_bisection_unverified_excess_stays_known_good` — phantom over_inclusion quote:
  trial stays known-good, largest hard-core span ships with `single_idea_unverified`.
All 10 pre-existing trim/bisection tests (test_repair_rework.py) and the 22 W25-E tests
pass unchanged — old bisection scenarios used hard-core-FAILING bad verdicts, so the
narrowed predicate is behavior-preserving for them.

## What changed and why

### 1. Judge gains an atomicity criterion (`backend/pipeline/assemble/validate.py`)
Root cause (spec §9): JUDGE_SYSTEM's three evaluation steps probed ONLY missing context, so
verdicts never carried the kinds `_trim_flavored` requires — the built-and-tested trim
bisection had no input (`n_trims=0`).

- `JUDGE_SYSTEM`: now "Evaluate in four steps" — step 4 asks whether the clip contains MORE
  than one self-contained idea / material off-idea content; a `single_idea` boolean line was
  added to the instructed fields; `over_inclusion` joined the EXACTLY-one-of kind vocabulary;
  the evidence_quote instruction now names the over_inclusion exemplar: *the opening sentence
  of the SECOND idea* (quotable by construction, so it can survive the asymmetric
  verify+confirm kill gate, unlike absence-shaped kinds).
- `JudgeVerdict.single_idea: bool = True` (additive; old cached verdicts stay atomic).
  Deliberately **NOT** added to `_hard_core_ok` or `required_verdict_fields`
  (pre-calibration risk, per spec).
- `FailureReason.kind` vocabulary comment gained `over_inclusion`.
- Routing: `_TRIM_KIND_HINTS` += `("inclusion", "multiple_idea", "atomic")` — matches
  `over_inclusion` / `over-inclusion` / `overinclusion` / `multiple_ideas` / `not_atomic` /
  `atomicity` after `_norm_kind`. None can collide with the exact-equality `'other'` check
  (`_norm_kind("over_inclusion") != "other"`; `"another"` does not route — pinned by test).
- Warning-only semantics: new `_flag_unverified_atomicity(cand)` — `single_idea=False`
  whose verdict carries no VERIFIED excess-content (trim-hint-family) reason adds a
  `single_idea_unverified` warning and nothing else. Wired into `_attach_judge_stats`
  (every keep path) and the terminal flagged path (which bypasses `_attach_judge_stats`).
  It can never gate or kill; `unverified_kill = 0` is preserved by construction.

### 2. Same-facet dedupe union guards (`backend/pipeline/assemble/boundary_adapt.py`)
Root cause (spec §10): every worked-example-family role shares facet `worked_example`, so
DISTINCT problems that merely touch were union-merged (qP arcs 2+4+5 → one [382,480] mash);
unions had NO max-duration re-check (kinematics arc_1+arc_2 would union to 264s > 240s cap).

- New `_arc_provenance(spec)` (arc_id + W25-D `arc_ids` union) and `_union_guard(a, b,
  units_by_id, max_dur)`. The same-facet union at the old :140-148 now runs only when the
  guard returns None; guarded pairs fall through to the existing cross-facet
  trim/keep-both path (so nothing dies that didn't before). Guards:
  (a) both sides carry differing non-empty arc provenance;
  (b) their unit `node_id` sets are both non-empty and disjoint;
  (c) both sides are contract-complete (`contract_coverage == 1.0`) with `hard_gates_ok`;
  (d) the union span would exceed `max_clip_duration_s` (threaded as a new
  `max_dur` kwarg on `_dedupe_partb`, internal-only callee).

### 3. Node-aware min-duration snap direction (`backend/pipeline/refine.py` + boundary_adapt)
Root cause: the min-duration snap extended FORWARD only, into the next event's units
(2s practice prompts swallowed their answers), manufacturing overlaps.

- `snap_candidates` computes the anchor's topic-node time hull from the units sharing the
  anchor's `node_id` and threads it into the boundary input as `node_span` (Part B only —
  the legacy fast path never sets it, so `refine_and_snap` behavior is unchanged).
- `_snap_one`'s min-duration loop: forward stays the default; when BOTH directions are
  available and the forward boundary would leave `node_span` while the previous sentence
  start stays inside it, the START extends backward instead. Same
  `extended_for_min_duration` warning either way (scoring/eval consumers unchanged).

## Tests (all offline, mock judge / pure functions)
New file `backend/pipeline/assemble/tests/test_atomicity.py` — 22 tests (+3 post-review, §0):
- schema/prompt wiring (single_idea default, four steps, over_inclusion vocabulary,
  SECOND-idea quote instruction);
- routing vocabulary (+ 'other'-collision negative, absence kinds still grow,
  over_inclusion produces zero grow targets);
- trim bisection reachable via an over_inclusion verdict (`n_trims >= 1` organically,
  second idea trimmed off, ships clean);
- warning-only single_idea (no verified reason → `single_idea_unverified`, verified
  reason → no warning, terminal gate → ships flagged, never killed);
- each union guard + its control (arc provenance incl. W25-D `arc_ids`, disjoint vs
  shared topic nodes, both-contract-complete vs one-incomplete, oversized union vs
  under-cap), pure `_union_guard` reasons, and an end-to-end qP-mash-shape test
  (three touching arcs ship as three clips through `snap_candidates`);
- snap direction preference (backward when forward leaves the node, forward when inside,
  forward when both leave, forward without node info — legacy pinned, plus end-to-end
  node_span threading with `true_contents` refresh).

## Files changed
- `backend/pipeline/assemble/validate.py` (snapshot in `.superpowers/sdd/snap-w25-E/`)
- `backend/pipeline/assemble/boundary_adapt.py` (snapshot)
- `backend/pipeline/refine.py` (snapshot)
- `backend/pipeline/assemble/tests/test_atomicity.py` (NEW)

## Deviations
- None from the spec's W25-E section. No existing test needed changing (the spec-governs
  clause was not exercised).
- Interpretation notes (within spec latitude):
  - "single_idea=False without a verified reason ⇒ warning only" implemented as the
    warning string `single_idea_unverified`; "verified reason" = a failure reason whose
    kind is in the excess-content (`_TRIM_KIND_HINTS`) family AND whose evidence_quote
    passed deterministic containment. Bare verified `other` reasons do not count (they
    don't demonstrate a second idea).
  - The anchor's "topic node" span at snap time is the time hull of units sharing the
    anchor's `node_id` (the ContentMap is not threaded into `snap_candidates`; the unit
    hull is the same partition). The plan's "node/arc" was implemented as node-only, per
    the task instruction's wording.
  - Guard (a) blocks on `provenance sets non-empty on both sides AND unequal`; two halves
    of the SAME arc still union (control-tested).

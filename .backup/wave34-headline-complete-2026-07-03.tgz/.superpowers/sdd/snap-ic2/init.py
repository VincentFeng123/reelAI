"""Topic-dependent clip assembly (spec §6–9, §7B–C).

assemble_clips turns a cached Structure + a search topic into ordered, self-contained
clip specs: anchor selection → context closure → clip-only judge + repair → boundary
snapping (reusing the existing code) → quality filter → context cards → chronological
sequencing. Returns (clips_spec, notes); the orchestrator applies the optional precise
Whisper boundary pass and builds the final embed/cut clip dicts.
"""
from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Optional

from ... import config
from ..sentences import Sentence
from ..understand.models import Structure
from . import scoring
from .boundary_adapt import snap_candidates
from .candidates import build_candidate, score_topic_relevance, select_anchors
from .context_card import generate_context_card
from .graph import Graph
from .sequence import sequence_clips
from .validate import validate_and_repair

ProgressCb = Optional[Callable[[float, str], None]]


def _introducer_index(units) -> dict[str, list[str]]:
    idx: dict[str, list[str]] = {}
    for u in units:
        for c in u.concepts_introduced:
            idx.setdefault(c, []).append(u.unit_id)
    return idx


def assemble_clips(structure: Structure, topic: str, sentences: list[Sentence], url: str,
                   video_id: str, settings: dict, adapter,
                   progress: ProgressCb = None) -> tuple[list[dict], str]:
    def emit(frac: float, msg: str = "") -> None:
        if progress:
            progress(max(0.0, min(1.0, frac)), msg)

    units = structure.units
    if not units or not sentences:
        return [], "No usable structure was built for this video."
    units_by_id = structure.units_by_id()
    graph = Graph(structure.dependencies.edges, units)
    introducers = _introducer_index(units)

    # 1. topic relevance -----------------------------------------------------
    emit(0.05, "Scoring topic relevance…")
    relevance = score_topic_relevance(units, topic, settings, lambda f, m="": emit(0.05 + 0.10 * f, m))

    # 2. anchors -------------------------------------------------------------
    anchors = select_anchors(units, relevance, adapter, settings)
    if not anchors:
        return [], f"“{topic}” isn’t covered enough in this video to clip." if topic \
            else "No clip-worthy moments were found in this video."

    # 3. assemble + validate/repair each candidate (judged concurrently) -----
    cache: dict = {}
    cache_lock = threading.Lock()

    def _assemble_one(anchor):
        cand = build_candidate(anchor, graph, adapter, units, units_by_id, sentences, relevance, settings)
        if cand is None:
            return None
        cand = validate_and_repair(cand, sentences, graph, units, units_by_id, introducers, adapter,
                                   settings, structure.visual_summary, topic, cache, cache_lock)
        if cand is None:
            return None
        cand.completeness_score = scoring.completeness_score(cand.verdict, cand.role, adapter)
        cand.grounding_score = scoring.grounding_score(cand, units_by_id)
        cand.final_quality = scoring.final_quality(cand)
        return cand

    kept = []
    workers = max(1, min(int(settings.get("judge_workers", config.JUDGE_WORKERS)), len(anchors)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_assemble_one, a) for a in anchors]
        for done, fut in enumerate(as_completed(futures), start=1):
            cand = fut.result()
            if cand is not None:
                kept.append(cand)
            emit(0.15 + 0.60 * done / len(anchors), f"Validating clip {done}/{len(anchors)}")

    if not kept:
        return [], "No self-contained clips could be assembled for this topic."

    # 4. snap boundaries (reuse) --------------------------------------------
    emit(0.80, "Refining boundaries…")
    specs = snap_candidates(kept, sentences, settings)

    # 5. boundary score + quality filter ------------------------------------
    for s in specs:
        s["boundary_score"] = scoring.boundary_score(s.get("warnings"))
        s["final_quality"] = scoring.quality(
            s.get("completeness_score", 0.0), s.get("grounding_score", 0.0),
            s["boundary_score"], s.get("priority", 0.0))
    floor = float(settings.get("quality_floor", 0.45))
    specs = scoring.drop_weak(specs, floor)
    specs.sort(key=lambda s: s["final_quality"], reverse=True)
    specs = specs[: int(settings.get("max_clips", config.DEFAULTS["max_clips"]))]

    if not specs:
        return [], "Clips were found but none were complete enough to keep."

    # 6. context cards -------------------------------------------------------
    emit(0.90, "Writing context cards…")
    for s in specs:
        s["context_card"] = generate_context_card(s, units_by_id, adapter, topic)

    # 7. chronological sequence + prerequisite hints ------------------------
    specs = sequence_clips(specs, graph)
    emit(1.0, f"Assembled {len(specs)} clip(s)")

    notes = f"{len(specs)} clip(s) about “{topic}”." if topic else f"{len(specs)} clip(s)."
    return specs, notes

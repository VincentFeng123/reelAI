"""integrity helpers: truthful unit_ids, Part-B merge, Rejection. Pure/offline."""
from __future__ import annotations

import pytest

from backend.pipeline.assemble.integrity import Rejection, merge_partb, true_contents

from .conftest import mini_sents, mini_units


def _setup(n=6):
    sents = mini_sents(n)
    units = mini_units(sents)          # unit i ↔ sentence i, ids u0000..u000{n-1}
    return sents, units


# ── true_contents ─────────────────────────────────────────────────────────────
def test_absorbs_spanned_units_time_ordered():
    sents, units = _setup()
    ids, ref = true_contents(["u0000", "u0003"], [], units, 0, 3)
    assert ids == ["u0000", "u0001", "u0002", "u0003"]   # gap units absorbed, ordered
    assert ref == []


def test_drops_referential_now_inside_span():
    sents, units = _setup()
    ids, ref = true_contents(["u0000", "u0002"], [("u0001", "prerequisite"), ("u0005", "prerequisite")],
                             units, 0, 2)
    assert "u0001" in ids                                # was referential, now in-span → absorbed
    assert ref == [("u0005", "prerequisite")]            # outside span → untouched


def test_idempotent():
    sents, units = _setup()
    once = true_contents(["u0000", "u0003"], [("u0005", "x")], units, 0, 3)
    twice = true_contents(once[0], once[1], units, 0, 3)
    assert once == twice


def test_partial_overlap_unit_not_absorbed():
    sents, units = _setup()
    # unit u0003 spans sentence 3 only; span [0,2] must not absorb it
    ids, _ = true_contents(["u0000"], [], units, 0, 2)
    assert "u0003" not in ids


# ── merge_partb ───────────────────────────────────────────────────────────────
def _spec(cand_id, s0, s1, sents, *, fq=0.5, facet="other", **extra):
    d = {"cand_id": cand_id, "facet": facet, "role": "explanation", "title": f"t-{cand_id}",
         "anchor_id": "u0000", "unit_ids": [f"u{i:04d}" for i in range(s0, s1 + 1)],
         "referential": [], "start": sents[s0].start, "end": sents[s1].end,
         "cut_end": sents[s1].end, "sentence_start_idx": s0, "sentence_end_idx": s1,
         "score": fq, "final_quality": fq, "warnings": ("w_a",) if cand_id == "a" else ("w_b",),
         "judge_error": False, "truncated": False, "context_card": ""}
    d.update(extra)
    return d


def test_merge_unions_span_ids_referential_warnings():
    sents, units = _setup()
    a = _spec("a", 0, 2, sents, fq=0.9, referential=[("u0005", "prerequisite")])
    b = _spec("b", 2, 4, sents, fq=0.4)
    m = merge_partb(a, b, units, sents)
    assert m["sentence_start_idx"] == 0 and m["sentence_end_idx"] == 4
    assert m["start"] == sents[0].start and m["end"] == sents[4].end
    assert m["unit_ids"] == [f"u{i:04d}" for i in range(5)]      # union + absorption
    assert m["referential"] == [("u0005", "prerequisite")]        # still outside span
    assert set(m["warnings"]) >= {"w_a", "w_b", "merged_overlap"}
    assert m["merged"] is True
    assert m["title"] == "t-a"                                    # winner metadata (higher fq)


def test_merge_ors_flags_and_keeps_winner_metadata():
    sents, units = _setup()
    a = _spec("a", 0, 1, sents, fq=0.3, judge_error=True)
    b = _spec("b", 1, 2, sents, fq=0.8, truncated=True)
    m = merge_partb(a, b, units, sents)
    assert m["judge_error"] is True and m["truncated"] is True    # OR'd
    assert m["title"] == "t-b"                                    # b wins on final_quality


def test_merge_without_units_skips_absorption():
    sents, _ = _setup()
    a = _spec("a", 0, 0, sents, fq=0.9)
    b = _spec("b", 3, 3, sents, fq=0.1)
    m = merge_partb(a, b, None, sents)
    assert m["unit_ids"] == ["u0000", "u0003"]                    # union only, no sweep


# ── Rejection ─────────────────────────────────────────────────────────────────
def test_rejection_dataclass_shape():
    r = Rejection(cand_id="c1", title="t", role="claim", stage="dedupe",
                  reason="overlap loser to c0", score=0.4, failure_kinds=["off_topic"],
                  final_quality=0.3, start=1.0, end=2.0)
    assert r.stage == "dedupe" and r.failure_kinds == ["off_topic"]

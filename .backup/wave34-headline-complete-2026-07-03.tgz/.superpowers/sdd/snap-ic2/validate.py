"""Clip-only judge + repair loop (spec §8).

A separate judge sees ONLY a candidate clip's transcript (+ any on-screen summary) and
decides whether a new viewer could understand it in isolation. If not, the repair loop
pulls the specific missing units (unresolved reference / missing prerequisite / missing
outcome) from the graph and re-judges, up to a bounded number of attempts; if it still
fails or would grow too long, the candidate is rejected. The verdict schema doubles as
the eval comprehension scorer.
"""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field, model_validator

from ... import config
from ..sentences import Sentence
from ..understand.models import Unit
from .contracts import check_contract
from .types import Candidate


class FailureReason(BaseModel):
    kind: str = "other"     # unresolved_reference|missing_prerequisite|missing_visual|
                            # missing_problem_statement|missing_reasoning|missing_result|
                            # not_source_grounded|off_topic|other
    detail: str = ""
    missing_concept: Optional[str] = None
    reference_text: Optional[str] = None
    approx_time: Optional[float] = None


class JudgeVerdict(BaseModel):
    reasoning: str = ""      # 2-3 sentence CoT the judge writes BEFORE the verdict fields
    understandable: bool = False
    score: float = 0.0       # normalized 0-1; derived from score_10 when the judge emits it
    score_10: int = 0        # judge emits an integer 1-10; 0 = not emitted (legacy/fallback)
    topic_identifiable: bool = True
    purpose_identifiable: bool = True
    all_references_resolved: bool = True
    prerequisites_satisfied: bool = True
    visuals_sufficient: bool = True
    problem_statement_complete: bool = True
    reasoning_complete: bool = True
    result_complete: bool = True
    source_grounded: bool = True
    failure_reasons: list[FailureReason] = Field(default_factory=list)
    error: bool = False      # judge call failed (set ONLY by the fallback path, never the LLM)

    @model_validator(mode="after")
    def _normalize_score(self):
        if self.score_10 != 0:     # 0 = sentinel "not emitted"; any other value gets clamped
            self.score = min(max(self.score_10, 1), 10) / 10.0
        return self


JUDGE_SYSTEM = (
    "You are a strict judge of whether a short video clip is SELF-CONTAINED. You see ONLY the "
    "clip's transcript (and any on-screen text), never the surrounding video. Decide whether a "
    "brand-new viewer, watching only this clip, could understand what it is about and follow it "
    "to a complete thought.\n"
    "Evaluate in three steps:\n"
    "1. Identify what the clip is about and why it matters (topic and purpose).\n"
    "2. Hunt for dangling references — 'this', 'that', 'the previous equation' with no antecedent "
    "inside the clip — and for concepts the clip assumes but never introduces (and that are not "
    "common knowledge).\n"
    "3. If the clip is a worked problem, check the question is stated, the reasoning shown, and "
    "the result reached.\n"
    "Score bands for score_10 (integer 1-10):\n"
    "1-2: incomprehensible without the source video. 3-4: major gaps — the topic is unclear OR a "
    "key reference/prerequisite is missing. 5-6: partially followable — topic clear but real gaps "
    "remain. 7-8: fully understandable with minor rough edges. 9-10: flawlessly self-contained.\n"
    "First write `reasoning`: 2-3 sentences applying the steps to THIS clip. Then set every "
    "boolean truthfully and score_10 per the bands:\n"
    "- topic_identifiable / purpose_identifiable: is it clear what this is about and why?\n"
    "- all_references_resolved: no dangling 'this/that/the previous equation' without an antecedent.\n"
    "- prerequisites_satisfied: it doesn't assume a concept it never introduces or that isn't common.\n"
    "- visuals_sufficient: you cannot see the frames — set TRUE unless the transcript explicitly leans "
    "on an unshown, undescribed visual that is essential to follow it.\n"
    "- problem_statement_complete / reasoning_complete / result_complete: for a worked problem, is the "
    "question stated, the reasoning shown, and the result reached? (Set true/NA if not a problem.)\n"
    "- source_grounded: the clip stands on its own words (not obviously mid-argument).\n"
    "Give an overall 'understandable' boolean. For each problem add a failure_reason whose 'kind' "
    "is EXACTLY one of: unresolved_reference, missing_prerequisite, missing_visual, "
    "missing_problem_statement, missing_reasoning, missing_result, not_source_grounded, off_topic, "
    "other — and set missing_concept (for a prerequisite) or reference_text (the dangling phrase) "
    "when relevant. Never set 'error' or 'score' yourself; emit score_10 only. "
    "Output only the structured result."
)


def _clip_text(sentences: list[Sentence], i0: int, i1: int) -> str:
    return " ".join((sentences[i].text or "") for i in range(i0, i1 + 1)).strip()


def judge_clip(clip_text: str, role: str, adapter, visual_summary: str = "",
               topic: str = "", context_card: str = "") -> JudgeVerdict:
    """Judge a clip's self-containedness from ITS OWN text only. Shared by the repair loop
    (Part B) and the eval comprehension metric — same measurement in both places."""
    from ...llm import llm_json
    required = adapter.required_elements(role) if adapter else []
    user = (
        f"TOPIC: {topic or '(general)'}\n"
        f"CLIP ROLE: {role or '(unspecified)'}"
        + (f" (a complete one needs: {', '.join(required)})" if required else "") + "\n"
        + (f"CONTEXT CARD (shown before the clip): {context_card}\n" if context_card else "")
        + f"ON-SCREEN TEXT: {visual_summary or '(none available)'}\n\n"
        f"CLIP TRANSCRIPT:\n{clip_text}\n\n"
        "Judge whether this clip is self-contained."
    )
    # judge on a different model/provider than the authoring passes (self-preference bias)
    jp = config.JUDGE_PROVIDER
    provider = None if jp in ("", "same") else jp
    jm = config.JUDGE_MODEL
    model = jm if (jm and jm != config.GEMINI_MODEL) else None
    try:
        v = llm_json(JUDGE_SYSTEM, user, JudgeVerdict, temperature=0.0, provider=provider, model=model)
        v.error = False                      # the LLM can never self-flag a transport error
        return v
    except Exception:
        if provider is not None or model is not None:  # cross-model judge failed → authoring model
            try:
                v = llm_json(JUDGE_SYSTEM, user, JudgeVerdict, temperature=0.0)
                v.error = False
                return v
            except Exception:
                pass
        # judge unavailable after retries: honest error verdict — never a free pass (was 0.7)
        return JudgeVerdict(error=True, understandable=False, score=0.0,
                            reasoning="judge unavailable",
                            topic_identifiable=False, purpose_identifiable=False,
                            all_references_resolved=False, prerequisites_satisfied=False,
                            source_grounded=False)


def validate_candidate(cand: Candidate, sentences: list[Sentence], adapter,
                       visual_summary: str = "", topic: str = "") -> JudgeVerdict:
    return judge_clip(_clip_text(sentences, cand.i_start, cand.i_end), cand.role, adapter,
                      visual_summary=visual_summary, topic=topic)


def is_complete(v: JudgeVerdict, role: str, adapter, min_score: float) -> bool:
    if v.error:
        return False
    required = adapter.required_verdict_fields(role)
    return v.score >= min_score and all(getattr(v, f, True) for f in required)


def _reindex(unit_ids: list[str], units_by_id: dict[str, Unit], sentences: list[Sentence]):
    units = [units_by_id[u] for u in unit_ids if u in units_by_id]
    i0 = min(u.sentence_range[0] for u in units)
    i1 = max(u.sentence_range[1] for u in units)
    i0 = max(0, min(i0, len(sentences) - 1))
    i1 = max(i0, min(i1, len(sentences) - 1))
    return i0, i1


def _norm_kind(kind: str) -> str:
    """Canonicalize a failure_reason kind for fuzzy matching (the judge free-forms them)."""
    return "".join(c if c.isalnum() else "_" for c in (kind or "").lower())


def expand_candidate(cand: Candidate, verdict: JudgeVerdict, graph, units: list[Unit],
                     units_by_id: dict[str, Unit], introducers: dict[str, list[str]],
                     sentences: list[Sentence], max_span_s: float) -> Optional[Candidate]:
    """Pull the specific missing context for an incomplete verdict. Targeting is driven by the
    verdict's reliable BOOLEAN gates (kind-agnostic), with the free-form failure_reasons[].kind
    used only as an extra hint — the LLM does not emit a fixed kind vocabulary, so booleans are
    the durable signal. Grows the clip greedily nearest-anchor-first within the span cap."""
    order = {u.unit_id: i for i, u in enumerate(units)}
    anchor_i = order.get(cand.anchor_id, 0)
    cur = set(cand.unit_ids)
    targets: set[str] = set()

    def prior_introducer(concept: str) -> Optional[str]:
        lst = introducers.get((concept or "").strip().lower())
        if not lst:
            return None
        prior = [x for x in lst if order.get(x, 0) <= anchor_i]
        return prior[-1] if prior else lst[0]

    def pull_graph(*relations: str) -> None:
        for uid in list(cur):
            for e in graph.needs(uid, relations):
                targets.add(e.target)

    def pull_references() -> None:                          # antecedents for dangling 'this/that/…'
        pull_graph("refers_to", "answers", "requires")
        for uid in list(cur):
            u = units_by_id.get(uid)
            for ref in (u.references if u else []):
                if ref.source_unit:
                    targets.add(ref.source_unit)
        for uid, _rel in cand.referential:                  # far prereqs closure set aside
            targets.add(uid)

    def pull_grounding() -> None:                           # prior same-thread context (not mid-argument)
        pull_graph("continues", "requires", "explains", "defines")
        earliest = min((order[u] for u in cur if u in order), default=anchor_i)
        for u in units:
            if order[u.unit_id] == earliest - 1:            # the immediately preceding unit
                targets.add(u.unit_id)

    def pull_problem() -> None:
        prior = [u for u in units if order[u.unit_id] < anchor_i
                 and u.role in ("example_setup", "problem_givens", "practice_prompt", "setup")]
        if prior:
            targets.add(prior[-1].unit_id)

    def pull_reasoning() -> None:
        for u in units:
            if u.role in ("worked_step", "calculation", "derivation", "procedure") \
                    and abs(order[u.unit_id] - anchor_i) <= 3:
                targets.add(u.unit_id)

    def pull_result() -> None:
        after = [u for u in units if order[u.unit_id] > anchor_i and u.role in ("result", "solution")]
        if after:
            targets.add(after[0].unit_id)

    # 1) targeted hints from the judge's failure_reasons (kind fuzzily normalized) ----------
    for fr in verdict.failure_reasons:
        k = _norm_kind(fr.kind)
        if "prerequisite" in k and fr.missing_concept:
            t = prior_introducer(fr.missing_concept)
            if t:
                targets.add(t)
        elif any(w in k for w in ("reference", "dangling", "antecedent", "pronoun")):
            pull_references()
        elif any(w in k for w in ("problem", "givens", "prompt")):
            pull_problem()
        elif any(w in k for w in ("reasoning", "step", "derivation", "calculation")):
            pull_reasoning()
        elif any(w in k for w in ("result", "outcome", "answer", "conclusion")):
            pull_result()
        elif "visual" in k:
            pull_graph("visually_depends_on")
        elif "ground" in k:
            pull_grounding()

    # 2) boolean-driven fallbacks — the reliable structured signal, kind-agnostic ----------
    if not verdict.all_references_resolved:
        pull_references()
    if not verdict.prerequisites_satisfied:
        for uid, _rel in cand.referential:
            targets.add(uid)
    if not verdict.source_grounded:
        pull_grounding()
    if not verdict.visuals_sufficient:
        pull_graph("visually_depends_on")
    if not verdict.problem_statement_complete:
        pull_problem()
    if not verdict.reasoning_complete:
        pull_reasoning()
    if not verdict.result_complete:
        pull_result()

    # add targets nearest-to-anchor first, staying within the span cap (partial progress is fine)
    from dataclasses import replace
    ordered_targets = sorted((t for t in targets - cur if t in units_by_id),
                             key=lambda t: abs(order.get(t, 0) - anchor_i))
    if not ordered_targets:
        return None
    chosen = set(cur)
    for t in ordered_targets:
        trial = sorted(chosen | {t}, key=lambda x: (units_by_id[x].start, order.get(x, 0)))
        i0, i1 = _reindex(trial, units_by_id, sentences)
        if sentences[i1].end - sentences[i0].start <= max_span_s:
            chosen.add(t)
    if chosen == cur:
        return None
    new_ids = sorted(chosen, key=lambda x: (units_by_id[x].start, order.get(x, 0)))
    i0, i1 = _reindex(new_ids, units_by_id, sentences)
    return replace(cand, unit_ids=new_ids, i_start=i0, i_end=i1,
                   start=sentences[i0].start, end=sentences[i1].end)


def _fill_contract(cand: Candidate, adapter, units: list[Unit], units_by_id: dict[str, Unit],
                   sentences: list[Sentence], max_span_s: float) -> Candidate:
    """Deterministic contract precheck (spec §8): pull the units for any missing REQUIRED
    contract element into the candidate BEFORE spending an LLM judge call. Span-safe and
    never rejects — if an element can't be added within budget the judge still has final say."""
    contract = adapter.contract_for(cand.role)
    if not contract:
        return cand
    order = {u.unit_id: i for i, u in enumerate(units)}
    ai = order.get(cand.anchor_id, 0)
    cur = set(cand.unit_ids)
    for el in contract.elements:
        if el.necessity != "required":
            continue
        present = {units_by_id[uid].role for uid in cur if uid in units_by_id}
        if any(r in present for r in el.roles):
            continue
        want = set(el.roles)
        if el.position == "before":
            picks = [u for u in units if order[u.unit_id] < ai and u.role in want]
            pick = picks[-1] if picks else None          # nearest element before the anchor
        elif el.position == "after":
            picks = [u for u in units if order[u.unit_id] > ai and u.role in want]
            pick = picks[0] if picks else None
        else:
            picks = sorted((u for u in units if u.role in want),
                           key=lambda u: abs(order[u.unit_id] - ai))
            pick = picks[0] if picks else None
        if not pick or pick.unit_id in cur:
            continue
        trial = sorted(cur | {pick.unit_id}, key=lambda x: (units_by_id[x].start, order.get(x, 0)))
        i0, i1 = _reindex(trial, units_by_id, sentences)
        if sentences[i1].end - sentences[i0].start <= max_span_s:
            cur.add(pick.unit_id)
    if cur == set(cand.unit_ids):
        return cand
    new_ids = sorted(cur, key=lambda x: (units_by_id[x].start, order.get(x, 0)))
    i0, i1 = _reindex(new_ids, units_by_id, sentences)
    from dataclasses import replace
    return replace(cand, unit_ids=new_ids, i_start=i0, i_end=i1,
                   start=sentences[i0].start, end=sentences[i1].end)


def validate_and_repair(cand: Candidate, sentences: list[Sentence], graph, units: list[Unit],
                        units_by_id: dict[str, Unit], introducers: dict[str, list[str]], adapter,
                        settings: dict, visual_summary_fn, topic: str,
                        cache: dict, cache_lock=None) -> Optional[Candidate]:
    min_score = float(settings.get("min_comprehension_score", config.JUDGE_MIN_SCORE))
    max_span = float(settings.get("closure_max_span_s", config.CLOSURE_MAX_SPAN_S))
    best: Optional[Candidate] = None

    def _cached(key):
        if cache_lock is not None:
            with cache_lock:
                return cache.get(key)
        return cache.get(key)

    def _store(key, verdict):
        if cache_lock is not None:
            with cache_lock:
                cache[key] = verdict
        else:
            cache[key] = verdict

    for attempt in range(config.JUDGE_MAX_REPAIR + 1):
        # deterministic contract precheck first — pull missing required elements without
        # spending a judge call, so the judge only runs on structurally-complete candidates.
        if not check_contract(cand.unit_ids, cand.role, units_by_id, adapter).ok:
            filled = _fill_contract(cand, adapter, units, units_by_id, sentences, max_span)
            if set(filled.unit_ids) != set(cand.unit_ids):
                cand = filled

        key = frozenset(cand.unit_ids)
        verdict = _cached(key)
        if verdict is None:
            verdict = validate_candidate(cand, sentences, adapter,
                                         visual_summary_fn(cand.start, cand.end), topic)
            if not verdict.error:            # an outage verdict must not poison the cache
                _store(key, verdict)
        cand.verdict = verdict
        cand.attempts = attempt + 1

        if verdict.error:
            return cand                      # ship-but-flag: keep the clip, skip repair entirely

        if is_complete(verdict, cand.role, adapter, min_score):
            return cand
        if best is None or verdict.score > getattr(best.verdict, "score", -1):
            from dataclasses import replace
            best = replace(cand)

        expanded = expand_candidate(cand, verdict, graph, units, units_by_id, introducers,
                                    sentences, max_span)
        if expanded is None or set(expanded.unit_ids) == set(cand.unit_ids):
            break
        cand = expanded

    # keep a best-partial only if it clears the hard core (topic + purpose + grounded + refs)
    if best is not None:
        v = best.verdict
        if v.topic_identifiable and v.purpose_identifiable and v.source_grounded and v.all_references_resolved:
            return best
    return None

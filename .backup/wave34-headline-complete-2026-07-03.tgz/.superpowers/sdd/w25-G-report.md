# W25-G report — eval inventory recall, run artifacts, columns (reconstructed)

NOTE: the W25-G implementer agent completed the code + tests but died on a usage-credits
limit while writing this report and the diff package. This report was reconstructed by the
orchestrator from the on-disk state and verified (suite green, wiring confirmed end-to-end).
W25-G did NOT receive its own adversarial review during the wave — a focused review is being
run post-hoc alongside the whole-change review.

## Delivered (all verified on disk)

1. **inventory_recall** (`metrics.py`): `inventory_coverage(items, specs)` + `inventory_recall`
   — item covered iff one-sided overlap (overlap_s / item_duration) ≥ 0.60 vs any shipped
   spec; NaN when no items (must not read as 0 and drag the aggregate). New golden file
   `backend/eval/golden/qP-9wwRrJbg.json` = {video_id, topics:["kinematics"], inventory: 26
   items} copied from docs/audits/2026-07-02/qP-9wwRrJbg-coverage-gold.json. Wired gold-gated
   in `run_eval._measure`; in `_PREFERRED_KEYS`; `--verbose` lists per-item covered/missed
   with overlap fractions.
2. **Run-artifact persistence** (`pipeline/assemble/artifacts.py`, NEW): `write_run_artifacts`
   writes `work/<id>/runs/<UTC ts>/{plan.json, arcs.json, shipped.json, ledger.json}`,
   collision-suffixed for `--runs N`, fully defensive (`_jsonable` projects dataclass/pydantic/
   set/tuple/NaN; never raises). Called from BOTH orchestrator._run_full (before the empty
   bail, so failed runs still leave a ledger) and eval.run_eval. Producer side wired in
   `candidates.select_anchors_planned` (stats['arcs_verified'] = post-verify survivors,
   stats['plan_proposals'] = validated proposals; [] on the priority/fallback path).
3. **Build-stage ledgering**: candidate builders returning None now emit
   `Rejection(stage="build", …)` (assemble/__init__.py ~176-183); "build" prepended to the
   stage literal comment (integrity.py:19) and to `REJECTION_STAGES` (run_eval.py:82). Integrity
   + integrity-columns tests updated for the added stage (spec governs).
4. **quality_floor → config**: `config.QUALITY_FLOOR` (env-overridable, 0.45) + DEFAULTS
   ["quality_floor"]=None (inherit) + per-job override; the inline 0.45 literal is gone.
5. **New/surfaced eval columns**: inventory_recall, topic_span_coverage (metric from W25-C),
   structure_source, n_min_duration_extensions (metrics.min_duration_extensions counts
   snap-extended specs), index_clamp_events (stat from W25-A), forward_requires_edges
   (metrics.forward_requires_edges over the graph — tripwire, expect 0 after W25-B),
   n_refund_superset_replaced (stat from W25-F), phantom_quotable_rate (phantom rate over
   quotable kinds only). NaN-vs-0 semantics chosen per spec (NaN excludes a video from that
   aggregate; counts that default to 0 count it).

## Out-of-brief changes (justified plumbing for the named `phantom_quotable_rate` column)
- `types.Candidate` gains `verified_kinds`/`unverified_kinds` tuples; `validate.py`
  `_attach_judge_stats` + terminal gate populate them (WHICH kinds passed/failed evidence
  containment); `boundary_adapt.candidate_to_boundary_input` threads them onto the spec so
  `metrics.phantom_quotable_rate` can filter to quotable kinds (off_topic / over_inclusion /
  not_source_grounded / unresolved_reference). Absence-shaped kinds are unquotable by
  construction and correctly excluded. Minimal, additive, commented.

## Tests
- New: `eval/tests/test_w25g_eval.py` + `pipeline/assemble/tests/test_w25g_artifacts.py`
  (29 tests: inventory_recall math incl. NaN + the 0.60 boundary, golden load, artifact writer
  in a tmp dir, build-stage ledgering, per-column presence/semantics).
- Updated per spec-governs: test_integrity.py + test_integrity_columns.py (added 'build' stage).
- Full suite green at reconstruction: **599 passed**, compileall clean.

## Review outcome (post-hoc review COMPLETED 2026-07-03)

The promised focused review ran as part of the wave's whole-change adversarial review (7 seams →
per-finding adversarial verification; the `eval-columns-artifacts` seam scrutinized W25-G hardest
since it had no per-task review). **W25-G came back correct and invariant-preserving** — the
inventory_recall math (one-sided overlap / ITEM duration, 0.60 threshold — not IoU, not union),
the `phantom_quotable_rate` quotable-only denominator, and the `write_run_artifacts`
error-swallowing were all independently verified sound.

Two W25-G-adjacent findings were adversarially REFUTED:
- "the `build` stage double-ledgers a re-selected failed unit-anchor across refund rounds" —
  proven **unreachable**: `compute_closure` always seeds `cl.unit_ids` with the anchor, and a
  regular anchor's `unit_id` is always in `units_by_id`, so `build_candidate` never returns None
  for a re-selectable unit anchor; arc anchors that can return None are synthetic (`arc_id ∉
  units`) and cannot re-enter the residual. No fix needed.
- a comment nit calling `index_clamp_events` "structure-derived" (it is stats-borne) — no
  behavior; semantically defensible (it counts a stale-structure symptom). No fix needed.

The whole wave's ONE confirmed finding was a **refund superset-REPLACE coverage regression** in
W25-F (not G): eviction gated on the judge hard core but not the quality floor, so a below-floor
superset could evict a shippable sliver and then die at the floor → nothing ships for the span.
Fixed in `assemble/__init__.py` (hoisted `floor` above the refund loop; new `_refund_ship_worthy`
gate) + a mutation-verified regression test. This touched W25-G's turf only insofar as the
`quality_floor` constant it introduced is now computed once and shared.

Test-quality audit (separate agent): Wave 2.5's safety invariants (unverified_kill=0, atomicity
bisection oracle, freshness staleness, inventory 0.60/item-duration, practice-preservation) are
all mutation-resistant. One gap — the `_excess_verified` half of the atomicity oracle was
co-defended in every bisection test — was closed with an isolating test
(`test_bisection_isolates_excess_verified_on_incomplete_prefix`, mutation-verified).

Suite after review fixes: **601 passed**, compileall clean.

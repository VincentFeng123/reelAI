"""Precise boundary refinement with targeted Whisper.

Supadata gives fast but coarse (caption-level) timing. After the LLM picks rough
clip ranges, we transcribe ONLY a small audio window around each boundary with
faster-whisper (word-level timestamps + punctuation), then snap:
  - start → the start of the sentence containing the rough start
  - end   → the end of the nearest period-terminated sentence at/after the rough end

This buys word-level precision for a few seconds of audio per boundary instead of
transcribing the whole video.
"""
from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path
from typing import Callable, Optional

from .. import config
from ..errors import PipelineError
from . import download as download_mod
from .sentences import Sentence, build_sentence_index
from .transcribe import _get_whisper

ProgressCb = Optional[Callable[[float, str], None]]


def _ensure_audio(url: str, video_id: str) -> Path:
    work = config.WORK_DIR / video_id
    work.mkdir(parents=True, exist_ok=True)
    audio = work / "audio.m4a"
    if audio.exists():
        return audio
    video = work / "video.mp4"
    if video.exists():
        download_mod._extract_audio(video, audio)
        return audio
    # audio-only download (fast, not throttled like video)
    import yt_dlp

    opts = {
        "format": "bestaudio/best",
        "outtmpl": str(work / "audio_src.%(ext)s"),
        "quiet": True,
        "no_warnings": True,
        "ffmpeg_location": str(Path(config.FFMPEG_BIN).parent),
        "remote_components": ["ejs:github"],
        "retries": 5,
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url])
    except Exception as e:  # noqa: BLE001
        raise PipelineError(f"Audio download failed: {str(e).strip().splitlines()[-1]}")
    cands = sorted(work.glob("audio_src.*"))
    if not cands:
        raise PipelineError("Audio download produced no file.")
    subprocess.run(
        [config.FFMPEG_BIN, "-nostdin", "-y", "-i", str(cands[0]), "-vn",
         "-ar", str(config.TARGET_AUDIO_SR), "-ac", str(config.TARGET_AUDIO_CH),
         "-c:a", "aac", "-b:a", f"{config.AUDIO_BITRATE_K}k", str(audio)],
        capture_output=True,
    )
    cands[0].unlink(missing_ok=True)
    if not audio.exists():
        raise PipelineError("Audio transcode failed.")
    return audio


def _whisper_window(audio: Path, win_start: float, win_end: float) -> list[Sentence]:
    win_start = max(0.0, win_start)
    win_len = max(1.0, win_end - win_start)
    tmp = Path(tempfile.mkstemp(suffix=".wav", dir=str(audio.parent))[1])
    try:
        subprocess.run(
            [config.FFMPEG_BIN, "-nostdin", "-y", "-ss", f"{win_start:.3f}", "-t", f"{win_len:.3f}",
             "-i", str(audio), "-ar", "16000", "-ac", "1", str(tmp)],
            capture_output=True,
        )
        model = _get_whisper()
        segments, _ = model.transcribe(str(tmp), word_timestamps=True, beam_size=5)
        words, segs = [], []
        for seg in segments:
            segs.append({"start": float(seg.start), "end": float(seg.end), "text": seg.text})
            for w in (seg.words or []):
                words.append({"word": w.word, "start": float(w.start), "end": float(w.end)})
    finally:
        tmp.unlink(missing_ok=True)
    if not words:
        return []
    sents = build_sentence_index({"words": words, "segments": segs})
    for s in sents:  # shift to absolute video time
        s.start += win_start
        s.end += win_start
    return sents


def _pick_start(sents: list[Sentence], rough: float, pad: float) -> float:
    """Latest real sentence-start at/just before the rough start (begin at a thought)."""
    if not sents:
        return rough
    # sents[0] is the window's leading fragment (cut mid-sentence) — drop it.
    starts = [s.start for s in sents[1:]] or [s.start for s in sents]
    before = [x for x in starts if x <= rough + 1.0]
    cand = max(before) if before else min(starts)
    return cand if abs(cand - rough) <= pad else rough


def _pick_end(sents: list[Sentence], rough: float, pad: float, allow_qe: bool) -> float:
    """Earliest period-terminated end at/just after the rough end (complete the thought)."""
    if not sents:
        return rough
    ends = [s.end for s in sents if s.is_valid_end(allow_qe)]
    if not ends:
        return rough
    after = [x for x in ends if x >= rough - 1.0]
    cand = min(after) if after else max(ends)
    return cand if abs(cand - rough) <= pad else rough


def _resolve_overlaps(clips: list[dict], min_dur: float, tail_pad: float) -> list[dict]:
    """After independent boundary snapping, ensure clips don't overlap. Trim a clip's
    start to the previous clip's (period) end — a clean sentence boundary — and drop
    any leftover that's too short."""
    clips = sorted(clips, key=lambda c: c["start"])
    out: list[dict] = []
    last_end = -1e9
    for c in clips:
        c = dict(c)
        if c["start"] < last_end:
            c["start"] = round(last_end, 3)
        if c["end"] - c["start"] < min_dur:
            continue
        c["cut_end"] = round(c["end"] + tail_pad, 3)
        out.append(c)
        last_end = c["end"]
    return out


def refine_clip_boundaries(clips: list[dict], url: str, video_id: str, settings: dict,
                           progress: ProgressCb = None) -> list[dict]:
    allow_qe = bool(settings.get("allow_question_exclaim_ends", False))
    tail_pad = float(settings.get("tail_pad_s", config.DEFAULTS["tail_pad_s"]))
    min_dur = float(settings.get("min_clip_duration_s", config.DEFAULTS["min_clip_duration_s"]))
    pad = config.BOUNDARY_PAD_S
    audio = _ensure_audio(url, video_id)

    out: list[dict] = []
    total = max(1, len(clips))
    for i, c in enumerate(clips):
        s0, e0 = float(c["start"]), float(c["end"])
        try:
            if e0 - s0 <= 2 * pad + 20:   # short clip → one window covers both ends
                w = _whisper_window(audio, s0 - pad, e0 + pad)
                new_start = _pick_start(w, s0, pad)
                new_end = _pick_end(w, e0, pad, allow_qe)
            else:
                new_start = _pick_start(_whisper_window(audio, s0 - pad, s0 + pad), s0, pad)
                new_end = _pick_end(_whisper_window(audio, e0 - pad, e0 + pad), e0, pad, allow_qe)
            if new_end <= new_start:
                new_start, new_end = s0, e0
        except Exception:
            new_start, new_end = s0, e0
        d = dict(c)
        d["start"] = round(new_start, 3)
        d["end"] = round(new_end, 3)
        d["cut_end"] = round(new_end + tail_pad, 3)
        out.append(d)
        if progress:
            progress((i + 1) / total, f"Refining boundary {i + 1}/{len(clips)}")
    return _resolve_overlaps(out, min_dur, tail_pad)

"""Physical boundary refinement (spec §9) — REUSE the existing snapping code.

Validated candidates carry Part-B metadata (role, context_card, scores, unit_ids) that
``refine_and_snap`` would strip when it rebuilds dicts. So we call its internals directly
— ``boundary._snap_one`` (start→sentence-start, end→period, min/max duration, tail pad)
and ``refine._dedupe`` (overlap removal) — and merge the snapped result over the metadata,
preserving every field. The optional targeted-Whisper precise pass
(``boundary.refine_clip_boundaries``) is applied by the orchestrator afterwards.
"""
from __future__ import annotations

from ... import config
from ..sentences import Sentence
from .types import Candidate


def candidate_to_boundary_input(cand: Candidate) -> dict:
    return {
        "i_start": cand.i_start, "i_end": cand.i_end,
        "start": cand.start, "end": cand.end,
        "facet": cand.facet, "reason": cand.reason,
        "score": cand.final_quality, "rel": cand.final_quality,
        # Part-B metadata carried through the snap/dedupe (which preserve dict keys):
        "role": cand.role, "title": cand.title, "cand_id": cand.cand_id, "anchor_id": cand.anchor_id,
        "unit_ids": list(cand.unit_ids), "referential": list(cand.referential),
        "context_card": cand.context_card,
        "completeness_score": cand.completeness_score, "grounding_score": cand.grounding_score,
        "priority": cand.priority,
        "judge_error": bool(getattr(cand.verdict, "error", False)),
    }


def snap_candidates(cands: list[Candidate], sentences: list[Sentence], settings: dict) -> list[dict]:
    from ..refine import _dedupe, _snap_one
    allow_qe = bool(settings.get("allow_question_exclaim_ends", config.DEFAULTS["allow_question_exclaim_ends"]))
    min_dur = float(settings.get("min_clip_duration_s", config.DEFAULTS["min_clip_duration_s"]))
    max_dur = float(settings.get("max_clip_duration_s", config.DEFAULTS["max_clip_duration_s"]))
    tail_pad = float(settings.get("tail_pad_s", config.DEFAULTS["tail_pad_s"]))

    specs: list[dict] = []
    for c in cands:
        b = candidate_to_boundary_input(c)
        snapped = _snap_one(b, sentences, allow_qe, min_dur, tail_pad, max_dur)
        if snapped is None:
            continue
        specs.append({**b, **snapped})     # snapped wins on start/end/cut_end/warnings; metadata preserved
    for s in specs:
        if s.get("judge_error"):   # unjudged (judge outage): user-visible + boundary_score penalty
            s["warnings"] = list(s.get("warnings") or []) + ["unjudged"]
    specs = _dedupe(specs, sentences, min_dur)
    specs.sort(key=lambda s: s["start"])
    return specs

# Task 5: Card Integrity — Extractive Fallback + Missing-Card Warning

## Status
**COMPLETE** — All 3 tests passing; checkpoint clean (130 passed, compileall OK).

## Test Summary
Appended 3 tests to `test_integrity.py`:
- `test_card_llm_failure_falls_back_to_referential_summary` — LLM failure triggers extractive fallback to first referential summary
- `test_card_skips_referential_already_inside_clip` — Filters inlined referential up front; returns "" when no external context exists
- `test_missing_card_warning_appended` — `_card_warning()` appends `"missing_context_card"` only when card empty AND context needed

All 3 tests GREEN after implementation.

## Implementation Details

### context_card.py::generate_context_card
- Filters `spec["referential"]` to exclude units already in `spec["unit_ids"]` (line 44-46)
- LLM call wrapped in try-except; on failure card stays "" (line 56-63)
- Extractive fallback fires when card empty: takes first referential unit's summary verbatim (line 64-69)
- Word cap applied after fallback (line 71-73), ensuring grounded limit on both paths

### assemble/__init__.py
- Added module-level `_card_warning(s)` (line 30-34): checks empty card + needed context (referential or truncated), appends warning if both true
- Step 6 calls `_card_warning()` after generating card (line 177)
- Scores re-derived only for flagged specs (line 178-182): boundary_score and final_quality recalculated when `"missing_context_card"` added

## Files Modified
- `/Users/vincentfeng/Documents/practice/clips/backend/pipeline/assemble/tests/test_integrity.py` (3 tests appended)
- `/Users/vincentfeng/Documents/practice/clips/backend/pipeline/assemble/context_card.py` (referential filtering + fallback)
- `/Users/vincentfeng/Documents/practice/clips/backend/pipeline/assemble/__init__.py` (_card_warning + step 6 integration)

## Concerns
None — fallback logic is grounded by construction (uses unit summary verbatim); warning fires only when needed-and-empty; scores update on state change.

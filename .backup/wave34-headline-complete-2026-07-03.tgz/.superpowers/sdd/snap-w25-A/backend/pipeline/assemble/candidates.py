"""Anchor selection + candidate construction (spec §6, Wave 2 P3).

Two selectors (config.ANCHOR_SELECTOR / settings["anchor_selector"]):

- "priority" — the legacy path (the eval A/B lever): anchors are units whose role is
  clip-worthy (per the adapter) AND relevant to the search topic, ranked by priority
  under the per-video anchor budget. Since Wave 2.5 (Q1b/Q1c) the flat stable sort —
  which resolved large priority ties by list order = video order, front-loading every
  anchor into the video's opening minutes — is a greedy pass that spreads picks across
  content-map nodes and caps any single role at PLAN_ROLE_CAP (the same protection the
  plan path already had).
- "plan" (default) — the model proposes WHAT to extract per video (assemble/plan.py) from
  the actual inventory, with the adapter as a PRIOR; ``enforce_plan`` then does what LLMs
  are bad at deterministically: topic coverage, saturation quotas, arc retention, and the
  hard cap. Detected arcs (understand/arcs.py) BYPASS adapter.is_anchor_role and enter as
  synthetic anchors carrying the arc's terminal role. Plan failure or empty/garbage output
  falls back to the priority sort ("plan-fallback": stderr-logged + degraded note).

Topic relevance is scored by a single LLM pass over unit summaries (no embedding model
needed). Each anchor's context closure is turned into a sentence-anchored candidate using
the units' own sentence ranges (exact — units were built from sentence spans); arc anchors
inline their whole arc hull when it fits the ship cap.
"""
from __future__ import annotations

import math
import sys
from collections import Counter
from dataclasses import dataclass, replace
from typing import Callable, Optional

from pydantic import BaseModel, Field

from ... import config
from ..sentences import Sentence
from ..understand.arcs import ArcCandidate, detect_arcs, verify_arcs
from ..understand.models import Structure, Unit
from .closure import ClosureBudget, compute_closure
from .integrity import true_contents
from .types import Candidate

ProgressCb = Optional[Callable[[float, str], None]]


class RelItem(BaseModel):
    unit_id: str
    score: float = 0.0


class RelevanceLLM(BaseModel):
    items: list[RelItem] = Field(default_factory=list)


_REL_SYSTEM = (
    "You score how relevant each unit of a video is to a viewer's TOPIC. For each unit id, "
    "return a score from 0.0 (unrelated) to 1.0 (squarely about the topic). Judge by the unit's "
    "summary and concepts. Output only the structured result."
)


def score_topic_relevance(units: list[Unit], topic: str, settings: dict,
                          progress: ProgressCb = None) -> tuple[dict[str, float], bool]:
    """(unit_id → 0..1 relevance, degraded). degraded=True means the relevance LLM failed
    (after one retry per batch) and scores are neutral defaults — the topic filter is
    effectively OFF and callers must surface that instead of pretending scores exist."""
    if not topic or not topic.strip():
        return {u.unit_id: 1.0 for u in units}, False
    from ...llm import llm_json
    rel: dict[str, float] = {}
    degraded = False
    B = 120
    batches = [units[i:i + B] for i in range(0, len(units), B)] or [[]]
    for bi, batch in enumerate(batches):
        rows = "\n".join(
            f"{u.unit_id}: {u.summary[:120]}"
            + (f" | concepts: {', '.join((u.concepts_introduced + u.concepts_required)[:6])}"
               if (u.concepts_introduced or u.concepts_required) else "")
            for u in batch
        )
        user = f"TOPIC: {topic}\n\nUNITS:\n{rows}\n\nScore each unit id 0.0–1.0 for relevance to the topic."
        got: dict[str, float] = {}
        for attempt in range(2):                            # one retry on transient failure
            try:
                res = llm_json(_REL_SYSTEM, user, RelevanceLLM, temperature=0.0)
                got = {it.unit_id: max(0.0, min(1.0, float(it.score))) for it in res.items}
                break
            except Exception:
                if attempt == 1:
                    degraded = True                          # batch stays neutral — flag it
        for u in batch:
            rel[u.unit_id] = got.get(u.unit_id, 0.5)   # neutral if the model omitted it
        if progress:
            progress((bi + 1) / len(batches), "Scoring topic relevance")
    return rel, degraded


def compute_anchor_budget(units: list[Unit], content_map, detection, settings: dict, *,
                          adapter=None, relevance: Optional[dict[str, float]] = None) -> int:
    """Q1a content-scaled per-video anchor budget.

    An EXPLICIT settings["max_anchors"] (a number — user dial / test pin) wins outright.
    Otherwise the budget scales with how much anchor-eligible material the video actually
    has: clamp(ceil(n_anchor_eligible / 4) + 4·[detection.density == "high"],
    [MAX_ANCHORS, MAX_ANCHORS_CEIL]). Eligibility is the legacy rule (_anchor_eligible:
    anchor role + priority floor + relevance floor); without an adapter every unit counts
    (conservative overcount — the clamp still bounds it). ``content_map`` is accepted for
    future topic-count-aware scaling (enforce_plan's quota arithmetic already wants
    ~2·n_topics slots) but is not part of the current formula.
    Acceptance arithmetic: 75 eligible + density high → min(ceil(75/4)+4, 32) = 23; a
    small video stays at the floor 12."""
    explicit = settings.get("max_anchors")
    if explicit is not None:
        return max(1, int(explicit))
    floor_cap = int(config.MAX_ANCHORS)
    ceil_cap = max(floor_cap, int(config.MAX_ANCHORS_CEIL))
    rel = relevance if relevance is not None else {u.unit_id: 1.0 for u in units}
    rel_floor = float(settings.get("anchor_rel_floor", config.ANCHOR_REL_FLOOR))
    if adapter is not None:
        n_eligible = sum(1 for u in units if _anchor_eligible(u, rel, adapter, rel_floor))
    else:
        n_eligible = len(units)
    scaled = math.ceil(n_eligible / 4)
    if str(getattr(detection, "density", "") or "").lower() == "high":
        scaled += 4
    return max(floor_cap, min(scaled, ceil_cap))


def topic_matches_subject(topic: str, structure: Structure) -> bool:
    """Q1d relevance bypass predicate: True when the search query IS the video's own
    subject — asking a kinematics lecture for "kinematics" should select everything
    important, not run an LLM relevance pass whose noise re-ranks the whole video.
    Conservative by construction: case-insensitive verbatim containment (query ≥ 4 chars)
    or rapidfuzz token_set_ratio ≥ 85 against the detection rationale, the video title,
    or the content-map root title. Never raises (a bad structure just returns False)."""
    q = " ".join((topic or "").lower().split())
    if len(q) < 4:
        return False
    from rapidfuzz import fuzz
    det = getattr(structure, "detection", None)
    cm = getattr(structure, "content_map", None)
    root_title = ""
    if cm is not None:
        root = next((n for n in cm.nodes if n.node_id == cm.root_id), None)
        root_title = getattr(root, "title", "") if root is not None else ""
    subjects = (getattr(det, "rationale", "") if det is not None else "",
                getattr(structure, "title", ""), root_title)
    for s in subjects:
        s_norm = " ".join((s or "").lower().split())
        if not s_norm:
            continue
        if q in s_norm:
            return True                            # verbatim containment
        if fuzz.token_set_ratio(q, s_norm) >= 85:  # word-order/inflection tolerant
            return True
    return False


def select_anchors(units: list[Unit], relevance: dict[str, float], adapter, settings: dict) -> list[Unit]:
    """The legacy 'priority' selector, upgraded in place (Q1b/Q1c — same eligibility, same
    scoring formula, no longer a flat stable sort):

    - Q1b topic-spread tie-break: a greedy pass picks, at each step, the highest-SCORED
      remaining unit; ties resolve toward the content-map node that has contributed the
      FEWEST already-selected anchors (unknown node "" is never penalized), then time,
      then unit_id. Score stays PRIMARY — node spread only breaks score ties — so a
      strong anchor is never dropped for a weaker one from an unseen node, while the
      stable-sort artifact (a 27-way priority tie resolved by list order putting every
      anchor in the video's opening minutes) still round-robins across nodes.
    - Q1c per-role cap: no single role holds more than PLAN_ROLE_CAP slots — the same
      saturation protection enforce_plan gives the plan path (27 claims ≤ 4 slots here).
    Fully deterministic; the cap is the per-video anchor budget (settings["max_anchors"],
    injected by assemble_clips; None falls back to the MAX_ANCHORS floor)."""
    floor = float(settings.get("anchor_rel_floor", config.ANCHOR_REL_FLOOR))
    cap = int(settings.get("max_anchors") or config.MAX_ANCHORS)
    scored = [(_legacy_anchor_score(u, relevance, adapter), u)
              for u in units if _anchor_eligible(u, relevance, adapter, floor)]
    # deterministic base order: score desc, then time, then unit id
    scored.sort(key=lambda t: (-t[0], t[1].start, t[1].unit_id))
    picked: list[Unit] = []
    node_count: Counter = Counter()
    role_count: Counter = Counter()
    pool = list(scored)
    while pool and len(picked) < cap:
        pool = [t for t in pool if role_count[t[1].role] < config.PLAN_ROLE_CAP]
        if not pool:
            break
        i = min(range(len(pool)),
                key=lambda j: (-pool[j][0],
                               (node_count[pool[j][1].node_id] if pool[j][1].node_id else 0),
                               pool[j][1].start, pool[j][1].unit_id))
        _score, u = pool.pop(i)
        picked.append(u)
        if u.node_id:
            node_count[u.node_id] += 1
        role_count[u.role] += 1
    return picked


# ── Wave 2 P3: plan-driven selection + deterministic enforcement ─────────────────────────

@dataclass
class _Sel:
    """One selected anchor entry during enforcement (anchor unit + optional arc + rank)."""
    anchor: Unit
    arc: Optional[ArcCandidate]
    kind: str                                  # "plan" | "arc" | "coverage"
    rank: int


def _legacy_anchor_score(u: Unit, relevance: dict[str, float], adapter) -> float:
    """EXACTLY the legacy select_anchors scoring formula (shared so coverage additions are
    'best prior-scored' in the same sense the priority path ranks anchors)."""
    rel = relevance.get(u.unit_id, 0.0)
    return adapter.anchor_priority(u.role) * (0.4 + 0.6 * rel) * (0.5 + 0.5 * u.source_confidence)


def _anchor_eligible(u: Unit, relevance: dict[str, float], adapter, floor: float) -> bool:
    """The legacy eligibility gate (anchor role + priority floor + relevance floor)."""
    return (adapter.is_anchor_role(u.role)
            and adapter.anchor_priority(u.role) * 100.0 >= config.ANCHOR_MIN_PRIORITY
            and relevance.get(u.unit_id, 0.0) >= floor)


def _unit_topic_id(u: Unit, topic_nodes) -> str:
    """The content-map topic node a unit belongs to ('' when the map has no topic level)."""
    ids = {n.node_id for n in topic_nodes}
    if u.node_id in ids:
        return u.node_id
    for n in topic_nodes:
        if n.sentence_range[0] <= u.sentence_range[0] <= n.sentence_range[1]:
            return n.node_id
    return ""


def _arc_anchor_unit(arc: ArcCandidate, units_by_id: dict[str, Unit]) -> Optional[Unit]:
    """The synthetic anchor a detected arc enters selection as: the arc's TERMINAL unit,
    re-roled to the arc's terminal role (result/solution — the worked-example contracts)
    and widened to the arc hull, bypassing adapter.is_anchor_role by construction."""
    members = [units_by_id[uid] for uid in arc.unit_ids if uid in units_by_id]
    terminal = units_by_id.get(arc.terminal_id)
    if not members or terminal is None:
        return None
    opener = units_by_id.get(arc.opener_ids[0]) if arc.opener_ids else None
    return terminal.model_copy(update={
        "unit_id": arc.arc_id,
        "role": arc.terminal_role,
        "start": min(u.start for u in members),
        "end": max(u.end for u in members),
        "sentence_range": (min(u.sentence_range[0] for u in members),
                           max(u.sentence_range[1] for u in members)),
        "topic": (opener.topic if opener and opener.topic else terminal.topic),
        "summary": (opener.summary if opener and opener.summary else terminal.summary),
    })


def enforce_plan(proposals, arcs: list[ArcCandidate], structure: Structure, units: list[Unit],
                 relevance: dict[str, float], adapter, settings: dict) -> tuple[list[Unit], dict[str, ArcCandidate]]:
    """Deterministic enforcement over the validated plan (P3c) — the plan is the primary
    selector; this pass guarantees what the LLM can't: (i) topic coverage — every content-
    map topic node with ≥1 anchor-eligible unit contributes ≥1 candidate (a skipped topic
    gets its best prior-scored anchor); (ii) saturation — no topic contributes more than
    ceil(cap/n_topics)+1 anchors, no single role more than PLAN_ROLE_CAP (lowest plan-ranked
    overflow drops); (iii) detected arcs are never dropped by saturation (highest-value
    extraction class; arcs the plan skipped are appended); (iv) the MAX_ANCHORS hard cap is
    preserved. Precedence when (i) and (ii) conflict: COVERAGE WINS — a plan-skipped
    topic's best anchor is added even when its role is already at the PLAN_ROLE_CAP quota
    (deliberate: an uncovered topic is a worse failure than a 5th anchor of one role; only
    the hard cap can still drop it). Returns (anchor units, arc_id → ArcCandidate for the
    synthetic anchors)."""
    cap = int(settings.get("max_anchors") or config.MAX_ANCHORS)   # None → the budget floor
    floor = float(settings.get("anchor_rel_floor", config.ANCHOR_REL_FLOOR))
    units_by_id = {u.unit_id: u for u in units}
    arcs_by_id = {a.arc_id: a for a in arcs}
    topic_nodes = structure.content_map.topics()

    entries: list[_Sel] = []
    planned_arcs: set[str] = set()
    for p in proposals:
        if p.kind == "arc":
            arc = arcs_by_id.get(p.ref_id)
            anchor = _arc_anchor_unit(arc, units_by_id) if arc else None
            if anchor is None:
                continue
            entries.append(_Sel(anchor, arc, "plan", p.rank))
            planned_arcs.add(arc.arc_id)
        else:
            u = units_by_id.get(p.ref_id)
            if u is None:
                continue
            anchor = u if (not p.role or p.role == u.role) else u.model_copy(update={"role": p.role})
            entries.append(_Sel(anchor, None, "plan", p.rank))
    # (iii) arcs the plan skipped are appended — they are the highest-value extraction class
    for arc in arcs:
        if arc.arc_id in planned_arcs:
            continue
        anchor = _arc_anchor_unit(arc, units_by_id)
        if anchor is not None:
            entries.append(_Sel(anchor, arc, "arc", len(entries)))

    def _topics_of(e: _Sel) -> set[str]:
        if e.arc is not None:
            return {t for t in (_unit_topic_id(units_by_id[uid], topic_nodes)
                                for uid in e.arc.unit_ids if uid in units_by_id) if t}
        return {t for t in (_unit_topic_id(e.anchor, topic_nodes),) if t}

    def _home_topic(e: _Sel) -> str:
        if e.arc is not None:
            term = units_by_id.get(e.arc.terminal_id)
            return _unit_topic_id(term, topic_nodes) if term is not None else ""
        return _unit_topic_id(e.anchor, topic_nodes)

    # (ii) saturation in plan-rank order — arcs are exempt (iii) ---------------------------
    topic_quota = (math.ceil(cap / len(topic_nodes)) + 1) if topic_nodes else None
    role_quota = config.PLAN_ROLE_CAP
    kept: list[_Sel] = []
    topic_count: Counter = Counter()
    role_count: Counter = Counter()
    for e in entries:
        home = _home_topic(e)
        if e.arc is None:                      # arcs are never dropped by saturation
            if topic_quota is not None and home and topic_count[home] >= topic_quota:
                continue
            if role_count[e.anchor.role] >= role_quota:
                continue
        if home:
            topic_count[home] += 1
        role_count[e.anchor.role] += 1
        kept.append(e)

    # (i) topic coverage floor — a plan-skipped topic contributes its best prior anchor ----
    covered: set[str] = set()
    for e in kept:
        covered |= _topics_of(e)
    selected_ids = {e.anchor.unit_id for e in kept} \
        | {uid for e in kept if e.arc is not None for uid in e.arc.unit_ids}
    for node in topic_nodes:
        if node.node_id in covered:
            continue
        eligible = [u for u in units
                    if u.unit_id not in selected_ids
                    and _unit_topic_id(u, topic_nodes) == node.node_id
                    and _anchor_eligible(u, relevance, adapter, floor)]
        if not eligible:
            continue                           # nothing anchor-eligible → no floor for it
        best = max(eligible, key=lambda u: (_legacy_anchor_score(u, relevance, adapter), -u.start))
        kept.append(_Sel(best, None, "coverage", len(entries) + len(kept)))
        covered.add(node.node_id)
        selected_ids.add(best.unit_id)

    # (iv) hard cap — drop lowest-ranked plan extras first, then coverage, arcs last -------
    for droppable in (("plan",), ("plan", "coverage"), ("plan", "coverage", "arc")):
        while len(kept) > cap:
            idx = next((i for i in range(len(kept) - 1, -1, -1)
                        if kept[i].kind in droppable and kept[i].arc is None), None)
            if idx is None and "arc" in droppable:
                idx = len(kept) - 1            # all arcs: the cap still wins
            if idx is None:
                break
            kept.pop(idx)
    kept = kept[:cap]

    anchors = [e.anchor for e in kept]
    arc_map = {e.anchor.unit_id: e.arc for e in kept if e.arc is not None}
    return anchors, arc_map


def select_anchors_planned(structure: Structure, units: list[Unit], relevance: dict[str, float],
                           adapter, settings: dict, topic: str, *,
                           stats: Optional[dict] = None) \
        -> tuple[list[Unit], dict[str, ArcCandidate], list[str]]:
    """The 'plan' selector (P3a/b/c/d): detect + optionally verify arcs, ask the model for a
    per-video extraction plan, then deterministically enforce coverage/saturation/caps.
    Plan-call failure or empty/garbage output falls back to the legacy priority sort
    ('plan-fallback') — byte-equivalent anchors, stderr-logged, degraded note appended.
    ``stats`` (optional, additive — I1 eval plumbing) is filled with machine-readable run
    signals: n_arcs_detected (pre-verify detection count) and plan_engine
    ('plan' | 'plan-fallback'). Returns (anchor units, arc_id → ArcCandidate for synthetic
    arc anchors, notes)."""
    from .plan import propose_plan
    if stats is None:
        stats = {}
    # normalize the budget once so every downstream reader (propose_plan's cap,
    # enforce_plan, the fallback select_anchors) sees a concrete number, never None.
    settings = {**settings, "max_anchors": int(settings.get("max_anchors") or config.MAX_ANCHORS)}
    notes: list[str] = []
    units_by_id = {u.unit_id: u for u in units}
    arcs = detect_arcs(units)
    stats["n_arcs_detected"] = len(arcs)       # detection count BEFORE the verify pass
    arcs, arc_note = verify_arcs(arcs, units_by_id, settings)
    if arc_note:
        notes.append(arc_note)
    proposals = None
    try:
        proposals = propose_plan(structure, units, arcs, adapter, topic, settings)
    except Exception as e:
        print(f"[plan] extraction-plan call failed ({e!r}); falling back to priority selection",
              file=sys.stderr)
    if not proposals:                          # failure OR empty/garbage output → fallback
        if proposals is not None:
            print("[plan] extraction plan empty after validation; "
                  "falling back to priority selection", file=sys.stderr)
        notes.append("extraction plan degraded — legacy priority selection used (plan-fallback)")
        stats["plan_engine"] = "plan-fallback"
        return select_anchors(units, relevance, adapter, settings), {}, notes
    anchors, arc_map = enforce_plan(proposals, arcs, structure, units, relevance, adapter, settings)
    if not anchors:
        notes.append("extraction plan degraded — legacy priority selection used (plan-fallback)")
        stats["plan_engine"] = "plan-fallback"
        return select_anchors(units, relevance, adapter, settings), {}, notes
    stats["plan_engine"] = "plan"
    return anchors, arc_map, notes


def build_arc_candidate(arc: ArcCandidate, graph, adapter, units: list[Unit],
                        units_by_id: dict[str, Unit], sentences: list[Sentence],
                        relevance: dict[str, float], settings: dict) -> Optional[Candidate]:
    """Turn a detected arc into a candidate. The arc IS the known-complete extraction, so
    its whole hull is inlined when it fits the ship cap (no closure guesswork). A hull
    that cannot ship (cross-distance practice pair, oversized example) degrades to the
    normal closure build anchored on the terminal unit re-roled to the arc's terminal
    role — near context inlines, far context goes referential (card / watch-first)."""
    max_span = min(float(settings.get("closure_max_span_s", config.CLOSURE_MAX_SPAN_S)),
                   float(settings.get("max_clip_duration_s", config.DEFAULTS["max_clip_duration_s"])))
    members = [units_by_id[uid] for uid in arc.unit_ids if uid in units_by_id]
    terminal = units_by_id.get(arc.terminal_id)
    if not members or terminal is None:
        return None
    i_start = min(u.sentence_range[0] for u in members)
    i_end = max(u.sentence_range[1] for u in members)
    i_start = max(0, min(i_start, len(sentences) - 1))
    i_end = max(i_start, min(i_end, len(sentences) - 1))
    hull_s = float(sentences[i_end].end) - float(sentences[i_start].start)
    opener = units_by_id.get(arc.opener_ids[0]) if arc.opener_ids else None
    if hull_s > max_span:
        # unshippable hull → closure build on the re-roled terminal (real unit id, so the
        # graph/contract machinery and repair-trim protections keep working).
        synth = (terminal if terminal.role == arc.terminal_role
                 else terminal.model_copy(update={"role": arc.terminal_role}))
        cand = build_candidate(synth, graph, adapter, units, units_by_id, sentences,
                               relevance, settings)
        if cand is None:
            return None
        ref = list(cand.referential)
        have = {uid for uid, _rel in ref} | set(cand.unit_ids)
        for uid in arc.opener_ids:             # the paired prompt/setup must surface via card
            if uid not in have:
                ref.append((uid, "answers" if arc.arc_role == "practice_pair" else "prerequisite"))
        return replace(cand, cand_id=f"c_{arc.arc_id}", arc_id=arc.arc_id,
                       referential=ref, truncated=True)
    unit_ids, referential = true_contents([m.unit_id for m in members], [], units, i_start, i_end)
    return Candidate(
        cand_id=f"c_{arc.arc_id}",
        arc_id=arc.arc_id,
        anchor_id=arc.terminal_id,
        role=arc.terminal_role,
        facet=adapter.facet_for(arc.terminal_role),
        title=(opener.topic if opener and opener.topic else terminal.topic)
              or (opener.summary[:60] if opener and opener.summary else terminal.summary[:60]),
        reason=(opener.summary if opener and opener.summary else terminal.summary),
        unit_ids=unit_ids,
        referential=referential,
        i_start=i_start, i_end=i_end,
        start=float(sentences[i_start].start), end=float(sentences[i_end].end),
        relevance=max((relevance.get(m.unit_id, 0.0) for m in members), default=0.0),
        priority=adapter.anchor_priority(arc.terminal_role),
        truncated=False,
    )


def build_candidate(anchor: Unit, graph, adapter, units: list[Unit], units_by_id: dict[str, Unit],
                    sentences: list[Sentence], relevance: dict[str, float], settings: dict) -> Optional[Candidate]:
    # judged text must be shippable: closure span budget can never exceed the ship cap
    budget = ClosureBudget(max_span_s=min(
        float(settings.get("closure_max_span_s", config.CLOSURE_MAX_SPAN_S)),
        float(settings.get("max_clip_duration_s", config.DEFAULTS["max_clip_duration_s"]))))
    cl = compute_closure(anchor, graph, units_by_id, adapter, units, budget)
    inline = [units_by_id[uid] for uid in cl.unit_ids if uid in units_by_id]
    if not inline:
        return None
    i_start = min(u.sentence_range[0] for u in inline)
    i_end = max(u.sentence_range[1] for u in inline)
    i_start = max(0, min(i_start, len(sentences) - 1))
    i_end = max(i_start, min(i_end, len(sentences) - 1))
    unit_ids, referential = true_contents(list(cl.unit_ids), list(cl.referential),
                                          units, i_start, i_end)
    return Candidate(
        cand_id=f"c_{anchor.unit_id}",
        anchor_id=anchor.unit_id,
        role=anchor.role,
        facet=adapter.facet_for(anchor.role),
        title=anchor.topic or (anchor.summary[:60]),
        reason=anchor.summary,
        unit_ids=unit_ids,
        referential=referential,
        i_start=i_start, i_end=i_end,
        start=float(sentences[i_start].start), end=float(sentences[i_end].end),
        relevance=relevance.get(anchor.unit_id, 0.0),
        priority=adapter.anchor_priority(anchor.role),
        truncated=cl.truncated,
    )

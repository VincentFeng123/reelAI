"""Pipeline runner.

Two profiles share transcription and sentence indexing, then diverge:

- ``full`` (default) — the structure-first pipeline: understand the whole video (cached
  per video_id as a Structure), then assemble self-contained clips from that structure
  (anchors → context closure → clip-only judge/repair → boundary snap → context cards →
  chronological order).
- ``fast`` — the legacy single-pass selector (transcript window → snap). Also the
  graceful-degrade target: if the full path raises (missing keys/deps, LLM failure), we
  fall back to fast rather than failing the job.

Clips play from YouTube embeds at full quality; a single clip can be exported to mp4 on
demand. If TRANSCRIBER is a Whisper variant, audio is downloaded first for transcription.
"""
from __future__ import annotations

import asyncio
import math
from concurrent.futures import ThreadPoolExecutor

from . import config
from .errors import PipelineError, friendly_error
from .jobs import Job, ProgressEvent, Status, registry
from .pipeline.boundary import refine_clip_boundaries
from .pipeline.cut import cut_clips
from .pipeline.download import download, extract_video_id
from .pipeline.refine import refine_and_snap
from .pipeline.select import select_segments
from .pipeline.punctuation.service import build_sentences
from .pipeline.transcribe import transcribe, transcribe_supadata


def _scale(lo: float, hi: float, frac: float) -> float:
    return lo + (hi - lo) * max(0.0, min(1.0, frac))


def _embed_url(video_id: str, start: float, end: float) -> str:
    return (
        f"https://www.youtube.com/embed/{video_id}"
        f"?start={int(math.floor(start))}&end={int(math.ceil(end)) + 1}&rel=0"
    )


def _build_embed_clips(clips_spec: list[dict], video_id: str) -> list[dict]:
    """Shape the final clip dicts (contract-preserving) with optional structure fields."""
    clips = []
    for i, c in enumerate(clips_spec):
        start, end = float(c["start"]), float(c["end"])
        seq = int(c.get("sequence_index", i + 1))
        clips.append({
            "n": seq,
            "video_id": video_id,
            "facet": c.get("facet", "other"),
            "reason": c.get("reason", ""),
            "start": round(start, 2),
            "end": round(end, 2),
            "duration": round(end - start, 2),
            "embed_url": _embed_url(video_id, start, end),
            "path": None,
            # optional structure-first fields (frontends ignore unknown keys) --
            "role": c.get("role", ""),
            "title": c.get("title", ""),
            "context_card": c.get("context_card", ""),
            "sequence_index": seq,
            "prerequisite_clips": c.get("prerequisite_clips", []),
            # human-readable per-clip notes (e.g. P4b's 'continues clip N' watch-first cue)
            "notes": list(c.get("notes") or []),
        })
    return clips


async def run_pipeline(job: Job, executor: ThreadPoolExecutor) -> None:
    loop = asyncio.get_running_loop()

    def emit(stage: str, lo: float, hi: float):
        def cb(frac: float, msg: str = "") -> None:
            registry.publish(job, ProgressEvent(stage, _scale(lo, hi, frac), msg))
        return cb

    async def run(fn, *args):
        return await loop.run_in_executor(executor, fn, *args)

    try:
        # ── TRANSCRIBE (shared) ─────────────────────────────────────────────
        if config.TRANSCRIBER == "supadata":
            video_id = extract_video_id(job.url)
            if not video_id:
                return registry.fail(job, "Couldn't read the YouTube video id from that URL.")
            registry.set_meta(job, video_id=video_id)
            registry.publish(job, ProgressEvent("transcribing", 10.0, "Fetching transcript…"))
            transcript = await run(
                transcribe_supadata, job.url, video_id, job.settings, emit("transcribing", 10, 40)
            )
        else:
            registry.publish(job, ProgressEvent("transcribing", 0.0, "Downloading audio…"))
            dl = await run(download, job.url, job.settings, emit("transcribing", 0, 25))
            video_id = dl["video_id"]
            registry.set_meta(job, video_id=video_id, title=dl.get("title", ""))
            transcript = await run(
                transcribe, dl["audio_path"], video_id, job.settings, emit("transcribing", 25, 40)
            )
        transcript.setdefault("title", job.title or "")

        sentences = await run(
            build_sentences, transcript, video_id, job.settings, emit("punctuating", 40, 44))
        if not sentences:
            return registry.fail(job, "Could not build a transcript index for this video.")

        # ── SELECT + ASSEMBLE (profile switch, with graceful degrade) ───────
        profile = str(job.settings.get("analysis_profile", config.ANALYSIS_PROFILE)).lower()
        handled = False
        if profile == "full":
            try:
                await _run_full(job, transcript, video_id, sentences, run, emit)
                handled = True
            except (PipelineError, Exception) as e:  # noqa: BLE001 — degrade, don't fail
                if isinstance(e, asyncio.CancelledError):
                    raise
                registry.publish(job, ProgressEvent(
                    "selecting", 45.0, "Structure pass unavailable — using fast mode…"))
        if not handled:
            await _run_fast(job, transcript, video_id, sentences, run, emit)

    except PipelineError as e:
        registry.fail(job, str(e))
    except asyncio.CancelledError:
        job.status = Status.CANCELLED
        raise
    except Exception as e:  # noqa: BLE001
        registry.fail(job, friendly_error(e))


def _want_multimodal(settings: dict) -> bool:
    """Full-profile + multimodal enabled (per-job setting overrides the config default)."""
    mm = settings.get("multimodal")
    if mm is None:
        mm = config.MULTIMODAL
    return bool(mm) and str(settings.get("analysis_profile", config.ANALYSIS_PROFILE)).lower() == "full"


async def _run_full(job: Job, transcript: dict, video_id: str, sentences, run, emit) -> None:
    """Structure-first path: (cached) understanding → topic-dependent assembly → clips.

    In multimodal mode the video is downloaded and perceived (scenes → keyframes →
    Gemini-vision) before understanding; any failure there degrades to transcript-only
    (staying on the full path, not falling back to fast). ``output_mode="cut"`` renders
    mp4s once a video is available.
    """
    from .adapters import get_adapter, select_adapter
    from .pipeline.assemble import assemble_clips
    from .pipeline.understand import Perception, build_structure, load_structure, save_structure

    settings = job.settings
    want_mm = _want_multimodal(settings)
    want_cut = str(settings.get("output_mode", config.OUTPUT_MODE)).lower() == "cut"
    video_path: str | None = None

    structure = load_structure(video_id) if config.STRUCTURE_CACHE else None
    if structure is None or not structure.units:
        # ── perceive (multimodal only; graceful-degrade to transcript-only) ──
        perception = None
        if want_mm:
            try:
                registry.publish(job, ProgressEvent("perceiving", 44.0, "Downloading video for perception…"))
                dl = await run(download, job.url, settings, emit("perceiving", 44, 46))
                video_path = dl.get("video_path")
                if dl.get("title"):
                    registry.set_meta(job, title=dl["title"])
                from .pipeline.understand.perceive import perceive
                registry.publish(job, ProgressEvent("perceiving", 46.0, "Reading on-screen content…"))
                perception = await run(
                    perceive, video_path, video_id, transcript, sentences,
                    settings, emit("perceiving", 46, 55), dl.get("audio_path"),
                )
            except Exception:
                # degrade to transcript-only (stay full), but record that perception was attempted
                # and failed so /health and Structure.degraded reflect it.
                perception = Perception(video_id=video_id, degraded=["perception"])

        registry.publish(job, ProgressEvent("segmenting", 55.0, "Understanding the video…"))
        adapter, detection = await run(select_adapter, transcript, settings)
        structure = await run(
            build_structure, video_id, transcript, sentences, adapter, detection,
            settings, emit("segmenting", 55, 72), perception,
        )
        if not structure.units:
            raise PipelineError("No structure could be built from this transcript.")
        if config.STRUCTURE_CACHE:
            save_structure(structure)
    else:
        adapter = get_adapter(structure.detection.domain)

    # need the source video to cut mp4s even when the structure came from cache
    if want_cut and not video_path:
        try:
            dl = await run(download, job.url, settings, emit("perceiving", 55, 58))
            video_path = dl.get("video_path")
        except Exception:
            video_path = None

    registry.publish(job, ProgressEvent("assembling", 72.0, "Assembling self-contained clips…"))
    clips_spec, notes, rejections = await run(
        assemble_clips, structure, job.topic, sentences, job.url, video_id,
        settings, adapter, emit("assembling", 72, 90),
    )
    if rejections:
        registry.publish(job, ProgressEvent(
            "assembling", 90.0, f"{len(rejections)} candidate(s) dropped ({', '.join(sorted({r.stage for r in rejections}))})"))
    if not clips_spec:
        return registry.fail(
            job, notes or f"“{job.topic}” isn’t covered enough in this video to clip.", notes=notes)

    if config.PRECISE_BOUNDARIES and transcript.get("source") == "supadata":
        registry.publish(job, ProgressEvent("refining", 90.0, "Refining boundaries with Whisper…"))
        clips_spec = await run(
            refine_clip_boundaries, clips_spec, job.url, video_id, settings, emit("refining", 90, 96))

    clips = _build_embed_clips(clips_spec, video_id)
    if want_cut and video_path:
        try:
            registry.publish(job, ProgressEvent("cutting", 96.0, "Cutting clips…"))
            cut_results = await cut_clips(video_path, video_id, clips_spec, settings, emit("cutting", 96, 100))
            by_n = {c["n"]: c for c in cut_results}
            for i, clip in enumerate(clips):                # cut n == segment index + 1
                cr = by_n.get(i + 1)
                if cr and cr.get("path"):
                    clip["path"] = cr["path"]
        except Exception:
            pass                                            # keep embed clips (path stays None)

    registry.finish(job, clips, notes=notes)


async def _run_fast(job: Job, transcript: dict, video_id: str, sentences, run, emit) -> None:
    """Legacy single-pass selection path (also the degrade target)."""
    registry.publish(job, ProgressEvent("selecting", 45.0, "Finding relevant moments…"))
    candidates, notes = await run(
        select_segments, sentences, job.topic, job.settings, emit("selecting", 45, 70))
    if not candidates:
        msg = notes or f"The topic “{job.topic}” doesn’t appear enough in this video to clip."
        return registry.fail(job, msg, notes=notes)

    registry.publish(job, ProgressEvent("refining", 70.0, "Snapping to boundaries…"))
    clips_spec = await run(refine_and_snap, candidates, sentences, job.settings, emit("refining", 70, 85))
    if not clips_spec:
        return registry.fail(job, "No clean clip boundaries could be formed.", notes=notes)

    if config.PRECISE_BOUNDARIES and transcript.get("source") == "supadata":
        registry.publish(job, ProgressEvent("refining", 86.0, "Refining boundaries with Whisper…"))
        clips_spec = await run(
            refine_clip_boundaries, clips_spec, job.url, video_id, job.settings, emit("refining", 86, 99))

    registry.finish(job, _build_embed_clips(clips_spec, video_id), notes=notes)

# Task 2 Report: Atomic writes + range-keyed export + zip guard

## What was done

**Fix 3 — Atomic finalization (`finalize_output`):**
Defined in `backend/pipeline/cut.py` (to avoid circular imports; export.py already imports cut.py). Re-exported from `backend/pipeline/export.py` via `from .cut import finalize_output, _export_fname`. Writes go to `*.tmp.mp4`; only on rc==0 AND nonzero size does `tmp.replace(out)` atomically promote the file. On any failure the partial tmp is unlinked and `PipelineError` is raised.

**Fix 4 — Range-keyed export names (`_export_fname`):**
Also in `cut.py` (same reason), re-exported from `export.py`. Format: `clip_{n}_{slug}_{start_ms}_{end_ms}.mp4`. Cache-hit check in `export_clip` now also checks `st_size > 0` so zero-byte orphans don't block re-rendering.

**Fix 6 — Zip guard (`_zipable_files` + 409):**
`_zipable_files(clips, folder)` defined at module level in `backend/main.py`. Skips entries with `path=None` (embed mode) and missing files. `download_zip` raises HTTP 409 when `files` is empty AND no `clips.json` manifest exists, giving a clear message instead of silently returning an empty zip.

**Import direction:** `export.py` → `cut.py` (one-way). Both helpers defined once in `cut.py`; `export.py` imports and re-exports them so `from backend.pipeline.export import finalize_output, _export_fname` works as the tests require.

## TDD evidence

- Tests written first: `backend/pipeline/tests/test_output_safety.py` (6 tests, verbatim from brief)
- RED: `ImportError` on `_zipable_files`, `finalize_output`, `_export_fname` before implementation
- GREEN: 6/6 passed after implementation
- Checkpoint: **145 passed**, compile clean

## Files modified

- `backend/pipeline/cut.py` — added `_export_fname`, `finalize_output`; updated `one()` to write to tmp then atomically rename (inline logic, message format preserved)
- `backend/pipeline/export.py` — re-exports `finalize_output`, `_export_fname` from cut; `export_clip` uses range-keyed fname, tmp write, size-aware cache check, `finalize_output`
- `backend/main.py` — added `_zipable_files`; `download_zip` uses it + raises 409 for empty-file embed-mode jobs
- `backend/pipeline/tests/test_output_safety.py` — new test file (6 tests)

## Concerns / notes

- `cut.py`'s failure message format (`ffmpeg failed on clip {i+1}: ...`) is preserved via inline logic in `one()` rather than calling `finalize_output` (which emits `"Clip cut failed: ..."`). This is intentional per the brief.
- `_slug` remains defined independently in both `cut.py` and `export.py` (they had duplicate definitions already); no change needed there.
- No circular imports introduced; `export.py` is the single public surface for both helpers.

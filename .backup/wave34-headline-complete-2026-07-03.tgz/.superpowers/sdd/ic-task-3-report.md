# Task 3 Report: Part-B dedupe + snap rejections + additive mutation warnings

## What Was Done

Six failing tests appended to `test_integrity.py`, confirmed RED (6 failed, 11 passed), then implemented steps a–f verbatim from the brief.

**Changes (additive-only unless noted):**

- `backend/pipeline/refine.py` (`_snap_one`): Added `extended` flag + `extended_for_min_duration` warning when min-duration loop extends the end beyond the judged span.
- `backend/pipeline/refine.py` (`_trim_start_after`): Added `trimmed_start` warning on the successful-trim return path.
- `backend/pipeline/boundary.py` (`_resolve_overlaps`): Added `trimmed_start` warning when a start is trimmed to `last_end`. The keep/drop behavior is unchanged.
- `backend/pipeline/assemble/scoring.py` (`boundary_score`): Added three 0.10 penalties for `extended_for_min_duration`, `trimmed_start`, `missing_context_card`.
- `backend/pipeline/assemble/boundary_adapt.py`: Full rewrite — new module-level import `from .integrity import Rejection, merge_partb`; `candidate_to_boundary_input` gains `"truncated"` field; `snap_candidates` signature extended to `(cands, sentences, settings, units=None) -> tuple[list[dict], list[Rejection]]`; new `_dedupe_partb` function replaces `refine._dedupe` call, performs containment/near-dup drop with Rejection ledgering and same-facet merge via `merge_partb`.
- `backend/pipeline/assemble/tests/test_judge_rubric.py` (`test_snap_flags_and_warns_unjudged`): Updated unpack to `specs, _rej = snap_candidates(...)`.
- `backend/pipeline/assemble/__init__.py` (step 4): `specs = snap_candidates(kept, sentences, settings)` → `specs, _snap_rejections = snap_candidates(kept, sentences, settings, units)`.

## TDD Evidence

- RED: 6 new tests failed, 11 existing passed.
- GREEN: 17 passed in `test_integrity.py`; 31 passed in `assemble/tests/`; **123 passed** total backend; compile clean.

## Files Modified

- `backend/pipeline/refine.py`
- `backend/pipeline/boundary.py`
- `backend/pipeline/assemble/scoring.py`
- `backend/pipeline/assemble/boundary_adapt.py`
- `backend/pipeline/assemble/__init__.py`
- `backend/pipeline/assemble/tests/test_integrity.py`
- `backend/pipeline/assemble/tests/test_judge_rubric.py`

## Concerns

- Brief predicted 32 assemble tests; actual is 31. The delta is one — the brief count may have been written anticipating a test that wasn't included, or counted across a slightly different test set. All 6 new tests are present and green.
- `refine._dedupe` (legacy fast path) is intentionally untouched; `_dedupe_partb` replicates its keep/drop logic while adding Rejection ledgering and `merge_partb` for same-facet overlaps. The characterization test (`test_dedupe_partb_matches_refine_on_disjoint_and_containment`) passes, confirming parity.
- Full rejection wiring outward is deferred to Task 4 per the brief; `_snap_rejections` is discarded at the call site for now.

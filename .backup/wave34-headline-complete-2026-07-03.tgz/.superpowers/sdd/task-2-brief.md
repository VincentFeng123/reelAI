### Task 2: `treeseg.py` — pure segmentation algorithm

**Files:**
- Create: `backend/pipeline/understand/treeseg.py`
- Create: `backend/pipeline/understand/tests/conftest.py`
- Test: `backend/pipeline/understand/tests/test_treeseg.py`

**Interfaces:**
- Consumes: `segment.gap_before(sentences, i) -> float`, `segment.discourse_hits(sentences) -> set[int]` (existing).
- Produces:
  - `boundary_priors(sentences, weight: float) -> np.ndarray`  # shape (n+1,), prior bonus at cut index k
  - `divisive_segments(emb: np.ndarray, *, target_k: int, min_size: int, coherence_floor: float = 0.0, priors: np.ndarray | None = None) -> tuple[list[tuple[int, int]], list[int]]`  # (sorted inclusive segments, boundary indices in split order)
  - `chapter_cut(split_order: list[int], segments: list[tuple[int, int]], max_per_chapter: int) -> list[tuple[int, int]]`  # inclusive topic-index ranges
  - `embed_sentences(sentences) -> np.ndarray` (Task 3 fills the real body; declare here)

- [ ] **Step 1: Write the shared test fixtures**

```python
# backend/pipeline/understand/tests/conftest.py
"""Offline fixtures: fabricated Sentences + block-structured fake embeddings (no model, no LLM)."""
from __future__ import annotations

import numpy as np

from backend.pipeline.sentences import Sentence


def make_sents(n: int, *, sec: float = 2.0, gap_at: tuple[int, ...] = (), gap: float = 6.0,
               texts: list[str] | None = None) -> list[Sentence]:
    """n sentences, `sec` seconds each; a `gap`-second pause BEFORE each index in gap_at."""
    sents, t = [], 0.0
    for i in range(n):
        if i in gap_at:
            t += gap
        s, e = t, t + sec
        sents.append(Sentence(idx=i, text=(texts[i] if texts else f"sentence number {i}"),
                              start=s, end=e, terminator=".", ends_with_period=True,
                              word_start_idx=i, word_end_idx=i, align_confidence=1.0))
        t = e + 0.1
    return sents


def block_emb(sizes: list[int], dim: int = 8) -> np.ndarray:
    """Unit vectors; block j points along axis j%dim → maximal between-block scatter at
    block boundaries. Deterministic by construction."""
    rows = []
    for j, sz in enumerate(sizes):
        v = np.zeros(dim)
        v[j % dim] = 1.0
        rows += [v] * sz
    return np.asarray(rows, dtype=np.float64)
```

- [ ] **Step 2: Write the failing algorithm tests**

```python
# backend/pipeline/understand/tests/test_treeseg.py
"""divisive_segments / boundary_priors / chapter_cut — pure, deterministic, offline."""
from __future__ import annotations

import numpy as np

from backend.pipeline.understand.treeseg import boundary_priors, chapter_cut, divisive_segments

from .conftest import block_emb, make_sents


def _coverage_ok(segments, n):
    assert segments == sorted(segments)
    assert segments[0][0] == 0 and segments[-1][1] == n - 1
    for (a0, a1), (b0, b1) in zip(segments, segments[1:]):
        assert b0 == a1 + 1


def test_two_blocks_cut_on_boundary():
    emb = block_emb([5, 5])
    segs, order = divisive_segments(emb, target_k=2, min_size=2)
    assert segs == [(0, 4), (5, 9)]
    assert order == [5]


def test_three_blocks_found():
    segs, _ = divisive_segments(block_emb([4, 4, 4]), target_k=3, min_size=2)
    assert segs == [(0, 3), (4, 7), (8, 11)]


def test_target_k_stops_splitting():
    segs, _ = divisive_segments(block_emb([3, 3, 3, 3]), target_k=2, min_size=2)
    assert len(segs) == 2


def test_uniform_never_splits_past_floor():
    emb = np.tile(np.array([1.0, 0, 0, 0]), (12, 1))          # identical vectors → gain 0
    segs, order = divisive_segments(emb, target_k=4, min_size=2, coherence_floor=1e-6)
    assert segs == [(0, 11)] and order == []


def test_min_size_respected():
    segs, _ = divisive_segments(block_emb([2, 10]), target_k=4, min_size=3)
    assert all(b - a + 1 >= 3 for a, b in segs)


def test_coverage_and_determinism():
    emb = block_emb([5, 4, 6, 5])
    r1 = divisive_segments(emb, target_k=4, min_size=2)
    r2 = divisive_segments(emb, target_k=4, min_size=2)
    assert r1 == r2
    _coverage_ok(r1[0], 20)


def test_degenerate_inputs():
    assert divisive_segments(block_emb([3]), target_k=1, min_size=2) == ([(0, 2)], [])
    assert divisive_segments(block_emb([2]), target_k=4, min_size=2) == ([(0, 1)], [])  # n < 2*min
    assert divisive_segments(np.zeros((0, 4)), target_k=2, min_size=2) == ([], [])


def test_prior_places_cut_on_uniform_embeddings():
    emb = np.tile(np.array([1.0, 0, 0, 0]), (12, 1))          # no embedding signal at all
    pr = np.zeros(13)
    pr[7] = 0.5
    segs, order = divisive_segments(emb, target_k=2, min_size=2, priors=pr)
    assert order == [7] and segs == [(0, 6), (7, 11)]


def test_boundary_priors_gap_and_discourse():
    sents = make_sents(10, gap_at=(5,), texts=[
        "alpha one", "alpha two", "alpha three", "alpha four", "alpha five",
        "beta one", "beta two", "So let us move on", "beta four", "beta five"])
    pr = boundary_priors(sents, weight=0.15)
    assert pr.shape == (11,)
    assert pr[5] > 0 and pr[7] > 0                            # pause seam + discourse marker
    assert pr[5] > pr[2] and pr[7] > pr[2]                    # plain boundary scores lower
    assert boundary_priors(sents, weight=0.0).sum() == 0.0


def test_chapter_cut_groups_by_earliest_splits():
    segs = [(0, 3), (4, 7), (8, 11), (12, 15), (16, 19), (20, 23)]
    order = [12, 4, 8, 16, 20]                                # first split at 12 = coarsest seam
    ranges = chapter_cut(order, segs, max_per_chapter=3)      # round(6/3)=2 chapters
    assert ranges == [(0, 2), (3, 5)]                         # boundary 12 = topic index 3


def test_chapter_cut_small_counts():
    segs = [(0, 5), (6, 11)]
    assert chapter_cut([6], segs, max_per_chapter=5) == [(0, 1)]   # round(2/5)=0 → 1 chapter
    assert chapter_cut([], [(0, 9)], max_per_chapter=5) == [(0, 0)]
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/understand/tests/test_treeseg.py -q`
Expected: FAIL — `ModuleNotFoundError`/`ImportError: treeseg`.

- [ ] **Step 4: Implement `treeseg.py`**

```python
# backend/pipeline/understand/treeseg.py
"""Deterministic embedding-based divisive topic segmentation (TreeSeg, arXiv:2407.12028).

Boundaries come 100% from sentence embeddings: bisecting splits that maximize the Ward-style
between-segment scatter gain, plus a small deterministic pause/discourse prior at candidate
boundaries. One tree yields both the topic cut and (via the earliest splits) the chapter cut.
No LLM, no randomness — same input, same output. Labeling happens later in content_map.
"""
from __future__ import annotations

import heapq

import numpy as np

from ... import config
from ..sentences import Sentence
from .segment import discourse_hits, gap_before

_model = None


def _get_model():
    global _model
    if _model is None:
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer(config.BI_ENCODER, device=config.TORCH_DEVICE)
    return _model


def embed_sentences(sentences: list[Sentence]) -> np.ndarray:
    """L2-normalized float32 sentence embeddings (all-MiniLM-L6-v2, locally cached).
    Raises on model-load/encode failure — the caller falls back to the legacy engine."""
    texts = [(s.text or "") for s in sentences]
    emb = _get_model().encode(texts, normalize_embeddings=True, show_progress_bar=False)
    return np.asarray(emb, dtype=np.float32)


def boundary_priors(sentences: list[Sentence], weight: float) -> np.ndarray:
    """Prior bonus for cutting BEFORE sentence k (shape n+1): long pauses and discourse
    markers ("so", "next", …) make a boundary slightly more attractive. Deterministic."""
    n = len(sentences)
    pr = np.zeros(n + 1, dtype=np.float64)
    if weight <= 0.0 or n < 2:
        return pr
    hits = discourse_hits(sentences)
    gaps = np.array([gap_before(sentences, i) for i in range(n)], dtype=np.float64)
    gmax = float(gaps.max()) or 1.0
    for i in range(1, n):
        pr[i] = weight * (min(gaps[i] / gmax, 1.0) + (1.0 if i in hits else 0.0)) / 2.0
    return pr


def divisive_segments(emb: np.ndarray, *, target_k: int, min_size: int,
                      coherence_floor: float = 0.0,
                      priors: np.ndarray | None = None) -> tuple[list[tuple[int, int]], list[int]]:
    """Bisecting segmentation of [0, n-1] into ≤ target_k contiguous segments.

    A cut at k splits [a,b] into [a,k-1],[k,b]; its gain is the between-segment scatter
    ‖S_L‖²/n_L + ‖S_R‖²/n_R − ‖S‖²/n (O(1) per candidate via prefix sums) + priors[k].
    Highest-gain span splits first; stops at target_k or when the best gain < coherence_floor.
    Ties break to the earliest index. Returns (sorted segments, boundaries in split order)."""
    n = int(emb.shape[0])
    if n == 0:
        return [], []
    if target_k <= 1 or n < 2 * min_size:
        return [(0, n - 1)], []
    prefix = np.zeros((n + 1, emb.shape[1]), dtype=np.float64)
    np.cumsum(emb, axis=0, out=prefix[1:])
    pri = priors if priors is not None else np.zeros(n + 1, dtype=np.float64)

    def best_cut(a: int, b: int):
        total = prefix[b + 1] - prefix[a]
        base = float(total @ total) / (b - a + 1)
        best_gain = best_k = None
        for k in range(a + min_size, b - min_size + 2):
            left = prefix[k] - prefix[a]
            right = total - left
            gain = (float(left @ left) / (k - a) + float(right @ right) / (b - k + 1)
                    - base + float(pri[k]))
            if best_gain is None or gain > best_gain + 1e-12:   # strict → earliest k wins ties
                best_gain, best_k = gain, k
        return (best_gain, best_k) if best_k is not None else None

    segments = [(0, n - 1)]
    split_order: list[int] = []
    heap: list[tuple[float, int, int, int]] = []
    first = best_cut(0, n - 1)
    if first:
        heapq.heappush(heap, (-first[0], 0, n - 1, first[1]))
    while heap and len(segments) < target_k:
        neg_gain, a, b, k = heapq.heappop(heap)
        if -neg_gain < coherence_floor:
            break
        segments.remove((a, b))
        segments.extend([(a, k - 1), (k, b)])
        split_order.append(k)
        for x, y in ((a, k - 1), (k, b)):
            c = best_cut(x, y)
            if c:
                heapq.heappush(heap, (-c[0], x, y, c[1]))
    segments.sort()
    return segments, split_order


def chapter_cut(split_order: list[int], segments: list[tuple[int, int]],
                max_per_chapter: int) -> list[tuple[int, int]]:
    """Chapter grouping from the SAME tree: the earliest splits are the coarsest seams.
    Returns inclusive (first_topic_idx, last_topic_idx) ranges covering all topics."""
    n_topics = len(segments)
    if n_topics == 0:
        return []
    n_chapters = max(1, round(n_topics / max_per_chapter))
    if n_chapters >= n_topics:
        return [(i, i) for i in range(n_topics)]
    bounds = sorted(split_order[: n_chapters - 1])
    starts = [s0 for s0, _ in segments]
    ranges, t0 = [], 0
    for b in bounds:
        t = starts.index(b)              # splits nest → every early boundary survives in the cut
        ranges.append((t0, t - 1))
        t0 = t
    ranges.append((t0, n_topics - 1))
    return ranges
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/understand/tests/test_treeseg.py -q`
Expected: 11 passed.

- [ ] **Step 6: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: all pass, compile clean.

---


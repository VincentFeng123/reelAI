### Task 2: Truthful unit_ids at build/repair + repair Rejections

**Files:**
- Modify: `backend/pipeline/assemble/candidates.py` (`build_candidate`, ~lines 88-109)
- Modify: `backend/pipeline/assemble/validate.py` (`expand_candidate` final replace ~line 262; `validate_and_repair` return contract)
- Modify: `backend/pipeline/assemble/__init__.py` (`_assemble_one` unpack; internal rejection list — NOT yet returned)
- Modify: `backend/pipeline/assemble/tests/test_judge_rubric.py` (repair test unpack)
- Test: append to `backend/pipeline/assemble/tests/test_integrity.py`

**Interfaces:**
- Consumes: Task 1's `true_contents`, `Rejection`.
- Produces: `validate_and_repair(...) -> tuple[Optional[Candidate], Optional[Rejection]]` — `(cand, None)` on keep, `(None, Rejection(stage="repair", …))` on drop, carrying the LAST verdict's score + failure kinds; `build_candidate`/`expand_candidate` always emit `true_contents`-consistent `unit_ids`/`referential`.

- [ ] **Step 1: Write the failing tests** (append to `test_integrity.py`)

```python
# ── truthful ids at build/repair + repair rejection ──────────────────────────
import threading

import backend.llm as llm_mod
from backend.pipeline.assemble.graph import Graph
from backend.pipeline.assemble.types import Candidate
from backend.pipeline.assemble.validate import JudgeVerdict, expand_candidate, validate_and_repair

from .conftest import FakeAdapter


def test_expand_candidate_emits_true_contents():
    sents, units = _setup()
    units_by_id = {u.unit_id: u for u in units}
    cand = Candidate(cand_id="c0", anchor_id="u0003", role="explanation", facet="other",
                     title="t", reason="r", unit_ids=["u0003"],
                     referential=[("u0000", "prerequisite")], i_start=3, i_end=3,
                     start=sents[3].start, end=sents[3].end)
    verdict = JudgeVerdict(prerequisites_satisfied=False, score_10=3)
    grown = expand_candidate(cand, verdict, Graph([], units), units, units_by_id,
                             {}, sents, max_span_s=999.0)
    assert grown is not None
    # u0000 pulled in → span [0,3] → u0001/u0002 absorbed, referential emptied
    assert grown.unit_ids == ["u0000", "u0001", "u0002", "u0003"]
    assert grown.referential == []


def test_repair_drop_returns_rejection_with_last_verdict(monkeypatch):
    from backend import config
    monkeypatch.setattr(config, "JUDGE_MODEL", "")
    monkeypatch.setattr(config, "JUDGE_PROVIDER", "same")

    def bad_verdict(*a, **kw):     # judged, failing, unrepairable (no targets: refs fine, topic bad)
        return JudgeVerdict(reasoning="bad", score_10=2, understandable=False,
                            topic_identifiable=False, purpose_identifiable=False)
    monkeypatch.setattr(llm_mod, "llm_json", bad_verdict)

    sents, units = _setup()
    units_by_id = {u.unit_id: u for u in units}
    cand = Candidate(cand_id="c0", anchor_id="u0000", role="explanation", facet="other",
                     title="T", reason="r", unit_ids=["u0000"], referential=[],
                     i_start=0, i_end=0, start=sents[0].start, end=sents[0].end)
    kept, rej = validate_and_repair(cand, sents, Graph([], units), units, units_by_id, {},
                                    FakeAdapter(), {}, lambda s, e: "", "topic", {}, threading.Lock())
    assert kept is None
    assert rej is not None and rej.stage == "repair"
    assert rej.score == pytest.approx(0.2)
    assert rej.cand_id == "c0" and rej.title == "T"


def test_repair_keep_returns_no_rejection(monkeypatch):
    from backend import config
    monkeypatch.setattr(config, "JUDGE_MODEL", "")
    monkeypatch.setattr(config, "JUDGE_PROVIDER", "same")
    monkeypatch.setattr(llm_mod, "llm_json",
                        lambda *a, **kw: JudgeVerdict(reasoning="ok", score_10=9, understandable=True))
    sents, units = _setup()
    units_by_id = {u.unit_id: u for u in units}
    cand = Candidate(cand_id="c0", anchor_id="u0000", role="explanation", facet="other",
                     title="t", reason="r", unit_ids=["u0000"], referential=[],
                     i_start=0, i_end=0, start=sents[0].start, end=sents[0].end)
    kept, rej = validate_and_repair(cand, sents, Graph([], units), units, units_by_id, {},
                                    FakeAdapter(), {}, lambda s, e: "", "topic", {}, threading.Lock())
    assert kept is not None and rej is None
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/test_integrity.py -q`
Expected: new tests FAIL — expand doesn't absorb; validate_and_repair returns a single value.

- [ ] **Step 3: Implement**

a) `candidates.py::build_candidate` — replace the final `return Candidate(...)` block's id fields:

```python
    from .integrity import true_contents
    unit_ids, referential = true_contents(list(cl.unit_ids), list(cl.referential),
                                          units, i_start, i_end)
    return Candidate(
        cand_id=f"c_{anchor.unit_id}",
        anchor_id=anchor.unit_id,
        role=anchor.role,
        facet=adapter.facet_for(anchor.role),
        title=anchor.topic or (anchor.summary[:60]),
        reason=anchor.summary,
        unit_ids=unit_ids,
        referential=referential,
        i_start=i_start, i_end=i_end,
        start=float(sentences[i_start].start), end=float(sentences[i_end].end),
        relevance=relevance.get(anchor.unit_id, 0.0),
        priority=adapter.anchor_priority(anchor.role),
        truncated=cl.truncated,
    )
```

(move the `from .integrity import true_contents` to the module imports.)

b) `validate.py::expand_candidate` — the final replace becomes:

```python
    new_ids = sorted(chosen, key=lambda x: (units_by_id[x].start, order.get(x, 0)))
    i0, i1 = _reindex(new_ids, units_by_id, sentences)
    from .integrity import true_contents
    new_ids, new_ref = true_contents(new_ids, cand.referential, units, i0, i1)
    return replace(cand, unit_ids=new_ids, referential=new_ref, i_start=i0, i_end=i1,
                   start=sentences[i0].start, end=sentences[i1].end)
```

c) `validate.py::validate_and_repair` — change the return contract. Signature line:

```python
def validate_and_repair(cand: Candidate, sentences: list[Sentence], graph, units: list[Unit],
                        units_by_id: dict[str, Unit], introducers: dict[str, list[str]], adapter,
                        settings: dict, visual_summary_fn, topic: str,
                        cache: dict, cache_lock=None) -> tuple[Optional[Candidate], Optional["Rejection"]]:
```

Every existing `return cand` / `return best` becomes `return cand, None` / `return best, None`
(three sites: the is_complete return, the error-verdict early return, the best-partial return).
The final `return None` becomes:

```python
    from .integrity import Rejection
    last = best.verdict if best is not None else getattr(cand, "verdict", None)
    return None, Rejection(
        cand_id=cand.cand_id, title=cand.title, role=cand.role, stage="repair",
        reason="judge verdict incomplete after repair budget",
        score=(float(last.score) if last is not None else None),
        failure_kinds=[f.kind for f in (last.failure_reasons if last is not None else [])],
        final_quality=None, start=cand.start, end=cand.end)
```

NOTE the best-partial gate: when `best` exists but fails the hard-core gate, execution falls
through to this same Rejection return (previously `return None`).

d) `assemble/__init__.py::_assemble_one` and its collection loop — unpack the tuple and stash
rejections in a thread-safe list (internal only in this task; returned in Task 4):

```python
    rejections: list = []
    rej_lock = threading.Lock()

    def _assemble_one(anchor):
        cand = build_candidate(anchor, graph, adapter, units, units_by_id, sentences, relevance, settings)
        if cand is None:
            return None
        cand, rejection = validate_and_repair(cand, sentences, graph, units, units_by_id, introducers,
                                              adapter, settings, structure.visual_summary, topic,
                                              cache, cache_lock)
        if rejection is not None:
            with rej_lock:
                rejections.append(rejection)
        if cand is None:
            return None
        cand.completeness_score = scoring.completeness_score(cand.verdict, cand.role, adapter)
        cand.grounding_score = scoring.grounding_score(cand, units_by_id)
        cand.final_quality = scoring.final_quality(cand)
        return cand
```

e) `tests/test_judge_rubric.py::test_repair_returns_candidate_on_error_without_burning_budget` —
the call becomes `cand, rej = validate_and_repair(...)`; add `assert rej is None` after the
existing assertions (error path is ship-but-flag: kept, not rejected).

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/ -q`
Expected: 26 passed (14 rubric + 12 integrity).

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: 118 passed, compile clean.

---


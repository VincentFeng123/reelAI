"""P3a arc detection — deterministic grammar scan + cross-distance practice pairing +
the optional single-call verification (MathNet pattern). All offline; the ONLY LLM entry
point (verify_arcs) is exercised with llm_json monkeypatched."""
from __future__ import annotations

import pytest

import backend.llm as llm_mod
from backend.pipeline.understand.arcs import (
    ArcCheckLLM, ArcVerifyLLM, detect_arcs, verify_arcs,
)
from backend.pipeline.understand.models import Unit


def _units(roles, concepts=None, needs=None):
    """One 10s unit per role; concepts/needs are {index: [..]} maps."""
    concepts = concepts or {}
    needs = needs or {}
    return [Unit(unit_id=f"u{i:04d}", start=i * 10.0, end=i * 10.0 + 9.9,
                 sentence_range=(i, i), role=r, transcript=f"unit {i} text.",
                 summary=f"unit {i}",
                 concepts_introduced=list(concepts.get(i, [])),
                 concepts_required=list(needs.get(i, [])))
            for i, r in enumerate(roles)]


def _by_id(units):
    return {u.unit_id: u for u in units}


# ── the audited kinematics shape: results labeled 'calculation' (u0021–u0025) ────────────
def test_kinematics_shape_calculation_as_final_detected():
    # docs/audits/2026-07-02/kinematics_e2e.json: u0021 example_setup (particle 100m E,
    # 150m W, 5s), u0022/u0025 worked_step, u0023/u0024 calculation — NO result/solution
    # unit; the complete example was unclippable pre-P3. Surrounding roles reproduced.
    roles = ["definition",                                     # u0020-ish context
             "example_setup", "worked_step", "calculation", "calculation", "worked_step",
             "definition", "explanation", "variable_definition"]   # u0026-u0028-ish
    arcs = detect_arcs(_units(roles))
    assert len(arcs) == 1
    a = arcs[0]
    assert a.arc_role == "worked_example"
    assert a.unit_ids == ["u0001", "u0002", "u0003", "u0004", "u0005"]
    assert a.terminal_id == "u0004"            # the LAST calculation is the payoff
    assert a.terminal_role == "result"         # synthetic anchor role → worked-example contract
    assert a.calculation_as_final is True
    assert a.arc_id == "arc_0"


def test_explicit_result_terminal():
    arcs = detect_arcs(_units(["example_setup", "worked_step", "result"]))
    assert len(arcs) == 1
    a = arcs[0]
    assert a.unit_ids == ["u0000", "u0001", "u0002"]
    assert a.terminal_id == "u0002" and a.terminal_role == "result"
    assert a.calculation_as_final is False


def test_multi_unit_setup_and_solution_terminal():
    # two setup units (example_setup + problem_givens) then steps then a solution unit
    arcs = detect_arcs(_units(["example_setup", "problem_givens", "derivation", "solution"]))
    assert len(arcs) == 1
    a = arcs[0]
    assert a.opener_ids == ["u0000", "u0001"]
    assert a.terminal_role == "solution"


# ── interleave tolerance ─────────────────────────────────────────────────────────────────
def test_two_interleaved_nonarc_units_tolerated():
    roles = ["example_setup", "worked_step", "transition", "exception", "worked_step", "result"]
    arcs = detect_arcs(_units(roles))
    assert len(arcs) == 1
    assert arcs[0].unit_ids == ["u0000", "u0001", "u0004", "u0005"]


def test_three_interleaved_units_break_the_arc():
    # tolerance exceeded before the result; steps have no calculation → nothing terminal
    roles = ["example_setup", "worked_step", "transition", "exception", "explanation", "result"]
    assert detect_arcs(_units(roles)) == []


def test_three_interleaves_still_close_on_calculation_as_final():
    roles = ["example_setup", "calculation", "transition", "exception", "explanation", "result"]
    arcs = detect_arcs(_units(roles))
    assert len(arcs) == 1
    assert arcs[0].unit_ids == ["u0000", "u0001"]
    assert arcs[0].terminal_id == "u0001" and arcs[0].calculation_as_final is True


# ── grammar negatives ────────────────────────────────────────────────────────────────────
def test_opener_directly_to_result_is_not_an_arc():
    assert detect_arcs(_units(["example_setup", "result"])) == []


def test_steps_without_opener_are_not_an_arc():
    assert detect_arcs(_units(["worked_step", "calculation", "result"])) == []


def test_worked_steps_only_never_close_without_calculation():
    assert detect_arcs(_units(["example_setup", "worked_step", "worked_step"])) == []


def test_new_opener_after_steps_closes_and_restarts():
    roles = ["example_setup", "worked_step", "calculation",
             "example_setup", "worked_step", "result"]
    arcs = detect_arcs(_units(roles))
    assert [a.unit_ids for a in arcs] == [["u0000", "u0001", "u0002"],
                                          ["u0003", "u0004", "u0005"]]
    assert arcs[0].calculation_as_final is True and arcs[1].terminal_role == "result"


def test_bus_problem_slice_from_audit_yields_two_arcs():
    # u0043–u0060 role sequence from the kinematics audit (transition, example_setup, setup,
    # claim, procedure, steps…, problem_givens, step, result, part-b setup…result).
    roles = ["transition", "example_setup", "setup", "claim", "procedure",
             "worked_step", "worked_step", "calculation", "worked_step",
             "problem_givens", "worked_step", "result",
             "example_setup", "problem_givens", "physical_interpretation", "procedure",
             "worked_step", "result"]
    arcs = detect_arcs(_units(roles))
    assert [a.unit_ids for a in arcs] == [
        ["u0009", "u0010", "u0011"],                       # givens → step → result
        ["u0012", "u0013", "u0016", "u0017"],              # part b (≤2 interleave)
    ]
    assert all(a.arc_role == "worked_example" for a in arcs)


# ── practice pairing across distance (shared concept) ────────────────────────────────────
def test_practice_pair_first_later_solution_sharing_a_concept():
    roles = ["practice_prompt", "explanation", "result", "claim", "explanation", "solution"]
    arcs = detect_arcs(_units(
        roles,
        concepts={0: ["momentum"], 2: ["energy"]},
        needs={5: ["Momentum"]}))                          # case-insensitive concept match
    assert len(arcs) == 1
    a = arcs[0]
    assert a.arc_role == "practice_pair"
    assert a.unit_ids == ["u0000", "u0005"]                # nearer non-sharing result skipped
    assert a.terminal_id == "u0005" and a.terminal_role == "solution"


def test_prompt_without_shared_concept_pairs_nothing():
    roles = ["practice_prompt", "explanation", "solution"]
    assert detect_arcs(_units(roles, concepts={0: ["momentum"], 2: ["energy"]})) == []


def test_prompt_consumed_as_arc_opener_is_not_paired_again():
    # prompt → step → solution is ONE grammar arc (practice_pair-shaped); no distance pair
    roles = ["practice_prompt", "worked_step", "solution", "solution"]
    arcs = detect_arcs(_units(roles, concepts={0: ["x"], 2: ["x"], 3: ["x"]}))
    assert len(arcs) == 1
    assert arcs[0].unit_ids == ["u0000", "u0001", "u0002"]
    assert arcs[0].arc_role == "practice_pair"             # prompt-opened, solution-terminated


def test_arc_ids_sequential():
    roles = ["example_setup", "worked_step", "result",
             "practice_prompt", "explanation", "solution"]
    arcs = detect_arcs(_units(roles, concepts={3: ["x"]}, needs={5: ["x"]}))
    assert [a.arc_id for a in arcs] == ["arc_0", "arc_1"]


# ── verification (one batched call; rule-checked ids; degrade-not-crash) ─────────────────
def _two_arcs():
    roles = ["example_setup", "worked_step", "result",
             "example_setup", "calculation", "result"]
    units = _units(roles)
    arcs = detect_arcs(units)
    assert len(arcs) == 2
    return arcs, _by_id(units)


def test_verify_confirms_and_drops_by_omission(monkeypatch):
    arcs, by_id = _two_arcs()
    calls = []

    def fake(system, user, schema, **kw):
        calls.append(schema)
        assert schema is ArcVerifyLLM
        return ArcVerifyLLM(arcs=[ArcCheckLLM(arc_id="arc_0", problem_ids=["u0000"],
                                              step_ids=["u0001"], answer_ids=["u0002"])])
    monkeypatch.setattr(llm_mod, "llm_json", fake)
    kept, note = verify_arcs(arcs, by_id, {"arc_verify": True})
    assert note is None and len(calls) == 1                # ONE batched call for all arcs
    assert [a.arc_id for a in kept] == ["arc_0"]           # arc_1 rejected by omission
    assert kept[0].verified is True


def test_verify_rule_checks_ids_inside_the_arc(monkeypatch):
    arcs, by_id = _two_arcs()

    def fake(system, user, schema, **kw):
        return ArcVerifyLLM(arcs=[
            # answer id points OUTSIDE arc_0 → discarded → no confirmed answer → dropped
            ArcCheckLLM(arc_id="arc_0", problem_ids=["u0000"], step_ids=["u0001"],
                        answer_ids=["u0005"]),
            ArcCheckLLM(arc_id="arc_1", problem_ids=["u0003", "u9999"], step_ids=["u0004"],
                        answer_ids=["u0005"]),             # stray u9999 discarded, arc still ok
        ])
    monkeypatch.setattr(llm_mod, "llm_json", fake)
    kept, note = verify_arcs(arcs, by_id, {"arc_verify": True})
    assert note is None
    assert [a.arc_id for a in kept] == ["arc_1"]


def test_verify_practice_pair_needs_no_steps(monkeypatch):
    roles = ["practice_prompt", "explanation", "solution"]
    units = _units(roles, concepts={0: ["x"]}, needs={2: ["x"]})
    arcs = detect_arcs(units)
    assert len(arcs) == 1 and arcs[0].arc_role == "practice_pair"

    def fake(system, user, schema, **kw):
        return ArcVerifyLLM(arcs=[ArcCheckLLM(arc_id="arc_0", problem_ids=["u0000"],
                                              step_ids=[], answer_ids=["u0002"])])
    monkeypatch.setattr(llm_mod, "llm_json", fake)
    kept, _ = verify_arcs(arcs, _by_id(units), {"arc_verify": True})
    assert len(kept) == 1 and kept[0].verified is True


def test_verify_llm_failure_keeps_arcs_unverified_with_note(monkeypatch):
    arcs, by_id = _two_arcs()

    def boom(*a, **kw):
        raise RuntimeError("api down")
    monkeypatch.setattr(llm_mod, "llm_json", boom)
    kept, note = verify_arcs(arcs, by_id, {"arc_verify": True})
    assert kept == arcs                                     # unverified-but-kept
    assert all(a.verified is False for a in kept)
    assert note is not None and "unverified" in note


def test_verify_flag_off_makes_no_llm_call(monkeypatch):
    arcs, by_id = _two_arcs()

    def boom(*a, **kw):                                     # any call would fail the test
        raise AssertionError("llm_json must not be called with arc_verify off")
    monkeypatch.setattr(llm_mod, "llm_json", boom)
    kept, note = verify_arcs(arcs, by_id, {"arc_verify": False})
    assert kept == arcs and note is None


def test_verify_no_arcs_short_circuits(monkeypatch):
    monkeypatch.setattr(llm_mod, "llm_json",
                        lambda *a, **kw: pytest.fail("no call expected"))
    assert verify_arcs([], {}, {"arc_verify": True}) == ([], None)

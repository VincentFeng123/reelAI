# Task 1: boundary.py — Resilience + Direction-Safe Picks

## Status
✓ COMPLETE — All tests green (6/6), full suite clean (139/139), compile pass.

## TDD Evidence
- Created test package: `backend/pipeline/tests/__init__.py` + `test_boundary_safety.py` (6 tests)
- All tests failed initially (refine raises, _pick_end returns wrong value, _pick_start missing `keep_first` parameter, fallbacks wrong direction)
- Implemented fixes (a, b, c) per brief
- All tests now pass; verified full suite with `.venv/bin/python -m pytest backend -q` (139 passed) and compile check (clean)

## Changes Made

### 1. `_pick_start` (lines 98–115)
- Added `keep_first: bool = False` parameter  
- Fragment-drop logic: `pool = sents if keep_first else sents[1:]`  
- Direction-safe fallback: only apply when candidates are too far (`min(starts) - rough > pad`); otherwise preserve old fragment-drop behavior

### 2. `_pick_end` (lines 118–132)
- Two-tier filtering: prefer ends >= rough, fall back to ends >= rough - 1.0
- Direction-safe fallback: if no candidates at either tier, return rough (never truncate earlier than rough−1s)

### 3. `refine_clip_boundaries` (lines 161–164, 173, 176–177)
- Wrapped `_ensure_audio` call in try/except to return input clips unchanged on audio failure
- Both `_pick_start` call sites now pass `keep_first=(s0 - pad <= 0.0)` (lines 173, 177)

## Files
- Modified: `/Users/vincentfeng/Documents/practice/clips/backend/pipeline/boundary.py` (3 functions)
- Created: `/Users/vincentfeng/Documents/practice/clips/backend/pipeline/tests/__init__.py` (empty)
- Created: `/Users/vincentfeng/Documents/practice/clips/backend/pipeline/tests/test_boundary_safety.py` (6 tests)

## Concerns
None. All changes isolated to specified functions; no unintended modifications to `_resolve_overlaps`, `_whisper_window`, or other code.

## Fix: strict direction-safe _pick_start

### What
Simplified `_pick_start` to enforce strict direction-safety: when no sentence start exists at/before rough+1.0, return `rough` unconditionally instead of falling back to `min(starts)` within pad (which moved the clip start LATER, truncating judge-approved opening content).

### Why
The previous fallback logic (`min(starts)-within-pad` compromise) violated the core audit principle: never move the start LATER than the rough boundary. The spec mandates direction-safety above convenience; a test assertion documenting the legacy behavior was wrong and had to change with it.

### Changes
- `backend/pipeline/boundary.py::_pick_start` (lines 106–110): replaced multi-clause fallback with unconditional `return rough`
- `backend/pipeline/tests/test_boundary_safety.py::test_pick_start_keep_first_at_video_start` (line 54): changed assertion from `3.1` to `0.5` with updated comment

### Commands & Output
```bash
$ .venv/bin/python -m pytest backend/pipeline/tests/test_boundary_safety.py -q
......                                                                   [100%]
6 passed in 0.30s

$ .venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend
........................................................................ [ 51%]
...................................................................      [100%]
139 passed in 0.39s
```

### Task 3: `content_map.py` — engine dispatch, treeseg assembly, labeling, fallback

**Files:**
- Modify: `backend/pipeline/understand/content_map.py`
- Test: `backend/pipeline/understand/tests/test_content_map_treeseg.py`

**Interfaces:**
- Consumes: Task 2's `treeseg` functions; existing `TopicLLM`, `ContentMap`, `ContentNode`, `render_sentences`, `backend.llm.llm_json`.
- Produces: `build_content_map(sentences, settings, progress) -> ContentMap` (signature unchanged) with `engine` set to `"treeseg"` / `"llm"` / `"llm-fallback"`; internal `_build_content_map_llm` (the moved legacy body), `_build_content_map_treeseg`, `_label_segments(segments, sentences) -> list[TopicLLM]`, `SegLabelLLM` / `SegLabelsLLM` pydantic models.

- [ ] **Step 1: Write the failing tests**

```python
# backend/pipeline/understand/tests/test_content_map_treeseg.py
"""Engine dispatch + treeseg ContentMap assembly + labeling alignment + fallback. Offline."""
from __future__ import annotations

import numpy as np
import pytest

import backend.llm as llm_mod
import backend.pipeline.understand.content_map as cm_mod
from backend.pipeline.understand.content_map import SegLabelLLM, SegLabelsLLM, build_content_map

from .conftest import block_emb, make_sents


@pytest.fixture
def two_block_embedder(monkeypatch):
    calls = {"n": 0}

    def fake_embed(sentences):
        calls["n"] += 1
        return block_emb([len(sentences) // 2, len(sentences) - len(sentences) // 2])

    monkeypatch.setattr(cm_mod, "embed_sentences", fake_embed)
    return calls


@pytest.fixture
def label_llm(monkeypatch):
    def fake_llm_json(system, user, schema, **kw):
        assert schema is SegLabelsLLM
        idxs = [int(t) for t in __import__("re").findall(r"\[(\d+)\]", user)]
        return SegLabelsLLM(labels=[
            SegLabelLLM(index=i, title=f"Label {i}", summary=f"About {i}", keywords=[f"k{i}"])
            for i in sorted(set(idxs))])

    monkeypatch.setattr(llm_mod, "llm_json", fake_llm_json)


def _mk_settings(engine=None):
    return {"content_map_engine": engine}


def test_treeseg_assembly(two_block_embedder, label_llm):
    sents = make_sents(12, sec=30.0)                     # 12×30 s → duration drives K ≥ 2
    cm = build_content_map(sents, _mk_settings())
    assert cm.engine == "treeseg"
    topics = cm.topics()
    assert [t.sentence_range for t in topics] == [(0, 5), (6, 11)]
    assert [t.title for t in topics] == ["Label 0", "Label 1"]
    assert topics[0].summary == "About 0" and topics[0].keywords == ["k0"]
    assert not cm.subtopics()                            # treeseg emits no subtopic nodes
    chapters = cm.chapters()
    assert chapters and all(ch.parent_id == "video" for ch in chapters)
    for t in topics:
        assert t.parent_id in {ch.node_id for ch in chapters}
        assert t.node_id in next(ch for ch in chapters if ch.node_id == t.parent_id).children_ids


def test_label_failure_keeps_partition(two_block_embedder, monkeypatch):
    def boom(*a, **kw):
        raise RuntimeError("label LLM down")
    monkeypatch.setattr(llm_mod, "llm_json", boom)
    sents = make_sents(12, sec=30.0)
    cm = build_content_map(sents, _mk_settings())
    assert cm.engine == "treeseg"                        # label failure ≠ engine fallback
    topics = cm.topics()
    assert [t.sentence_range for t in topics] == [(0, 5), (6, 11)]
    assert all(t.title for t in topics)                  # deterministic fallback titles


def test_embed_failure_falls_back_to_llm_engine(monkeypatch):
    def boom(sentences):
        raise RuntimeError("no model")
    monkeypatch.setattr(cm_mod, "embed_sentences", boom)

    def fake_llm_json(system, user, schema, **kw):       # legacy path's topic pass
        from backend.pipeline.understand.content_map import ContentMapLLM, TopicLLM
        assert schema is ContentMapLLM
        return ContentMapLLM(topics=[TopicLLM(title="Legacy", sentence_start=0, sentence_end=11)])
    monkeypatch.setattr(llm_mod, "llm_json", fake_llm_json)

    cm = build_content_map(make_sents(12, sec=30.0), _mk_settings())
    assert cm.engine == "llm-fallback"
    assert cm.topics()[0].title == "Legacy"


def test_llm_engine_when_configured(two_block_embedder, monkeypatch):
    def fake_llm_json(system, user, schema, **kw):
        from backend.pipeline.understand.content_map import ContentMapLLM, TopicLLM
        return ContentMapLLM(topics=[TopicLLM(title="Legacy", sentence_start=0, sentence_end=11)])
    monkeypatch.setattr(llm_mod, "llm_json", fake_llm_json)
    cm = build_content_map(make_sents(12, sec=30.0), _mk_settings(engine="llm"))
    assert cm.engine == "llm"
    assert two_block_embedder["n"] == 0                  # embeddings never touched


def test_empty_sentences_video_only():
    cm = build_content_map([], _mk_settings())
    assert [n.level for n in cm.nodes] == ["video"]


def test_tiny_video_single_topic_no_embeddings(two_block_embedder, label_llm):
    sents = make_sents(4, sec=30.0)                      # n=4 < 2×TREESEG_MIN_TOPIC_SENTS
    cm = build_content_map(sents, _mk_settings())
    assert cm.engine == "treeseg"
    assert [t.sentence_range for t in cm.topics()] == [(0, 3)]
    assert two_block_embedder["n"] == 0                  # early-out before embedding
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/understand/tests/test_content_map_treeseg.py -q`
Expected: FAIL — `ImportError: SegLabelLLM` (module not yet refactored).

- [ ] **Step 3: Implement the refactor**

In `backend/pipeline/understand/content_map.py`:

a) Extend the module docstring's first line context (keep spec §2 reference) and add imports:

```python
import re
from collections import Counter

from .treeseg import boundary_priors, chapter_cut, divisive_segments, embed_sentences
```

b) Rename the existing `build_content_map` body to `_build_content_map_llm` **unchanged** (drop only its `n == 0` early-return, which moves to the dispatcher).

c) Add the labeling models + prompt + helpers:

```python
class SegLabelLLM(BaseModel):
    index: int = 0
    title: str = ""
    summary: str = ""
    keywords: list[str] = Field(default_factory=list)


class SegLabelsLLM(BaseModel):
    labels: list[SegLabelLLM] = Field(default_factory=list)


LABEL_SYSTEM = (
    "You are labeling ALREADY-SEGMENTED topics of a video transcript. For each numbered "
    "segment excerpt, return its index with a short specific title, a one-line summary, and "
    "a few keywords. Do NOT merge, split, re-order, or invent segments. "
    "Output only the structured result."
)

_STOP = frozenset(
    "the a an and or of to in on for with is are was were be this that it its as at by "
    "we you i so now what when where which have has had will would can could about".split())


def _excerpt(sentences: list[Sentence], s0: int, s1: int, cap: int = 420) -> str:
    """First / middle / last sentences of the segment, bounded — enough to label, cheap to send."""
    idxs = sorted({max(s0, min(s1, i)) for i in (s0, s0 + 1, (s0 + s1) // 2, s1 - 1, s1)})
    return " … ".join(p for p in ((sentences[i].text or "").strip() for i in idxs) if p)[:cap]


def _fallback_title(sentences: list[Sentence], s0: int, s1: int, ti: int) -> str:
    """Deterministic keyword title when the label LLM fails: top content words of the segment."""
    text = " ".join((sentences[i].text or "") for i in range(s0, s1 + 1)).lower()
    words = [w for w in re.findall(r"[a-zA-Z][a-zA-Z'-]{3,}", text) if w not in _STOP]
    common = [w for w, _ in Counter(words).most_common(3)]
    return " ".join(common).title() or f"Topic {ti + 1}"


def _label_segments(segments: list[tuple[int, int]], sentences: list[Sentence]) -> list[TopicLLM]:
    """One cheap LLM pass per TREESEG_LABEL_BATCH segments. Labels align by index and are
    clamped to the fixed partition — they can never re-segment. Any failure degrades to
    deterministic keyword titles; the partition is untouched."""
    from ...llm import llm_json
    out = [TopicLLM(title="", sentence_start=s0, sentence_end=s1) for s0, s1 in segments]
    for base in range(0, len(segments), config.TREESEG_LABEL_BATCH):
        batch = segments[base: base + config.TREESEG_LABEL_BATCH]
        listing = "\n".join(
            f"[{base + j}] ({sentences[s0].start:.0f}-{sentences[s1].end:.0f}s) "
            f"{_excerpt(sentences, s0, s1)}"
            for j, (s0, s1) in enumerate(batch))
        try:
            res = llm_json(LABEL_SYSTEM,
                           f"SEGMENT EXCERPTS:\n{listing}\n\n"
                           f"Label every segment [{base}]–[{base + len(batch) - 1}].",
                           SegLabelsLLM, temperature=0.1)
        except Exception:
            res = SegLabelsLLM()
        for lab in res.labels:
            i = int(lab.index)
            if base <= i < base + len(batch) and lab.title.strip():
                out[i].title = lab.title.strip()
                out[i].summary = lab.summary.strip()
                out[i].keywords = [k for k in lab.keywords if k]
    for ti, ((s0, s1), t) in enumerate(zip(segments, out)):
        if not t.title:
            t.title = _fallback_title(sentences, s0, s1, ti)
    return out
```

d) Add the treeseg builder + assembler:

```python
def _assemble_treeseg(sentences: list[Sentence], segments: list[tuple[int, int]],
                      labels: list[TopicLLM], chapters: list[tuple[int, int]]) -> ContentMap:
    n = len(sentences)
    video = ContentNode(node_id="video", level="video", title="",
                        start=sentences[0].start, end=sentences[-1].end, sentence_range=(0, n - 1))
    nodes: list[ContentNode] = [video]
    for ci, (t0, t1) in enumerate(chapters):
        cid = f"c{ci}"
        cs0, cs1 = segments[t0][0], segments[t1][1]
        chapter = ContentNode(
            node_id=cid, level="chapter", parent_id="video",
            title=labels[t0].title or f"Chapter {ci + 1}",
            start=float(sentences[cs0].start), end=float(sentences[cs1].end),
            sentence_range=(cs0, cs1))
        video.children_ids.append(cid)
        nodes.append(chapter)
        for ti in range(t0, t1 + 1):
            s0, s1 = segments[ti]
            t = labels[ti]
            tid = f"{cid}.t{ti}"
            topic = ContentNode(
                node_id=tid, level="topic", parent_id=cid,
                title=t.title or f"Topic {ti + 1}", summary=t.summary,
                start=float(sentences[s0].start), end=float(sentences[s1].end),
                sentence_range=(s0, s1), keywords=t.keywords)
            chapter.children_ids.append(tid)
            nodes.append(topic)
    return ContentMap(root_id="video", nodes=nodes, engine="treeseg")


def _build_content_map_treeseg(sentences: list[Sentence], settings: dict,
                               progress: ProgressCb = None) -> ContentMap:
    n = len(sentences)
    duration = float(sentences[-1].end) - float(sentences[0].start)
    k = int(round(duration / config.TREESEG_TARGET_TOPIC_SEC))
    k = max(config.TREESEG_MIN_TOPICS, min(config.TREESEG_MAX_TOPICS, k))
    if n < 2 * config.TREESEG_MIN_TOPIC_SENTS or k <= 1:
        segments, split_order = [(0, n - 1)], []          # too small to segment — one topic
    else:
        emb = embed_sentences(sentences)                   # raises → caller falls back to legacy
        priors = boundary_priors(sentences, config.TREESEG_PAUSE_PRIOR)
        segments, split_order = divisive_segments(
            emb, target_k=k, min_size=config.TREESEG_MIN_TOPIC_SENTS,
            coherence_floor=config.TREESEG_COHERENCE_FLOOR, priors=priors)
    if progress:
        progress(0.6, f"Segmented into {len(segments)} topics")
    labels = _label_segments(segments, sentences)
    chapters = chapter_cut(split_order, segments, config.CHAPTER_MAX_TOPICS)
    if progress:
        progress(1.0, f"Labeled {len(segments)} topics")
    return _assemble_treeseg(sentences, segments, labels, chapters)
```

e) New dispatcher (public API, signature unchanged):

```python
def build_content_map(sentences: list[Sentence], settings: dict,
                      progress: ProgressCb = None) -> ContentMap:
    """Topic partition + labels. Engine "treeseg" (default): deterministic embedding
    boundaries + LLM labels; "llm": the legacy per-chunk LLM pass. Treeseg failure
    degrades to the legacy engine (engine="llm-fallback") — never crashes the job."""
    if not sentences:
        return ContentMap(nodes=[ContentNode(node_id="video", level="video")])
    engine = str(settings.get("content_map_engine") or config.CONTENT_MAP_ENGINE)
    if engine == "treeseg":
        try:
            return _build_content_map_treeseg(sentences, settings, progress)
        except Exception:
            cm = _build_content_map_llm(sentences, settings, progress)
            cm.engine = "llm-fallback"
            return cm
    cm = _build_content_map_llm(sentences, settings, progress)
    cm.engine = "llm"
    return cm
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/understand/tests/test_content_map_treeseg.py -q`
Expected: 6 passed.

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: all pass, compile clean.

---


"""build_structure — run the topic-independent understanding stages (spec §1–6).

Phase 1 is transcript-only: content map → atomic units (role + concepts + references
in one pass) → dependency graph. Perception (scenes/OCR/vision/diarization) is layered
in ahead of unit extraction in Phase 2; here ``has_perception`` stays False and visual
fields stay empty. The result is a ``Structure`` the caller caches per video_id.
"""
from __future__ import annotations

from typing import Callable, Optional

from ..sentences import Sentence
from .content_map import build_content_map
from .dependencies import build_dependency_graph
from .models import Structure
from .units import extract_units

ProgressCb = Optional[Callable[[float, str], None]]


def _scale(lo: float, hi: float, frac: float) -> float:
    return lo + (hi - lo) * max(0.0, min(1.0, frac))


def build_structure(video_id: str, transcript: dict, sentences: list[Sentence], adapter,
                    detection, settings: dict, progress: ProgressCb = None,
                    perception=None) -> Structure:
    def sub(lo: float, hi: float):
        def cb(frac: float, msg: str = "") -> None:
            if progress:
                progress(_scale(lo, hi, frac), msg)
        return cb

    content_map = build_content_map(sentences, settings, sub(0.00, 0.30))
    units = extract_units(sentences, content_map, adapter, settings, sub(0.30, 0.80), perception)
    dependencies = build_dependency_graph(units, settings, sub(0.80, 1.00))

    visual_events = list(perception.visual_events) if perception else []
    return Structure(
        video_id=video_id,
        title=transcript.get("title", "") or "",
        duration=float(transcript.get("duration", 0.0) or 0.0),
        detection=detection,
        content_map=content_map,
        units=units,
        dependencies=dependencies,
        visual_events=visual_events,
        has_perception=bool(visual_events),
        degraded=list(perception.degraded) if perception else [],
    )

# Task 1 Report: Config block + schema bump + ContentMap.engine

## Summary

Implemented schema groundwork for embedding-based segmentation (TreeSeg). All changes strictly follow the brief: TDD test-first, all 5 new tests pass, full test suite passes, and compilation is clean.

## What Was Implemented

1. **Schema version bump**: `SCHEMA_VERSION 3 → 4` in `backend/pipeline/understand/models.py` (line 18)
   - Comment reflects cache invalidation for TreeSeg boundaries
   
2. **ContentMap.engine field**: Added `engine: str = ""` to ContentMap class (line 108 in models.py)
   - Default empty string, can be "treeseg" | "llm" | "llm-fallback"
   
3. **TREESEG config block**: Added 8 config variables to `backend/config.py` (lines 194–205)
   - `CONTENT_MAP_ENGINE`: Default "treeseg", env-configurable
   - `TREESEG_TARGET_TOPIC_SEC`: 120.0 (float, env-configurable)
   - `TREESEG_MIN_TOPICS`: 2
   - `TREESEG_MAX_TOPICS`: 24
   - `TREESEG_MIN_TOPIC_SENTS`: 3
   - `TREESEG_COHERENCE_FLOOR`: 0.0 (float, env-configurable)
   - `TREESEG_PAUSE_PRIOR`: 0.15 (float, env-configurable)
   - `TREESEG_LABEL_BATCH`: 12
   
4. **DEFAULTS entry**: Added `"content_map_engine": None` to config.DEFAULTS dict (line 129)
   - Allows per-job override, None inherits config.CONTENT_MAP_ENGINE
   
5. **Test infrastructure**: 
   - Created `backend/pipeline/understand/tests/__init__.py` (empty, per brief)
   - Created `backend/pipeline/understand/tests/test_models_v4.py` with 5 tests

## TDD Evidence

### RED (Initial Failure)
```bash
$ .venv/bin/python -m pytest backend/pipeline/understand/tests/test_models_v4.py -q
FFFFF
```

Failures as expected:
- `test_schema_version_is_4`: SCHEMA_VERSION was 3
- `test_content_map_engine_field_defaults_empty`: ContentMap had no engine attribute
- `test_engine_field_roundtrips_through_structure_cache`: engine attribute missing
- `test_v3_cache_is_invalidated`: cache not invalidated (fixed by schema bump)
- `test_treeseg_config_block`: config attributes missing

### GREEN (Implementation Complete)
```bash
$ .venv/bin/python -m pytest backend/pipeline/understand/tests/test_models_v4.py -q
.....
5 passed in 0.44s
```

### Checkpoint (Full Suite + Compilation)
```bash
$ .venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend
68 passed in 0.91s
```
- 5 new tests passing
- 63 existing tests still passing
- Compilation clean (no output = success)

## Files Changed

- `backend/pipeline/understand/models.py`: SCHEMA_VERSION bump (line 18), ContentMap.engine (line 108)
- `backend/config.py`: TREESEG config block (lines 194–205), DEFAULTS entry (line 129)
- `backend/pipeline/understand/tests/__init__.py`: Created (empty)
- `backend/pipeline/understand/tests/test_models_v4.py`: Created (5 tests)

## Self-Review

✓ **Completeness**: All required fields, env vars, defaults, and tests from brief implemented.
✓ **Adherence to brief**: Exact values, exact defaults, exact file paths, exact test names and assertions.
✓ **No extras**: No code beyond the brief (YAGNI); minimal, focused changes.
✓ **TDD discipline**: Test written first, fails for correct reason, implementation passes all tests.
✓ **Cache invalidation**: Schema bump from 3→4 properly invalidates old caches (verified by test_v3_cache_is_invalidated).
✓ **Offline**: All tests run offline, no network/LLM calls.

## Concerns

None. Task completed as specified.

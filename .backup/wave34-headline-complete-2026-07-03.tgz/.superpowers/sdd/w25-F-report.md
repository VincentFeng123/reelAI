# W25-F report — refund unlock + severed-pair relaxation + practice-clip preservation

Spec: `docs/superpowers/plans/2026-07-02-wave-2.5-coverage.md` §W25-F (root causes 11-13).
Suite: **556 passing before → 570 passing after** (16 tests added, 2 stale tests removed/
replaced under spec-governs; `compileall` clean). All new tests offline (llm_json
monkeypatched; zero network / zero live LLM).

## What changed and why

### 1. Refund clash gate — `backend/pipeline/assemble/__init__.py`
Pre-W25-F any 1-sentence overlap between a refund-round spec and a shipped spec killed the
newcomer outright ("refund overlap loser"), making round-0 mistakes permanent (the qP c0.t1
sliver lock). Now, per newcomer:
- **(a) strict-superset REPLACE**: when the newcomer strictly contains (sentence-index
  containment, strict) EVERY clashing incumbent AND its fresh verdict is clean
  (`_refund_clean`: `hard_gates_ok` + not `ship_flagged` + not `judge_error` — the
  hard-core bar of the verdict covering its final text), the incumbents are removed from
  `specs` and each is ledgered at stage `'dedupe'`, reason
  `'superseded by refund superset <cand_id>'`. New stat
  `stats["n_refund_superset_replaced"]` (initialized 0, incremented per displaced
  incumbent). The kept+rejected accounting invariant is preserved: every displaced
  incumbent gains a ledger row; nothing is silently dropped.
- **(b) partial-overlap TRIM** (`_refund_trim`): before rejecting, the newcomer's start is
  moved past `max(clash ends)` via `refine._trim_start_after` (sentence-true boundary,
  adds the existing `trimmed_start` warning). The trimmed spec is then made truthful
  (units whose sentences left the span leave `unit_ids`; `integrity.true_contents`
  re-absorbs and prunes referential) and its NEVER-judged trimmed text is re-judged under
  a freshly bound contract (verdict cache-aware, same key scheme as the 4b seam). It ships
  ONLY on a clean `is_complete` verdict — with `judged_text_hash` / `hard_gates_ok` /
  completeness / grounding / phantom-stats refreshed exactly like the severed-merge
  closure. Any failure (no boundary past the incumbents, still-clashing result, anchor
  trimmed away, non-clean re-judge, judge outage) returns None and the old
  `'refund overlap loser'` rejection stands (status quo ante — kills nothing new).
- Imports added: `refine._trim_start_after`, `integrity.true_contents`; the assemble stats
  docstring documents the new key.

### 2. Severed pairs — `backend/pipeline/assemble/sequence.py`
The linker fired 0 times everywhere by construction (spec root cause 12). Three fixes:
- `SEVERED_OPENER_ROLES += {practice_prompt, setup}` (practice_prompt was the most common
  opener on qP — 27 units — and wasn't an opener at all).
- The LINK pass (pass 2) scans **non-adjacent** later clips: for each opener clip, every
  later clip whose `start` is within `SEVERED_MAX_GAP_S` of its `end` is considered
  (start-sorted, so the scan breaks at the first gap overrun); the NEAREST matching payoff
  is linked (one pair per opener). The MERGE pass stays adjacency+cap gated as specified
  (a union across an intervening clip would swallow it).
- The blanket "later has no opener roles" test is replaced by the pair-scoped
  `_pair_opener_in_later`: an opener unit inside the later clip blocks the pair only when
  it demonstrably belongs to THIS pair's problem — (a) a later payoff unit's `answers`
  edge targets it (the later clip restates and answers its own prompt → genuinely
  self-contained), or (b) it shares concepts (introduced ∪ required) with the earlier
  clip's units (same problem restated). An opener with neither tie (a different problem's
  setup that drifted in) no longer vetoes the link. Linking kills nothing, so the
  relaxation is safe by construction. `graph` is now threaded into `is_severed_pair`
  (optional kwarg, default None → concepts-only evidence) from both link_severed_pairs
  passes.

### 3. Practice-clip preservation — `backend/pipeline/assemble/validate.py`
`expand_candidate` gained an `adapter=None` kwarg (validate_and_repair passes it) and a
contract-exclusion gate: pulls of elements the BOUND contract deliberately excludes are
disabled, for BOTH the boolean fallbacks and the kind-targeted hints. An element family
(problem/reasoning/result — the three pull families that correspond to contract elements)
is allowed iff no contract binds (pre-W25-F behavior preserved for contract-free spans /
FakeAdapter tests), OR its verdict boolean is in `required_verdict_fields(contract_role)`,
OR any contract element (any necessity) is satisfiable by the family's pull roles. The
roles per family mirror exactly what pull_problem/pull_reasoning/pull_result pull.
Concretely: a practice_prompt-bound clip (contract has NO solution/steps elements and
result/reasoning booleans are not contract-required) never gets `pull_result` /
`pull_reasoning` off `result_complete=False` — so choose_contract's specificity tie-break
never sees a solution unit and the practice→solution conversion never starts. The
kind-hint branches still CONSUME a gated kind (no fall-through to a wrong family).

## Tests (16 added; per-part)
- `test_selection_budget.py` (+3, −1): superset replace + ledger + stats; flagged newcomer
  never replaces and falls back to the old rejection (trim re-judge fails too); partial
  overlap trimmed, truthfully re-united, re-judged clean, and SHIPPED.
- `test_dedupe_severed.py` (+7, −1): pair-scoped blocking via answers-edge and via shared
  concepts; unrelated later opener no longer vetoes; opener-role constants; non-adjacent
  link across an intervening clip; gap cap still respected on the non-adjacent scan; and
  the acceptance shape — a practice_prompt clip ships standalone and is LINKED to its
  solution clip (merge cap-gated off) through assemble_clips end-to-end.
- `test_practice_preservation.py` (NEW, +6): boolean pull gating under practice_prompt vs
  solution contracts; reasoning pull gating; kind-hint gating; contract-free spans keep
  the pre-W25-F pull; integration — the repair loop ships the practice clip un-grown,
  still bound to practice_prompt, with zero growth probes judged.

## Deviations (spec governs over stale tests)
1. `test_is_severed_pair_requires_payoff_without_setup_on_later` (test_dedupe_severed.py)
   REPLACED: it pinned the blanket later-side veto the spec explicitly removes. Its
   fixture (evidence-free later opener) now reads as "no tie to this pair → allowed";
   the blocking behavior it meant to pin is re-pinned pair-scoped by two new tests
   (answers-edge tie, shared-concepts tie).
2. `test_refund_spec_overlapping_shipped_clip_is_dropped_and_ledgered`
   (test_selection_budget.py) REPLACED: its fixture is exactly the strict-superset
   lock-in shape the spec unlocks, so under W25-F it replaces instead of dropping.
   Renamed to `test_refund_superset_replaces_incumbent_and_ledgers_it` with the new
   expectations; the drop+ledger path is re-pinned by the new flagged-newcomer test.
3. `test_budget_clamp.py` spy signature updated (`adapter=None` passthrough) —
   `expand_candidate` grew an adapter kwarg; existing positional callers are unaffected.
4. Design decision the spec's trim clause left open: a trimmed refund candidate is
   RE-JUDGED (clean-or-reject) rather than shipped with a stale verdict — the Wave-1
   trust rule ("a verdict is valid only for the exact text it was issued on") governs;
   a non-clean re-judge falls back to the pre-W25-F rejection, so nothing new dies.
5. The exclusion gate is the UNION of required_verdict_fields and contract-element
   satisfiability (the spec offers both signals): required_verdict_fields alone would
   over-block e.g. 'procedure' (steps are a required element but procedure is not in
   _PROBLEM_ROLES, so reasoning_complete isn't verdict-required).
6. `n_refund_superset_replaced` counts displaced INCUMBENTS (a superset containing two
   slivers counts 2) — the more informative accounting for the eval column W25-G wires.

## Verification
- `cd /Users/vincentfeng/Documents/practice/clips && .venv/bin/python -m pytest backend -q`
  → 570 passed.
- `.venv/bin/python -m compileall backend -q` → clean.
- Needle checks (python `in` assertions) confirmed every edit landed.

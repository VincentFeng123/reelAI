# Task 4 Report: `build.py` Degrade Marker

## Summary

Implemented degrade marker for content_map fallback engine in `build_structure()`. When treeseg fails and the fallback LLM engine is used, `Structure.degraded` now contains `"content_map"` to signal degraded content understanding.

## TDD Evidence

### RED (Failing Test)
Appended `test_build_structure_records_content_map_fallback` to `backend/pipeline/understand/tests/test_content_map_treeseg.py`. Test monkeypatches `build_content_map` to return `ContentMap(..., engine="llm-fallback")` and asserts `"content_map" in st.degraded`. Test failed as expected:
```
AssertionError: assert 'content_map' in []
```

### GREEN (Passing Implementation)
Modified `backend/pipeline/understand/build.py` (lines 38–51):
- Extract `degraded` list from perception (if present)
- Check `if content_map.engine == "llm-fallback"`
- Append `"content_map"` to degraded list when condition met
- Return Structure with updated degraded list

Test now passes. All 86 backend tests pass. Compileall passes.

## Files Modified

1. **backend/pipeline/understand/tests/test_content_map_treeseg.py** (+1 test)
   - Added `test_build_structure_records_content_map_fallback` 
   - Uses monkeypatching to isolate `build_structure` with fallback ContentMap
   - Imports `DetectionResult()` (pydantic validation requires this, not `None`)

2. **backend/pipeline/understand/build.py** (lines 38–51)
   - Extracted degraded list handling to variable for modification
   - Added engine check and append logic per brief specification
   - Preserved all other Structure field logic

## Concerns

None. Pydantic validation required `DetectionResult()` instead of `None` for the test's `detection` parameter (documented in brief as fallback behavior).

## Checkpoint Results

```
$ .venv/bin/python -m pytest backend -q
86 passed in 0.19s

$ .venv/bin/python -m compileall -q backend
[No errors]
```

All tests pass. Compile clean.

### Task 5: Card integrity — extractive fallback + missing-card warning

**Files:**
- Modify: `backend/pipeline/assemble/context_card.py::generate_context_card`
- Modify: `backend/pipeline/assemble/__init__.py` step 6 (warning append)
- Test: append to `backend/pipeline/assemble/tests/test_integrity.py`

**Interfaces:**
- Consumes: `spec["referential"]`, `spec["truncated"]`, `spec["unit_ids"]` (Tasks 2-4).
- Produces: `generate_context_card` never returns "" when referential context exists (extractive fallback); step 6 appends `"missing_context_card"` when a needed card is still empty.

- [ ] **Step 1: Write the failing tests** (append to `test_integrity.py`)

```python
# ── card integrity ────────────────────────────────────────────────────────────
from backend.pipeline.assemble.context_card import generate_context_card


def test_card_llm_failure_falls_back_to_referential_summary(monkeypatch):
    def boom(*a, **kw):
        raise RuntimeError("card llm down")
    monkeypatch.setattr(llm_mod, "llm_json", boom)
    sents, units = _setup()
    units_by_id = {u.unit_id: u for u in units}
    units_by_id["u0005"].summary = "Definition of the derivative from first principles."
    spec = {"referential": [("u0005", "prerequisite")], "anchor_id": "u0000",
            "unit_ids": ["u0000"], "truncated": True}
    card = generate_context_card(spec, units_by_id, FakeAdapter(), "derivatives")
    assert "derivative" in card.lower()                  # extractive, verbatim from summary


def test_card_skips_referential_already_inside_clip(monkeypatch):
    monkeypatch.setattr(llm_mod, "llm_json", lambda *a, **kw: (_ for _ in ()).throw(RuntimeError()))
    sents, units = _setup()
    units_by_id = {u.unit_id: u for u in units}
    spec = {"referential": [("u0001", "prerequisite")], "anchor_id": "u0000",
            "unit_ids": ["u0000", "u0001"], "truncated": False}
    assert generate_context_card(spec, units_by_id, FakeAdapter(), "") == ""   # nothing outside clip


def test_missing_card_warning_appended():
    # pure: the step-6 helper logic — needed context, empty card → warning
    from backend.pipeline.assemble import _card_warning
    s = {"context_card": "", "referential": [("u0005", "prerequisite")], "truncated": False,
         "warnings": ("x",)}
    _card_warning(s)
    assert "missing_context_card" in s["warnings"] and "x" in s["warnings"]
    s2 = {"context_card": "has one", "referential": [("u0005", "p")], "warnings": ()}
    _card_warning(s2)
    assert "missing_context_card" not in s2["warnings"]
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/test_integrity.py -q`
Expected: FAIL — card returns "" on LLM failure; no `_card_warning`.

- [ ] **Step 3: Implement**

a) `context_card.py::generate_context_card` — filter inlined referential up front, and add the
extractive fallback:

```python
def generate_context_card(spec: dict, units_by_id: dict[str, Unit], adapter, topic: str) -> str:
    in_clip = set(spec.get("unit_ids", []))
    ref_pairs = [(uid, rel) for uid, rel in spec.get("referential", [])
                 if uid in units_by_id and uid not in in_clip]
    ref_units = [units_by_id[uid] for uid, _rel in ref_pairs]
    if not ref_units:
        return ""
    anchor = units_by_id.get(spec.get("anchor_id", ""))
    allowed = {u.unit_id: u for u in (([anchor] if anchor else []) + ref_units)}
    rows = "\n".join(f"{u.unit_id}: {u.summary}" for u in allowed.values())
    from ...llm import llm_json
    system = _CARD_SYSTEM.format(max_words=config.CONTEXT_CARD_MAX_WORDS)
    user = f"TOPIC: {topic or '(general)'}\n\nUNITS (earlier context for the clip):\n{rows}\n\nWrite the preface."
    card = ""
    try:
        draft = llm_json(system, user, ContextCardDraft, temperature=0.2)
        kept = [cs.text.strip() for cs in draft.sentences
                if cs.source_unit_id in allowed and _grounded(cs.text, allowed[cs.source_unit_id])]
        card = " ".join(t for t in kept if t)
    except Exception:
        card = ""
    if not card:
        # extractive fallback: verbatim referential-unit summary — grounded by construction
        for u in ref_units:
            if (u.summary or "").strip():
                card = u.summary.strip()
                break
    words = card.split()
    if len(words) > config.CONTEXT_CARD_MAX_WORDS:     # hard word budget (prompt asks for it too)
        card = " ".join(words[:config.CONTEXT_CARD_MAX_WORDS])
    return card
```

b) `assemble/__init__.py` — module-level helper + step-6 use:

```python
def _card_warning(s: dict) -> None:
    """A clip that NEEDS earlier context (referential prereqs or truncated closure) but has no
    card ships with an explicit, penalized marker instead of failing silently."""
    if not s.get("context_card") and (s.get("referential") or s.get("truncated")):
        s["warnings"] = tuple(set(s.get("warnings") or ()) | {"missing_context_card"})
```

```python
    # 6. context cards -------------------------------------------------------
    emit(0.90, "Writing context cards…")
    for s in specs:
        s["context_card"] = generate_context_card(s, units_by_id, adapter, topic)
        _card_warning(s)
```

NOTE ordering: `_card_warning` runs AFTER step 5 computed `boundary_score`, so re-derive the
two scores for flagged specs right there:

```python
        if "missing_context_card" in (s.get("warnings") or ()):
            s["boundary_score"] = scoring.boundary_score(s.get("warnings"))
            s["final_quality"] = scoring.quality(
                s.get("completeness_score", 0.0), s.get("grounding_score", 0.0),
                s["boundary_score"], s.get("priority", 0.0))
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/ -q`
Expected: 37 passed.

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: 129 passed, compile clean.

---


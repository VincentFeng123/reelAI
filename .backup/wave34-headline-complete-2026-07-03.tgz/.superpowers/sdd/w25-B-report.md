# W25-B report — drift telemetry + punctuation retry + graph hygiene

Spec: `docs/superpowers/plans/2026-07-02-wave-2.5-coverage.md` §W25-B.
Tests: 470 before → 484 after (14 new), 100% green. `compileall backend` clean.
Snapshots of every edited file: `.superpowers/sdd/snap-w25-B/`.

## What changed and why

### 1. Unit-boundary drift telemetry (was fully silent)
- `backend/pipeline/understand/units.py`
  - The `s0 = max(s0, cursor)` non-overlap clamp (was :169) now writes
    `'boundary_clamped'` into `Unit.warnings` **only when it actually moves s0**
    (i.e. `cursor > s0` — the LLM double-claimed a sentence and every later unit
    in the topic cascades). `Unit.warnings` existed but was never written.
  - New `drift_stats(units, content_map, n_sentences) -> (n_clamped, n_uncovered)`:
    counts clamp-warned units plus sentence indices inside the unit-bearing topic
    partition that NO unit covers (units should partition each topic; qP had 23
    uncovered indices). Mirrors `extract_units`' partition exactly (same
    `topics() or nodes[:1]` fallback, same range clamping).
- `backend/pipeline/understand/build.py`
  - `build_structure` rolls the counts into a structure-level note:
    `"unit_drift: {n} boundary_clamped unit(s), {m} uncovered sentence(s)"` appended
    to `Structure.degraded` (only when either count is nonzero), and extends
    `Structure.degraded` with `dependencies.degraded` (see §3).

### 2. Punctuation cache: degraded artifacts become retry-eligible
- `backend/pipeline/punctuation/service.py` (cache.py itself unchanged — the status
  gate lives at the two serve points, so the cached content stays loadable as the
  never-worse floor)
  - **Artifact level** (`restore_transcript_punctuation`): a cached artifact with
    `status='degraded'` no longer early-returns; the run proceeds to ONE fresh
    attempt (per-chunk caches make this cheap: complete chunks replay, degraded
    chunks retry). If the fresh pass rolls up `degraded` again, the CACHED artifact
    is returned and left on disk byte-for-byte (a failed retry never overwrites —
    the fresh pass could even be worse, e.g. a full-validation fallback wiping
    chunks that were fine). A successful retry saves + returns the new artifact.
  - **Chunk level** (`_annotate_chunk`): a cached chunk with `status='degraded'` no
    longer short-circuits — the fresh ladder runs once; on total failure the cached
    degraded annotations are returned unchanged (no re-save). Without this the
    artifact-level retry would just replay the degraded chunks and be a no-op.
  - Net semantics: one fresh attempt per run, monotone improvement, never worse.
    This unblocks qP's live index (183 degraded run-on sentences served forever).

### 3. Dependency-graph hygiene
- `backend/pipeline/understand/dependencies.py`
  - `_introducer` returns `None` when no PRIOR introducer exists — the
    `return lst[0]` future-unit fallback is gone, in BOTH modes (earliest =
    `requires`, nearest = reference resolution / `refers_to`). This was the
    producer of forward-in-time edges (qP: u0020/u0021 "required" u0035 at +124s)
    that polluted closure referential lists, cards, and judge prerequisite inputs.
    Unresolvable references now keep `source_unit=None` instead of pointing forward.
  - The LLM edge-pass failure (was a bare `except: pass`) now records
    `"dependency_llm_edges: {ExcType}: {msg}"` into a new `DependencyGraph.degraded`
    list, which `build_structure` folds into `Structure.degraded` — the graph still
    ships on rule edges alone, but the loss is visible.
  - Forward-requires graph lint: `DependencyGraph.forward_requires_count` counts
    `requires` edges whose source precedes its target in unit order on the FINAL
    deduped graph. Rule/bridge edges are backward by construction post-fix, so any
    nonzero count is an LLM direction-contract violation (counted as telemetry, not
    filtered; spec expects 0 on live runs — W25-G wires the eval column).
- `backend/pipeline/understand/models.py`
  - `DependencyGraph` gains `degraded: list[str]` and `forward_requires_count: int = 0`.
    Pydantic-additive: old cached structures validate with clean defaults;
    `SCHEMA_VERSION` deliberately not bumped (telemetry-only fields; W25-A freshness
    gating governs cache validity).

## Tests added (14)
- `backend/pipeline/understand/tests/test_drift_telemetry.py` (11):
  clamp-warning emission when the cursor moves a boundary / no warning when clean;
  `drift_stats` arithmetic (clamps + gaps, clean partition = (0,0));
  `build_structure` emits the `unit_drift` note + folds the edge-pass note / no note
  on clean builds; no-prior-introducer ⇒ no `requires` AND no `refers_to` edge and
  `source_unit` stays None; prior introducer still resolves backward; edge-pass
  failure ⇒ `dependency_llm_edges` degraded note (success ⇒ none); forward-requires
  lint counts an injected LLM direction violation.
- `backend/pipeline/punctuation/tests/test_degraded_retry.py` (3):
  degraded artifact retried once and REPLACED on success (and the healed artifact
  serves from cache afterwards, provider untouched); failed retry keeps the artifact
  byte-for-byte, still returns a usable degraded result, and stays retry-eligible on
  the NEXT run; non-degraded artifacts keep serve-from-cache (provider never called).

## Deviations
- None from the spec. No existing test contradicted the spec, so none were changed
  (the pre-existing `test_graph_nutrition` fixtures only exercise prior-introducer
  paths and pass unchanged; `test_content_map_treeseg`'s exact-member `degraded`
  assertions are unaffected by the additive `unit_drift` note).
- Placement note: the spec offered "Structure.degraded or stats" for the drift
  counts — chose `Structure.degraded` (persisted, human-readable, same channel the
  content-map fallback already uses). The forward-requires lint count is persisted
  on `DependencyGraph.forward_requires_count` (structure-level stats) so W25-G's
  `forward_requires_edges` eval column can read it without a re-walk.
- The degraded-status gate for the punctuation cache lives in `service.py` (the two
  serve points), not `cache.py`: load must still RETURN degraded content so it can
  serve as the keep-on-failed-retry floor.

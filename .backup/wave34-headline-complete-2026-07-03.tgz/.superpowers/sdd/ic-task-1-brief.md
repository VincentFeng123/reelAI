### Task 1: `integrity.py` — pure helpers + Rejection

**Files:**
- Create: `backend/pipeline/assemble/integrity.py`
- Test: `backend/pipeline/assemble/tests/test_integrity.py` (uses existing `tests/conftest.py` fixtures `mini_sents`, `mini_units`)

**Interfaces:**
- Produces:
  - `true_contents(unit_ids: list[str], referential: list[tuple[str, str]], units: list, i_start: int, i_end: int) -> tuple[list[str], list[tuple[str, str]]]`
  - `merge_partb(a: dict, b: dict, units: list | None, sentences: list) -> dict`
  - `@dataclass Rejection(cand_id, title, role, stage, reason, score, failure_kinds, final_quality, start, end)`

- [ ] **Step 1: Write the failing tests**

```python
# backend/pipeline/assemble/tests/test_integrity.py
"""integrity helpers: truthful unit_ids, Part-B merge, Rejection. Pure/offline."""
from __future__ import annotations

import pytest

from backend.pipeline.assemble.integrity import Rejection, merge_partb, true_contents

from .conftest import mini_sents, mini_units


def _setup(n=6):
    sents = mini_sents(n)
    units = mini_units(sents)          # unit i ↔ sentence i, ids u0000..u000{n-1}
    return sents, units


# ── true_contents ─────────────────────────────────────────────────────────────
def test_absorbs_spanned_units_time_ordered():
    sents, units = _setup()
    ids, ref = true_contents(["u0000", "u0003"], [], units, 0, 3)
    assert ids == ["u0000", "u0001", "u0002", "u0003"]   # gap units absorbed, ordered
    assert ref == []


def test_drops_referential_now_inside_span():
    sents, units = _setup()
    ids, ref = true_contents(["u0000", "u0002"], [("u0001", "prerequisite"), ("u0005", "prerequisite")],
                             units, 0, 2)
    assert "u0001" in ids                                # was referential, now in-span → absorbed
    assert ref == [("u0005", "prerequisite")]            # outside span → untouched


def test_idempotent():
    sents, units = _setup()
    once = true_contents(["u0000", "u0003"], [("u0005", "x")], units, 0, 3)
    twice = true_contents(once[0], once[1], units, 0, 3)
    assert once == twice


def test_partial_overlap_unit_not_absorbed():
    sents, units = _setup()
    # unit u0003 spans sentence 3 only; span [0,2] must not absorb it
    ids, _ = true_contents(["u0000"], [], units, 0, 2)
    assert "u0003" not in ids


# ── merge_partb ───────────────────────────────────────────────────────────────
def _spec(cand_id, s0, s1, sents, *, fq=0.5, facet="other", **extra):
    d = {"cand_id": cand_id, "facet": facet, "role": "explanation", "title": f"t-{cand_id}",
         "anchor_id": "u0000", "unit_ids": [f"u{i:04d}" for i in range(s0, s1 + 1)],
         "referential": [], "start": sents[s0].start, "end": sents[s1].end,
         "cut_end": sents[s1].end, "sentence_start_idx": s0, "sentence_end_idx": s1,
         "score": fq, "final_quality": fq, "warnings": ("w_a",) if cand_id == "a" else ("w_b",),
         "judge_error": False, "truncated": False, "context_card": ""}
    d.update(extra)
    return d


def test_merge_unions_span_ids_referential_warnings():
    sents, units = _setup()
    a = _spec("a", 0, 2, sents, fq=0.9, referential=[("u0005", "prerequisite")])
    b = _spec("b", 2, 4, sents, fq=0.4)
    m = merge_partb(a, b, units, sents)
    assert m["sentence_start_idx"] == 0 and m["sentence_end_idx"] == 4
    assert m["start"] == sents[0].start and m["end"] == sents[4].end
    assert m["unit_ids"] == [f"u{i:04d}" for i in range(5)]      # union + absorption
    assert m["referential"] == [("u0005", "prerequisite")]        # still outside span
    assert set(m["warnings"]) >= {"w_a", "w_b", "merged_overlap"}
    assert m["merged"] is True
    assert m["title"] == "t-a"                                    # winner metadata (higher fq)


def test_merge_ors_flags_and_keeps_winner_metadata():
    sents, units = _setup()
    a = _spec("a", 0, 1, sents, fq=0.3, judge_error=True)
    b = _spec("b", 1, 2, sents, fq=0.8, truncated=True)
    m = merge_partb(a, b, units, sents)
    assert m["judge_error"] is True and m["truncated"] is True    # OR'd
    assert m["title"] == "t-b"                                    # b wins on final_quality


def test_merge_without_units_skips_absorption():
    sents, _ = _setup()
    a = _spec("a", 0, 0, sents, fq=0.9)
    b = _spec("b", 3, 3, sents, fq=0.1)
    m = merge_partb(a, b, None, sents)
    assert m["unit_ids"] == ["u0000", "u0003"]                    # union only, no sweep


# ── Rejection ─────────────────────────────────────────────────────────────────
def test_rejection_dataclass_shape():
    r = Rejection(cand_id="c1", title="t", role="claim", stage="dedupe",
                  reason="overlap loser to c0", score=0.4, failure_kinds=["off_topic"],
                  final_quality=0.3, start=1.0, end=2.0)
    assert r.stage == "dedupe" and r.failure_kinds == ["off_topic"]
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/test_integrity.py -q`
Expected: FAIL — `ModuleNotFoundError: integrity`.

- [ ] **Step 3: Implement `integrity.py`**

```python
# backend/pipeline/assemble/integrity.py
"""Clip-integrity helpers (audit pkg 1): keep unit_ids truthful at every span change,
merge Part-B specs without losing metadata, and record WHY candidates are dropped.

Pure module — no LLM, no I/O. `refine.py`'s merge/dedupe stays untouched (the legacy
fast path shares it); Part B routes overlaps through merge_partb instead.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Rejection:
    """One dropped candidate + the stage and reason — the assemble run's drop ledger."""
    cand_id: str
    title: str
    role: str
    stage: str            # repair | snap | dedupe | post_merge_judge | quality_floor | max_clips
    reason: str
    score: Optional[float] = None            # last judge score, when one exists
    failure_kinds: list[str] = field(default_factory=list)
    final_quality: Optional[float] = None
    start: float = 0.0
    end: float = 0.0


def true_contents(unit_ids, referential, units, i_start: int, i_end: int):
    """(unit_ids ∪ every unit whose sentence_range lies inside [i_start, i_end], time-ordered;
    referential minus entries now inside the span). Keeps unit_ids the TRUE clip contents so
    contract checks, grounding, repair targeting, and cards see what the viewer sees."""
    have = set(unit_ids)
    for u in units or []:
        s0, s1 = u.sentence_range
        if s0 >= i_start and s1 <= i_end:
            have.add(u.unit_id)
    by_id = {u.unit_id: u for u in units or []}
    ordered = sorted(have, key=lambda uid: (by_id[uid].start if uid in by_id else 0.0, uid))
    new_ref = [(uid, rel) for uid, rel in referential if uid not in have]
    return ordered, new_ref


def merge_partb(a: dict, b: dict, units, sentences) -> dict:
    """Union two overlapping same-facet Part-B specs WITHOUT losing metadata: span/ids/
    referential/warnings union, flags OR'd, other keys from the higher-final_quality side.
    Marks the result merged — the caller MUST re-judge it (its text was never judged)."""
    winner = a if a.get("final_quality", a.get("score", 0.0)) >= b.get("final_quality", b.get("score", 0.0)) else b
    s0 = min(a["sentence_start_idx"], b["sentence_start_idx"])
    s1 = max(a["sentence_end_idx"], b["sentence_end_idx"])
    ids = list(dict.fromkeys(list(a.get("unit_ids", [])) + list(b.get("unit_ids", []))))
    ref = list(dict.fromkeys(list(map(tuple, a.get("referential", []))) +
                             list(map(tuple, b.get("referential", [])))))
    ids, ref = true_contents(ids, ref, units, s0, s1) if units else (ids, [(u, r) for u, r in ref if u not in set(ids)])
    return {
        **winner,
        "start": min(a["start"], b["start"]),
        "end": max(a["end"], b["end"]),
        "cut_end": max(a.get("cut_end", a["end"]), b.get("cut_end", b["end"])),
        "sentence_start_idx": s0,
        "sentence_end_idx": s1,
        "unit_ids": ids,
        "referential": ref,
        "warnings": tuple(set(a.get("warnings") or ()) | set(b.get("warnings") or ()) | {"merged_overlap"}),
        "judge_error": bool(a.get("judge_error")) or bool(b.get("judge_error")),
        "truncated": bool(a.get("truncated")) or bool(b.get("truncated")),
        "merged": True,
    }
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/test_integrity.py -q`
Expected: 9 passed.

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: 115 passed, compile clean.

---


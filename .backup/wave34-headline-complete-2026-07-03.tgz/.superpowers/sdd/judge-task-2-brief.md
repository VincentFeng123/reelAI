### Task 2: Scoring neutrality + unjudged-warning plumbing

**Files:**
- Modify: `backend/pipeline/assemble/scoring.py` (`completeness_score`, `boundary_score`)
- Modify: `backend/pipeline/assemble/boundary_adapt.py` (`candidate_to_boundary_input`, `snap_candidates`)
- Test: append to `backend/pipeline/assemble/tests/test_judge_rubric.py`

**Interfaces:**
- Consumes: `verdict.error` (Task 1); existing `Candidate`, `snap_candidates(cands, sentences, settings) -> list[dict]`.
- Produces: `completeness_score` → 0.5 on error verdicts; snap dicts carry `"judge_error": bool` and error clips have `"unjudged"` appended to `warnings`; `boundary_score` penalizes `"unjudged"` by 0.15.

- [ ] **Step 1: Write the failing tests** (append to test_judge_rubric.py)

```python
# ── ship-but-flag scoring + warning plumbing ─────────────────────────────────
def test_completeness_neutral_on_error():
    from backend.pipeline.assemble.scoring import completeness_score

    class Contracty(FakeAdapter):
        def required_verdict_fields(self, role):
            return ["result_complete"]
    v = JudgeVerdict(error=True)
    assert completeness_score(v, "explanation", Contracty()) == pytest.approx(0.5)


def test_boundary_score_penalizes_unjudged():
    from backend.pipeline.assemble.scoring import boundary_score
    assert boundary_score(["unjudged"]) == pytest.approx(0.85)
    assert boundary_score([]) == pytest.approx(1.0)


def test_snap_flags_and_warns_unjudged():
    from backend.pipeline.assemble.boundary_adapt import snap_candidates

    sents = mini_sents(3)
    ok = _mk_candidate(sents)
    ok.verdict = JudgeVerdict(score_10=9, understandable=True)
    bad = _mk_candidate(sents)
    bad.cand_id, bad.i_start, bad.i_end = "c1", 1, 2
    bad.start, bad.end = sents[1].start, sents[2].end
    bad.verdict = JudgeVerdict(error=True)

    specs = snap_candidates([ok, bad], sents, {"min_clip_duration_s": 1.0,
                                               "max_clip_duration_s": 500.0})
    flagged = {s["cand_id"]: s for s in specs}
    assert flagged["c1"]["judge_error"] is True
    assert "unjudged" in (flagged["c1"].get("warnings") or [])
    assert flagged["c0"]["judge_error"] is False
    assert "unjudged" not in (flagged["c0"].get("warnings") or [])
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/test_judge_rubric.py -q`
Expected: the 3 new tests FAIL (`judge_error` KeyError; completeness ≠ 0.5; boundary_score == 1.0).

- [ ] **Step 3: Implement**

In `scoring.py::completeness_score`, add before the `req` line:

```python
    if getattr(verdict, "error", False):
        return 0.5                # unjudged (ship-but-flag): below judged-good, above judged-bad
```

In `scoring.py::boundary_score`, add to the penalty sum:

```python
               + 0.15 * ("unjudged" in w)
```

In `boundary_adapt.py::candidate_to_boundary_input`, add to the returned dict:

```python
        "judge_error": bool(getattr(cand.verdict, "error", False)),
```

In `boundary_adapt.py::snap_candidates`, after the `specs.append({**b, **snapped})` loop and BEFORE `_dedupe`, insert:

```python
    for s in specs:
        if s.get("judge_error"):   # unjudged (judge outage): user-visible + boundary_score penalty
            s["warnings"] = list(s.get("warnings") or []) + ["unjudged"]
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/ -q`
Expected: 13 passed.

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: 101 passed, compile clean.

---


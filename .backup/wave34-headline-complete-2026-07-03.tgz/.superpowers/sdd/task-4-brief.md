### Task 4: `build.py` degrade marker

**Files:**
- Modify: `backend/pipeline/understand/build.py` (lines 34–50)
- Test: append to `backend/pipeline/understand/tests/test_content_map_treeseg.py`

**Interfaces:**
- Consumes: `ContentMap.engine` (Task 1), `build_content_map` (Task 3).
- Produces: `Structure.degraded` contains `"content_map"` iff `engine == "llm-fallback"`.

- [ ] **Step 1: Write the failing test** (append to `test_content_map_treeseg.py`)

```python
def test_build_structure_records_content_map_fallback(monkeypatch):
    from backend.adapters import generic
    from backend.pipeline.understand import build as build_mod
    from backend.pipeline.understand.models import ContentMap, ContentNode

    def fake_cm(sentences, settings, progress=None):
        return ContentMap(nodes=[ContentNode(node_id="video", level="video",
                                             sentence_range=(0, len(sentences) - 1))],
                          engine="llm-fallback")
    monkeypatch.setattr(build_mod, "build_content_map", fake_cm)
    monkeypatch.setattr(build_mod, "extract_units", lambda *a, **kw: [])
    monkeypatch.setattr(build_mod, "build_dependency_graph",
                        lambda units, settings, progress=None: __import__(
                            "backend.pipeline.understand.models",
                            fromlist=["DependencyGraph"]).DependencyGraph())

    sents = make_sents(4)
    st = build_mod.build_structure("vidX", {"title": "t"}, sents,
                                   generic.GenericAdapter(), None, {})
    assert "content_map" in st.degraded
```

Note: `detection=None` is acceptable — `Structure.detection` has a default factory and
`build_structure` passes it through; if pydantic rejects `None`, construct
`from backend.adapters.detect import DetectionResult` and pass `DetectionResult()` instead.

- [ ] **Step 2: Run test to verify it fails**

Run: `.venv/bin/python -m pytest backend/pipeline/understand/tests/test_content_map_treeseg.py::test_build_structure_records_content_map_fallback -q`
Expected: FAIL — `"content_map" not in []`.

- [ ] **Step 3: Implement** — in `build.py`, replace the return-block tail:

```python
    visual_events = list(perception.visual_events) if perception else []
    degraded = list(perception.degraded) if perception else []
    if content_map.engine == "llm-fallback":
        degraded.append("content_map")             # treeseg failed; legacy LLM engine used
    return Structure(
        video_id=video_id,
        title=transcript.get("title", "") or "",
        duration=float(transcript.get("duration", 0.0) or 0.0),
        detection=detection,
        content_map=content_map,
        units=units,
        dependencies=dependencies,
        visual_events=visual_events,
        has_perception=bool(visual_events),
        degraded=degraded,
    )
```

(If Step 1's `detection=None` fails validation, keep the test's `DetectionResult()` variant.)

- [ ] **Step 4: Run test to verify it passes**

Run: `.venv/bin/python -m pytest backend/pipeline/understand/tests/ -q`
Expected: all pass (22 in this package).

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: all pass, compile clean.

---


# Task 2 Report: Truthful unit_ids at build/repair + repair Rejections

## What Was Done

Threaded `true_contents` through the candidate lifecycle so `unit_ids`/`referential` stay
truthful at every span change, and changed `validate_and_repair` to return
`(Optional[Candidate], Optional[Rejection])` so dropped candidates carry their last verdict
into the ledger.

## TDD Evidence

- **RED**: 3 new tests appended to `test_integrity.py` failed as expected:
  - `test_expand_candidate_emits_true_contents` — assertion failed (absorption not happening)
  - `test_repair_drop_returns_rejection_with_last_verdict` — `TypeError: cannot unpack non-iterable NoneType`
  - `test_repair_keep_returns_no_rejection` — `TypeError: cannot unpack non-iterable Candidate`
- **GREEN**: After implementation, `backend/pipeline/assemble/tests/` → **25 passed**
- **Checkpoint**: `backend -q` → **117 passed**, `compileall -q backend` → clean

## Files Changed

- `backend/pipeline/assemble/candidates.py` — imported `true_contents` at module level; called it on `cl.unit_ids`/`cl.referential` before constructing `Candidate`
- `backend/pipeline/assemble/validate.py` — (1) `expand_candidate` final replace now calls `true_contents(new_ids, cand.referential, units, i0, i1)` to absorb spanned units and drop in-span referential; (2) `validate_and_repair` signature → `tuple[Optional[Candidate], Optional["Rejection"]]`; three `return cand`/`return best` → `return cand/best, None`; final `return None` → `return None, Rejection(stage="repair", score=last.score, ...)`
- `backend/pipeline/assemble/__init__.py` — `_assemble_one` unpacks tuple; `rejections: list` + `rej_lock` defined in enclosing scope; rejections appended thread-safely
- `backend/pipeline/assemble/tests/test_judge_rubric.py` — `validate_and_repair(...)` call unpacked as `cand, rej`; `assert rej is None` added

## Self-Review Notes

- All four return sites transformed: error-verdict (ship-but-flag), is_complete, best-partial (hard-core gate), final drop.
- Rejection carries `best.verdict` score/failure_kinds when `best` exists; falls back to `cand.verdict` (set by the loop before break) otherwise.
- Thread-safety: `rej_lock` is a separate `threading.Lock()` from `cache_lock`; `rejections` is closed over by `_assemble_one` and appended only inside `with rej_lock`.
- `rejections` list is internal only in this task (not yet returned from `assemble_clips` — deferred to Task 4).
- Test count: 117 vs brief's estimated 118 — brief likely overcounted by 1; all meaningful tests pass.

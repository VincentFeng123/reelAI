### Task 3: Relevance-degraded surfacing + unmet-concept prerequisite hints

**Files:**
- Modify: `backend/pipeline/assemble/candidates.py` (`score_topic_relevance` retry + tuple return)
- Modify: `backend/pipeline/assemble/sequence.py` (`attach_prerequisites`, `sequence_clips`)
- Modify: `backend/pipeline/assemble/__init__.py` (unpack relevance tuple; notes suffix; pass `units_by_id` to `sequence_clips`)
- Test: append to `backend/pipeline/assemble/tests/test_integrity.py`

**Interfaces:**
- Consumes: existing assemble flow (`relevance` used by `select_anchors`/`build_candidate` —
  the dict itself is unchanged in shape).
- Produces: `score_topic_relevance(units, topic, settings, progress) -> tuple[dict[str, float], bool]`;
  `sequence_clips(specs, graph, units_by_id) -> list[dict]`;
  notes suffix exactly `" (topic filtering degraded — clips selected by role priority)"`.

- [ ] **Step 1: Write the failing tests** (append to `test_integrity.py`)

```python
# ── pkg-3: relevance degraded flag + unmet-concept prereq hints ───────────────
from backend.pipeline.assemble.candidates import score_topic_relevance
from backend.pipeline.assemble.sequence import sequence_clips


def test_relevance_retry_then_success_not_degraded(monkeypatch):
    from backend.pipeline.assemble.candidates import RelevanceLLM, RelItem
    calls = {"n": 0}

    def flaky(*a, **kw):
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("transient")
        return RelevanceLLM(items=[RelItem(unit_id="u0000", score=0.9)])
    monkeypatch.setattr(llm_mod, "llm_json", flaky)
    sents, units = _setup(1)
    rel, degraded = score_topic_relevance(units, "calculus", {})
    assert degraded is False
    assert rel["u0000"] == pytest.approx(0.9)
    assert calls["n"] == 2                                  # one retry happened


def test_relevance_double_failure_flags_degraded(monkeypatch):
    def boom(*a, **kw):
        raise RuntimeError("down")
    monkeypatch.setattr(llm_mod, "llm_json", boom)
    sents, units = _setup(2)
    rel, degraded = score_topic_relevance(units, "calculus", {})
    assert degraded is True
    assert all(v == 0.5 for v in rel.values())              # neutral defaults, honestly flagged


def test_relevance_empty_topic_no_llm(monkeypatch):
    def boom(*a, **kw):
        raise AssertionError("must not be called")
    monkeypatch.setattr(llm_mod, "llm_json", boom)
    sents, units = _setup(2)
    rel, degraded = score_topic_relevance(units, "", {})
    assert degraded is False and all(v == 1.0 for v in rel.values())


def test_prereq_hint_skipped_when_self_defined():
    sents, units = _setup(6)
    units[0].concepts_introduced = ["derivative"]
    units[3].concepts_required = ["derivative"]
    units[3].concepts_introduced = ["derivative"]           # clip defines it itself
    units[5].concepts_required = ["derivative"]             # clip does NOT define it
    units_by_id = {u.unit_id: u for u in units}
    specs = [
        {"start": 0.0, "unit_ids": ["u0000"]},
        {"start": 30.0, "unit_ids": ["u0003"]},
        {"start": 50.0, "unit_ids": ["u0005"]},
    ]
    seq = sequence_clips(specs, Graph([], units), units_by_id)
    by_start = {s["start"]: s for s in seq}
    assert by_start[30.0]["prerequisite_clips"] == []       # self-defined → no hint
    assert by_start[50.0]["prerequisite_clips"] == [1]      # needs clip 1's definition
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/test_integrity.py -q`
Expected: FAIL — relevance returns a plain dict (unpack error); `sequence_clips` takes 2 args;
self-defined clip still gets a hint.

- [ ] **Step 3: Implement**

a) `candidates.py::score_topic_relevance`:

```python
def score_topic_relevance(units: list[Unit], topic: str, settings: dict,
                          progress: ProgressCb = None) -> tuple[dict[str, float], bool]:
    """(unit_id → 0..1 relevance, degraded). degraded=True means the relevance LLM failed
    (after one retry per batch) and scores are neutral defaults — the topic filter is
    effectively OFF and callers must surface that instead of pretending scores exist."""
    if not topic or not topic.strip():
        return {u.unit_id: 1.0 for u in units}, False
    from ...llm import llm_json
    rel: dict[str, float] = {}
    degraded = False
    B = 120
    batches = [units[i:i + B] for i in range(0, len(units), B)] or [[]]
    for bi, batch in enumerate(batches):
        rows = "\n".join(
            f"{u.unit_id}: {u.summary[:120]}"
            + (f" | concepts: {', '.join((u.concepts_introduced + u.concepts_required)[:6])}"
               if (u.concepts_introduced or u.concepts_required) else "")
            for u in batch
        )
        user = f"TOPIC: {topic}\n\nUNITS:\n{rows}\n\nScore each unit id 0.0–1.0 for relevance to the topic."
        got: dict[str, float] = {}
        for attempt in range(2):                            # one retry on transient failure
            try:
                res = llm_json(_REL_SYSTEM, user, RelevanceLLM, temperature=0.0)
                got = {it.unit_id: max(0.0, min(1.0, float(it.score))) for it in res.items}
                break
            except Exception:
                if attempt == 1:
                    degraded = True                          # batch stays neutral — flag it
        for u in batch:
            rel[u.unit_id] = got.get(u.unit_id, 0.5)   # neutral if the model omitted it
        if progress:
            progress((bi + 1) / len(batches), "Scoring topic relevance")
    return rel, degraded
```

b) `assemble/__init__.py` step 1 + notes:

```python
    relevance, relevance_degraded = score_topic_relevance(
        units, topic, settings, lambda f, m="": emit(0.05 + 0.10 * f, m))
```

```python
    notes = f"{len(specs)} clip(s) about “{topic}”." if topic else f"{len(specs)} clip(s)."
    if relevance_degraded and topic:
        notes += " (topic filtering degraded — clips selected by role priority)"
    return specs, notes, rejections
```

c) `sequence.py`:

```python
def attach_prerequisites(specs: list[dict], graph, units_by_id: dict) -> None:
    """Hint an earlier clip only for concepts this clip REQUIRES but does not itself
    introduce — a clip that contains its own definition needs no 'watch first' pointer."""
    def _units(s):
        return [units_by_id[u] for u in s.get("unit_ids", []) if u in units_by_id]

    for s in specs:
        mine = _units(s)
        intro = set().union(*[set(u.concepts_introduced) for u in mine]) if mine else set()
        req = set().union(*[set(u.concepts_required) for u in mine]) if mine else set()
        unmet = {c for c in (req - intro) if c}
        prereqs: list[int] = []
        if unmet:
            for other in specs:
                if other is s or other["start"] >= s["start"]:
                    continue                                  # only EARLIER clips
                other_intro = set().union(*[set(u.concepts_introduced) for u in _units(other)]) \
                    if _units(other) else set()
                if other_intro & unmet:
                    prereqs.append(other["sequence_index"])
        s["prerequisite_clips"] = sorted(set(prereqs))


def sequence_clips(specs: list[dict], graph, units_by_id: dict) -> list[dict]:
    specs.sort(key=lambda s: s["start"])
    for i, s in enumerate(specs):
        s["sequence_index"] = i + 1
    attach_prerequisites(specs, graph, units_by_id)
    return specs
```

d) `assemble/__init__.py` step 7: `specs = sequence_clips(specs, graph, units_by_id)`.

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/python -m pytest backend/pipeline/assemble/tests/ -q`
Expected: all pass (4 new).

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: 149 passed, compile clean.

---


### Task 1: Config block + schema bump + `ContentMap.engine`

**Files:**
- Modify: `backend/config.py` (after the `BRIDGE_MAX_PER_UNIT` line, ~line 191; plus `DEFAULTS` dict ~line 135)
- Modify: `backend/pipeline/understand/models.py` (`SCHEMA_VERSION` ~line 18; `ContentMap` ~line 104)
- Create: `backend/pipeline/understand/tests/__init__.py` (empty)
- Test: `backend/pipeline/understand/tests/test_models_v4.py`

**Interfaces:**
- Produces: `config.CONTENT_MAP_ENGINE: str`, `config.TREESEG_TARGET_TOPIC_SEC: float`, `config.TREESEG_MIN_TOPICS: int`, `config.TREESEG_MAX_TOPICS: int`, `config.TREESEG_MIN_TOPIC_SENTS: int`, `config.TREESEG_COHERENCE_FLOOR: float`, `config.TREESEG_PAUSE_PRIOR: float`, `config.TREESEG_LABEL_BATCH: int`; `DEFAULTS["content_map_engine"] = None`; `ContentMap.engine: str = ""`; `SCHEMA_VERSION == 4`.

- [ ] **Step 1: Write the failing test**

```python
# backend/pipeline/understand/tests/test_models_v4.py
"""Schema-v4 groundwork: engine field, version bump, cache gating, config block."""
from __future__ import annotations

import json

from backend import config
from backend.pipeline.understand.models import (
    SCHEMA_VERSION, ContentMap, Structure, load_structure, save_structure,
)


def test_schema_version_is_4():
    assert SCHEMA_VERSION == 4


def test_content_map_engine_field_defaults_empty():
    assert ContentMap().engine == ""


def test_engine_field_roundtrips_through_structure_cache(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "WORK_DIR", tmp_path)
    st = Structure(video_id="vidA", content_map=ContentMap(engine="treeseg"))
    save_structure(st)
    loaded = load_structure("vidA")
    assert loaded is not None
    assert loaded.content_map.engine == "treeseg"


def test_v3_cache_is_invalidated(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "WORK_DIR", tmp_path)
    st = Structure(video_id="vidB")
    save_structure(st)
    p = tmp_path / "vidB" / "structure.json"
    data = json.loads(p.read_text())
    data["schema_version"] = 3
    p.write_text(json.dumps(data))
    assert load_structure("vidB") is None


def test_treeseg_config_block():
    assert config.CONTENT_MAP_ENGINE in ("treeseg", "llm")
    assert config.TREESEG_TARGET_TOPIC_SEC == 120.0
    assert config.TREESEG_MIN_TOPICS == 2
    assert config.TREESEG_MAX_TOPICS == 24
    assert config.TREESEG_MIN_TOPIC_SENTS == 3
    assert config.TREESEG_COHERENCE_FLOOR == 0.0
    assert config.TREESEG_PAUSE_PRIOR == 0.15
    assert config.TREESEG_LABEL_BATCH == 12
    assert "content_map_engine" in config.DEFAULTS and config.DEFAULTS["content_map_engine"] is None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `.venv/bin/python -m pytest backend/pipeline/understand/tests/test_models_v4.py -q`
Expected: FAIL — `SCHEMA_VERSION == 3`, `ContentMap` has no `engine`, config attrs missing.

- [ ] **Step 3: Implement**

In `backend/pipeline/understand/models.py` replace the `SCHEMA_VERSION` block:

```python
SCHEMA_VERSION = 4   # 4: content-map boundaries are embedding-derived (TreeSeg); cached topic
                     #    partitions / sentence_ranges from the LLM engine are stale; rebuild.
                     # 3: punctuation-restoration stage changes sentence segmentation
                     # 2: Phase-2 perception (visual_events populated, visual_dependencies linked)
```

In `ContentMap` add the field (after `nodes`):

```python
class ContentMap(BaseModel):
    root_id: str = "video"
    nodes: list[ContentNode] = Field(default_factory=list)
    engine: str = ""                           # "treeseg" | "llm" | "llm-fallback" (see content_map)
```

In `backend/config.py`, after the `BRIDGE_MAX_PER_UNIT = 6` line add:

```python
# Content-map engine: "treeseg" = deterministic embedding-based divisive segmentation
# (arXiv:2407.12028) with a cheap LLM labeling pass; "llm" = the legacy per-chunk LLM
# boundary pass (also the graceful-degrade fallback when treeseg fails).
CONTENT_MAP_ENGINE = os.environ.get("CONTENT_MAP_ENGINE", "treeseg")   # "treeseg" | "llm"
TREESEG_TARGET_TOPIC_SEC = float(os.environ.get("TREESEG_TARGET_TOPIC_SEC", "120"))
TREESEG_MIN_TOPICS = 2
TREESEG_MAX_TOPICS = 24
TREESEG_MIN_TOPIC_SENTS = 3
TREESEG_COHERENCE_FLOOR = float(os.environ.get("TREESEG_COHERENCE_FLOOR", "0.0"))  # 0 = target-K driven
TREESEG_PAUSE_PRIOR = float(os.environ.get("TREESEG_PAUSE_PRIOR", "0.15"))
TREESEG_LABEL_BATCH = 12
```

In `config.DEFAULTS` add (next to `"multimodal": None`):

```python
    "content_map_engine": None,             # None → inherit config.CONTENT_MAP_ENGINE
```

Create empty `backend/pipeline/understand/tests/__init__.py`.

- [ ] **Step 4: Run test to verify it passes**

Run: `.venv/bin/python -m pytest backend/pipeline/understand/tests/test_models_v4.py -q`
Expected: 5 passed.

- [ ] **Step 5: Checkpoint**

Run: `.venv/bin/python -m pytest backend -q && .venv/bin/python -m compileall -q backend`
Expected: all pass (63 existing + 5 new), compile clean.

---


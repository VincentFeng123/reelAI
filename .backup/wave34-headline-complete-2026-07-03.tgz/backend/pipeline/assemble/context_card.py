"""Source-grounded context cards (spec §7B).

A ≤2-sentence intro generated ONLY from the anchor + the far "referential" prerequisite
units that closure chose not to inline. Every card sentence must cite a unit and pass a
fuzzy-entailment check against that unit's own words; anything unverifiable is dropped,
and an empty card is omitted rather than hallucinated.
"""
from __future__ import annotations

from pydantic import BaseModel, Field

from ... import config
from ..select import _normalize
from ..understand.models import Unit


class CardSentence(BaseModel):
    text: str = ""
    source_unit_id: str = ""


class ContextCardDraft(BaseModel):
    sentences: list[CardSentence] = Field(default_factory=list)


_CARD_SYSTEM = (
    "You write a one- or two-sentence 'earlier in the video' preface that makes a clip easier to "
    "follow. Use ONLY the provided unit summaries; never state anything not in them. Cite each "
    "sentence's source_unit_id. Keep it under {max_words} words total. If the units add nothing "
    "useful, return no sentences. Output only the structured result."
)


def _grounded(text: str, unit: Unit) -> bool:
    from rapidfuzz import fuzz
    hay = _normalize(" ".join([unit.summary] + unit.concepts_introduced + unit.claims))
    needle = _normalize(text)
    if not needle:
        return False
    return fuzz.partial_ratio(needle, hay) >= 55.0


def generate_context_card(spec: dict, units_by_id: dict[str, Unit], adapter, topic: str) -> str:
    in_clip = set(spec.get("unit_ids", []))
    ref_pairs = [(uid, rel) for uid, rel in spec.get("referential", [])
                 if uid in units_by_id and uid not in in_clip]
    ref_units = [units_by_id[uid] for uid, _rel in ref_pairs]
    if not ref_units:
        return ""
    anchor = units_by_id.get(spec.get("anchor_id", ""))
    allowed = {u.unit_id: u for u in (([anchor] if anchor else []) + ref_units)}
    rows = "\n".join(f"{u.unit_id}: {u.summary}" for u in allowed.values())
    from ...llm import llm_json
    system = _CARD_SYSTEM.format(max_words=config.CONTEXT_CARD_MAX_WORDS)
    user = f"TOPIC: {topic or '(general)'}\n\nUNITS (earlier context for the clip):\n{rows}\n\nWrite the preface."
    card = ""
    try:
        draft = llm_json(system, user, ContextCardDraft, temperature=0.2)
        kept = [cs.text.strip() for cs in draft.sentences
                if cs.source_unit_id in allowed and _grounded(cs.text, allowed[cs.source_unit_id])]
        card = " ".join(t for t in kept if t)
    except Exception:
        card = ""
    if not card:
        # extractive fallback: verbatim referential-unit summary — grounded by construction
        for u in ref_units:
            if (u.summary or "").strip():
                card = u.summary.strip()
                break
    words = card.split()
    if len(words) > config.CONTEXT_CARD_MAX_WORDS:     # hard word budget (prompt asks for it too)
        card = " ".join(words[:config.CONTEXT_CARD_MAX_WORDS])
    return card

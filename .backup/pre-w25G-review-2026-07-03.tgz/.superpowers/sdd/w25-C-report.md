# W25-C report — granularity-invariant closure + real coverage floor + per-topic role cap

Spec: `docs/superpowers/plans/2026-07-02-wave-2.5-coverage.md` §W25-C.
Tests: **484 → 497** (13 new), 100% green. `compileall backend` clean. All offline (no LLM).

## What changed and why

### 1. Closure element picks are contiguous runs (`backend/pipeline/assemble/closure.py`)
- New `_element_run(units, start_i, want, step, max_units)`: from the seed match, walk
  +1 ('after') / -1 ('before') taking units that match the element roles AND share the
  seed's topic node; a differing role or `node_id` breaks the run.
- `_contract_needs` now takes the `ClosureBudget` and replaces the single-unit picks
  (`[cand[0]]` after / `[cand[-1]]` before) with the run, capped at
  `budget.max_extra_units` at pick time. Span/gap/unit budgets are still enforced by the
  existing machinery (required inline is span-bounded; recommended goes through the
  frontier). 'within' picks unchanged.
- Why: the qP rebuild (139→239 units) split the vectors/scalars definition block into
  3.3s micro-units; picking `cand[0]` alone shrank the definition-anchored c0.t1 closure
  to a 24.2s sliver (gold item 3 at 0.548, item 4 at 0.000; pre-rebuild the same anchor
  spanned both at 1.0). Runs make closure extent invariant to unit granularity.

### 2. Real coverage floor in `enforce_plan` (`backend/pipeline/assemble/candidates.py`, `backend/config.py`)
- New `config.MIN_NODE_COVERAGE = 0.5` (env-overridable).
- New `_node_covered(node, members)`: a topic node counts covered only when the selected
  entries' units (arc members for arc entries, else the anchor unit) span ≥
  MIN_NODE_COVERAGE of the node's timed span — interval UNION clipped to the node, so
  overlaps never double-count. Untimed nodes (end <= start) keep the legacy any-anchor
  rule (fraction uncomputable ≠ zero).
- The floor loop now tops up under-covered (sliver) topics exactly like plan-skipped
  ones: one best prior-scored eligible anchor per pass. Coverage-beats-saturation
  precedence unchanged (only the hard cap can drop a floor addition). The now-unused
  `_topics_of` helper was removed (replaced by `_entry_units` + `_node_covered`).

### 3. Per-topic role cap (`candidates.py`, `config.py`)
- New `config.PLAN_ROLE_CAP_PER_TOPIC = 2` **replaces** the video-global
  `PLAN_ROLE_CAP = 4` (constant deleted; no non-comment references remain).
- `enforce_plan` saturation counter is keyed `(role, home_topic)`; the topic quota
  `ceil(cap/n_topics)+1` is unchanged; arcs stay saturation-exempt.
- Legacy `select_anchors` counter is keyed `(role, node_id)` — same protection on the
  priority/fallback arm. Unmapped units (`node_id == ""`) share one pseudo-topic bucket.
- Why: 46 eligible qP claims competed for 4 video-wide slots, starving the projectile
  zone (gold items 21-22, 10 eligible in-zone claims).

### 4. Eval sibling metric (`backend/eval/metrics.py`, `backend/eval/run_eval.py`)
- New `metrics.topic_span_coverage(specs, topic_nodes)`: shipped seconds / node seconds
  (per-node interval union of shipped spec spans, clipped; NaN when no node carries
  timing). Wired into `_wave2_columns` next to `chapter_coverage` and into
  `_PREFERRED_KEYS`. Per spec §W25-C: "chapter_coverage gains a sibling
  topic_span_coverage metric ... so slivers are visible in eval". (W25-G's remaining
  column work is untouched.)

## Tests

New (13):
- `backend/pipeline/assemble/tests/test_closure_runs.py` (NEW file, 5): qP-c0.t1-modeled
  fixture — 'after' run spans the full definition+unpacking block (102-160s vs the old
  23s sliver) with the claim breaking the run; run bounded by `max_extra_units`
  (overflow referential); run breaks at a topic-node boundary; symmetric 'before' run
  inlines a split problem statement; span budget keeps far run members referential +
  truncated.
- `test_plan.py` (4): per-topic cap keeps both claim-dense zones selectable; floor tops
  up a sliver-covered topic; union arithmetic (two 9.9s anchors = 0.66 ≥ 0.5 → no
  top-up); untimed node keeps the any-anchor rule.
- `test_selection_budget.py` (1): unmapped units share one pseudo-topic bucket.
- `eval/tests/test_wave2_columns.py` (3): sliver reads low where chapter_coverage reads
  1.0; overlap union + node clipping; NaN/zero conventions.

Updated (spec governs — see deviations): 3 enforcement tests in `test_plan.py`, 2
selector tests in `test_selection_budget.py`, the P4 ledger assertion in
`test_wave2_smoke.py`, the row-shape key list in `test_wave2_columns.py`.

## Deviations (existing tests changed because the spec governs)

1. `test_enforcement_role_saturation_drops_lowest_ranked_overflow`: 6 no-topic claims
   now cap at 2 (one `""` pseudo-topic), was 4; asserts `PLAN_ROLE_CAP_PER_TOPIC == 2`.
2. `test_enforcement_arcs_exempt_from_saturation_and_added_when_plan_skips_them`: 2
   results (not 4) now exhaust the per-topic quota before the exempt arc is appended.
3. `test_enforcement_adds_best_anchor_for_plan_skipped_topic`: the planned anchor spans
   9.9/19.9 = 0.497 < MIN_NODE_COVERAGE, so the new floor also tops up its own topic
   (expected ids gained `u0001`).
4. `test_role_cap_in_legacy_selector` → renamed `..._is_per_topic` and rebuilt around
   two claim-dense nodes; companion test pins the unmapped pseudo-topic bucket.
5. `test_unmapped_units_never_dominate_higher_scored_mapped_units`: third same-node
   result would now be capped, so the fixture moves it to a second node — the
   score-primacy intent is preserved under the new cap.
6. `test_smoke_plan_arc_rebind_trim_dedupe_compose`: ledger gains one row — the floor
   tops up sliver-covered c0.t1 (u0006 spans 33%) with u0007, whose candidate cleanly
   loses dedupe to the shipped definition clip; shipped specs unchanged.
7. Scope note: `topic_span_coverage` was not in the orchestrator's condensed
   deliverables list but is in spec §W25-C; implemented (metric + column) as specified.

## Files changed (snapshots in `.superpowers/sdd/snap-w25-C/`)

- `backend/config.py`
- `backend/pipeline/assemble/closure.py`
- `backend/pipeline/assemble/candidates.py`
- `backend/eval/metrics.py`
- `backend/eval/run_eval.py`
- `backend/pipeline/assemble/tests/test_plan.py`
- `backend/pipeline/assemble/tests/test_selection_budget.py`
- `backend/pipeline/assemble/tests/test_wave2_smoke.py`
- `backend/eval/tests/test_wave2_columns.py`
- `backend/pipeline/assemble/tests/test_closure_runs.py` (NEW)

Not done here (per instructions): no live evals; no docs/MEMORY edits. The live
acceptance checks (qP c0.t1 covering gold items 3+4 at ≥0.60; items 21-22 selectable;
kinematics non-regression) belong to the wave gate protocol.

"""Chronological sequencing + prerequisite hints (spec §7C).

Clips are presented in temporal order (earlier-in-video first). The dependency graph is
used only to attach optional "watch first" hints — never to reorder.
"""
from __future__ import annotations


def attach_prerequisites(specs: list[dict], graph, units_by_id: dict) -> None:
    """Hint an earlier clip only for concepts this clip REQUIRES but does not itself
    introduce — a clip that contains its own definition needs no 'watch first' pointer."""
    def _units(s):
        return [units_by_id[u] for u in s.get("unit_ids", []) if u in units_by_id]

    for s in specs:
        mine = _units(s)
        intro = set().union(*[set(u.concepts_introduced) for u in mine]) if mine else set()
        req = set().union(*[set(u.concepts_required) for u in mine]) if mine else set()
        unmet = {c for c in (req - intro) if c}
        prereqs: list[int] = []
        if unmet:
            # precompute each earlier clip's introduced-set ONCE (not per concept)
            earlier = []
            for other in specs:
                if other is s or other["start"] >= s["start"]:
                    continue                                  # only EARLIER clips
                ou_units = _units(other)
                ou_intro = set().union(*[set(u.concepts_introduced) for u in ou_units]) \
                    if ou_units else set()
                earlier.append((other, ou_intro))
            for concept in unmet:
                for other, ou_intro in earlier:               # specs are in temporal order
                    if concept in ou_intro:
                        prereqs.append(other["sequence_index"])
                        # only the earliest for this concept — deliberate departure from
                        # hint-all-earlier-clips: fewer redundant "watch first" pointers;
                        # the earliest introducer suffices
                        break
        s["prerequisite_clips"] = sorted(set(prereqs))


def sequence_clips(specs: list[dict], graph, units_by_id: dict) -> list[dict]:
    specs.sort(key=lambda s: s["start"])
    for i, s in enumerate(specs):
        s["sequence_index"] = i + 1
    attach_prerequisites(specs, graph, units_by_id)
    return specs

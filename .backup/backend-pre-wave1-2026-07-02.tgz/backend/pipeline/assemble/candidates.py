"""Anchor selection + candidate construction (spec §6).

Anchors are units whose role is clip-worthy (per the adapter) AND relevant to the search
topic. Topic relevance is scored by a single LLM pass over unit summaries (no embedding
model needed). Each anchor's context closure is turned into a sentence-anchored candidate
using the units' own sentence ranges (exact — units were built from sentence spans).
"""
from __future__ import annotations

from typing import Callable, Optional

from pydantic import BaseModel, Field

from ... import config
from ..sentences import Sentence
from ..understand.models import Unit
from .closure import ClosureBudget, compute_closure
from .integrity import true_contents
from .types import Candidate

ProgressCb = Optional[Callable[[float, str], None]]


class RelItem(BaseModel):
    unit_id: str
    score: float = 0.0


class RelevanceLLM(BaseModel):
    items: list[RelItem] = Field(default_factory=list)


_REL_SYSTEM = (
    "You score how relevant each unit of a video is to a viewer's TOPIC. For each unit id, "
    "return a score from 0.0 (unrelated) to 1.0 (squarely about the topic). Judge by the unit's "
    "summary and concepts. Output only the structured result."
)


def score_topic_relevance(units: list[Unit], topic: str, settings: dict,
                          progress: ProgressCb = None) -> tuple[dict[str, float], bool]:
    """(unit_id → 0..1 relevance, degraded). degraded=True means the relevance LLM failed
    (after one retry per batch) and scores are neutral defaults — the topic filter is
    effectively OFF and callers must surface that instead of pretending scores exist."""
    if not topic or not topic.strip():
        return {u.unit_id: 1.0 for u in units}, False
    from ...llm import llm_json
    rel: dict[str, float] = {}
    degraded = False
    B = 120
    batches = [units[i:i + B] for i in range(0, len(units), B)] or [[]]
    for bi, batch in enumerate(batches):
        rows = "\n".join(
            f"{u.unit_id}: {u.summary[:120]}"
            + (f" | concepts: {', '.join((u.concepts_introduced + u.concepts_required)[:6])}"
               if (u.concepts_introduced or u.concepts_required) else "")
            for u in batch
        )
        user = f"TOPIC: {topic}\n\nUNITS:\n{rows}\n\nScore each unit id 0.0–1.0 for relevance to the topic."
        got: dict[str, float] = {}
        for attempt in range(2):                            # one retry on transient failure
            try:
                res = llm_json(_REL_SYSTEM, user, RelevanceLLM, temperature=0.0)
                got = {it.unit_id: max(0.0, min(1.0, float(it.score))) for it in res.items}
                break
            except Exception:
                if attempt == 1:
                    degraded = True                          # batch stays neutral — flag it
        for u in batch:
            rel[u.unit_id] = got.get(u.unit_id, 0.5)   # neutral if the model omitted it
        if progress:
            progress((bi + 1) / len(batches), "Scoring topic relevance")
    return rel, degraded


def select_anchors(units: list[Unit], relevance: dict[str, float], adapter, settings: dict) -> list[Unit]:
    floor = float(settings.get("anchor_rel_floor", config.ANCHOR_REL_FLOOR))
    cap = int(settings.get("max_anchors", config.MAX_ANCHORS))
    scored = []
    for u in units:
        if not adapter.is_anchor_role(u.role):
            continue
        if adapter.anchor_priority(u.role) * 100.0 < config.ANCHOR_MIN_PRIORITY:
            continue                                   # honor the priority floor in the select path too
        rel = relevance.get(u.unit_id, 0.0)
        if rel < floor:
            continue
        scored.append((adapter.anchor_priority(u.role) * (0.4 + 0.6 * rel) * (0.5 + 0.5 * u.source_confidence), u))
    scored.sort(key=lambda t: t[0], reverse=True)
    return [u for _, u in scored[:cap]]


def build_candidate(anchor: Unit, graph, adapter, units: list[Unit], units_by_id: dict[str, Unit],
                    sentences: list[Sentence], relevance: dict[str, float], settings: dict) -> Optional[Candidate]:
    budget = ClosureBudget(max_span_s=float(settings.get("closure_max_span_s", config.CLOSURE_MAX_SPAN_S)))
    cl = compute_closure(anchor, graph, units_by_id, adapter, units, budget)
    inline = [units_by_id[uid] for uid in cl.unit_ids if uid in units_by_id]
    if not inline:
        return None
    i_start = min(u.sentence_range[0] for u in inline)
    i_end = max(u.sentence_range[1] for u in inline)
    i_start = max(0, min(i_start, len(sentences) - 1))
    i_end = max(i_start, min(i_end, len(sentences) - 1))
    unit_ids, referential = true_contents(list(cl.unit_ids), list(cl.referential),
                                          units, i_start, i_end)
    return Candidate(
        cand_id=f"c_{anchor.unit_id}",
        anchor_id=anchor.unit_id,
        role=anchor.role,
        facet=adapter.facet_for(anchor.role),
        title=anchor.topic or (anchor.summary[:60]),
        reason=anchor.summary,
        unit_ids=unit_ids,
        referential=referential,
        i_start=i_start, i_end=i_end,
        start=float(sentences[i_start].start), end=float(sentences[i_end].end),
        relevance=relevance.get(anchor.unit_id, 0.0),
        priority=adapter.anchor_priority(anchor.role),
        truncated=cl.truncated,
    )

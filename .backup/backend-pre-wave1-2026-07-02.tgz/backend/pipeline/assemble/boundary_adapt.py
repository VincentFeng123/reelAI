"""Physical boundary refinement (spec §9) — REUSE the existing snapping code.

Validated candidates carry Part-B metadata (role, context_card, scores, unit_ids) that
``refine_and_snap`` would strip when it rebuilds dicts. So we call its internals directly
— ``boundary._snap_one`` (start→sentence-start, end→period, min/max duration, tail pad)
and ``_dedupe_partb`` (overlap removal with metadata-aware merge) — and merge the snapped
result over the metadata, preserving every field. The optional targeted-Whisper precise pass
(``boundary.refine_clip_boundaries``) is applied by the orchestrator afterwards.
"""
from __future__ import annotations

from ... import config
from ..sentences import Sentence
from .integrity import Rejection, merge_partb, true_contents
from .types import Candidate


def candidate_to_boundary_input(cand: Candidate) -> dict:
    return {
        "i_start": cand.i_start, "i_end": cand.i_end,
        "start": cand.start, "end": cand.end,
        "facet": cand.facet, "reason": cand.reason,
        "score": cand.final_quality, "rel": cand.final_quality,
        # Part-B metadata carried through the snap/dedupe (which preserve dict keys):
        "role": cand.role, "title": cand.title, "cand_id": cand.cand_id, "anchor_id": cand.anchor_id,
        "unit_ids": list(cand.unit_ids), "referential": list(cand.referential),
        "context_card": cand.context_card,
        "completeness_score": cand.completeness_score, "grounding_score": cand.grounding_score,
        "priority": cand.priority,
        "judge_error": bool(getattr(cand.verdict, "error", False)),
        "truncated": bool(getattr(cand, "truncated", False)),
    }


def snap_candidates(cands: list[Candidate], sentences: list[Sentence], settings: dict,
                    units=None) -> tuple[list[dict], list[Rejection]]:
    from ..refine import _snap_one
    allow_qe = bool(settings.get("allow_question_exclaim_ends", config.DEFAULTS["allow_question_exclaim_ends"]))
    min_dur = float(settings.get("min_clip_duration_s", config.DEFAULTS["min_clip_duration_s"]))
    max_dur = float(settings.get("max_clip_duration_s", config.DEFAULTS["max_clip_duration_s"]))
    tail_pad = float(settings.get("tail_pad_s", config.DEFAULTS["tail_pad_s"]))

    rejections: list[Rejection] = []
    specs: list[dict] = []
    for c in cands:
        b = candidate_to_boundary_input(c)
        snapped = _snap_one(b, sentences, allow_qe, min_dur, tail_pad, max_dur)
        if snapped is None:
            rejections.append(Rejection(cand_id=c.cand_id, title=c.title, role=c.role,
                                        stage="snap", reason="unsnappable (end<=start)",
                                        final_quality=c.final_quality, start=c.start, end=c.end))
            continue
        specs.append({**b, **snapped})
    if units is not None:
        # snap may extend the span (min-duration) — keep unit_ids/referential truthful
        for s in specs:
            s["unit_ids"], s["referential"] = true_contents(
                s.get("unit_ids", []), s.get("referential", []), units,
                s["sentence_start_idx"], s["sentence_end_idx"])
    for s in specs:
        if s.get("judge_error"):   # unjudged (judge outage): user-visible + boundary_score penalty
            s["warnings"] = tuple(set(s.get("warnings") or ()) | {"unjudged"})
    specs, dedupe_rejections = _dedupe_partb(specs, sentences, min_dur, units)
    rejections.extend(dedupe_rejections)
    specs.sort(key=lambda s: s["start"])
    return specs, rejections


def _dedupe_partb(clips: list[dict], sentences: list[Sentence], min_dur: float,
                  units) -> tuple[list[dict], list[Rejection]]:
    """refine._dedupe's keep/drop decisions, but metadata-aware: same-facet overlaps merge via
    integrity.merge_partb (union + merged flag, re-judged upstream) and every dropped spec
    becomes a Rejection. refine.py itself is untouched (legacy fast path)."""
    from ..refine import NEAR_DUP_EPS, _better, _trim_start_after

    def _reject(loser: dict, winner: dict) -> None:
        rejections.append(Rejection(
            cand_id=loser.get("cand_id", ""), title=loser.get("title", ""),
            role=loser.get("role", ""), stage="dedupe",
            reason=f"overlap loser to {winner.get('cand_id', '?')}",
            final_quality=loser.get("final_quality", loser.get("score")), start=loser["start"], end=loser["end"]))

    rejections: list[Rejection] = []
    clips = sorted(clips, key=lambda c: (c["start"], -c["end"]))
    kept: list[dict] = []
    for c in clips:
        if not kept:
            kept.append(c)
            continue
        k = kept[-1]
        if c["start"] >= k["end"]:                      # disjoint
            kept.append(c)
            continue
        overlapping_pairs = (
            (c["start"] >= k["start"] and c["end"] <= k["end"]) or
            (c["start"] <= k["start"] and c["end"] >= k["end"]) or
            (abs(c["start"] - k["start"]) <= NEAR_DUP_EPS and abs(c["end"] - k["end"]) <= NEAR_DUP_EPS)
        )
        if overlapping_pairs:                            # containment / near-dup → keep better
            winner = _better(k, c)
            _reject(c if winner is k else k, winner)
            kept[-1] = winner
            continue
        if c["facet"] == k["facet"]:                    # same facet → metadata-aware union
            kept[-1] = merge_partb(k, c, units, sentences)
            continue
        trimmed = _trim_start_after(c, k["end"], sentences, min_dur)
        if trimmed is not None:
            kept.append(trimmed)
        else:
            winner = _better(k, c)
            _reject(c if winner is k else k, winner)
            kept[-1] = winner
    return kept, rejections

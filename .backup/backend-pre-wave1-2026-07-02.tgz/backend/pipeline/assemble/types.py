"""Shared types for clip assembly."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Candidate:
    cand_id: str
    anchor_id: str
    role: str
    facet: str
    title: str
    reason: str
    unit_ids: list[str]                        # inlined units (anchor + inline context), time-ordered
    referential: list[tuple[str, str]]         # (unit_id, relation) surfaced via card, not inlined
    i_start: int                               # sentence indices (for boundary reuse)
    i_end: int
    start: float
    end: float
    relevance: float = 0.0                     # topic relevance of the anchor (0..1)
    priority: float = 0.0                      # anchor role priority (0..1)
    truncated: bool = False                    # closure hit its budget with needs unmet
    # filled during validation / scoring:
    verdict: Optional[object] = None
    attempts: int = 0
    completeness_score: float = 0.0
    grounding_score: float = 0.0
    boundary_score: float = 1.0
    final_quality: float = 0.0
    context_card: str = ""
    prerequisite_anchor_ids: list[str] = field(default_factory=list)


@dataclass
class Need:
    unit_id: str
    relation: str
    weight: float
    gap: float

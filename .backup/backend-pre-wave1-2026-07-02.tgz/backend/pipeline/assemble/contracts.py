"""Deterministic completeness precheck (spec §7).

A cheap, no-LLM check of whether a candidate's inline units cover the required elements
of its role's contract. Runs before the judge to cut judge calls and to hint expansion.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..understand.models import Unit


@dataclass
class ContractReport:
    role: str
    present: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)   # required elements not covered
    ok: bool = True


def check_contract(unit_ids: list[str], role: str, units_by_id: dict[str, Unit], adapter) -> ContractReport:
    contract = adapter.contract_for(role)
    if not contract:
        return ContractReport(role, [], [], True)
    roles_present = {units_by_id[uid].role for uid in unit_ids if uid in units_by_id}
    present, missing = [], []
    for el in contract.elements:
        if any(r in roles_present for r in el.roles):
            present.append(el.key)
        elif el.necessity == "required":
            missing.append(el.key)
    return ContractReport(role, present, missing, ok=(not missing))

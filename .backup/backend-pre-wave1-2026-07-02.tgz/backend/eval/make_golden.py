"""Dump a golden *skeleton* from the predicted structure, for a human to correct (spec §4.2).

Running the full understanding pass and emitting the predicted units in the golden schema makes
hand-labeling fast: a human fixes roles / concept lists / anchor spans instead of typing them from
scratch. Output goes to ``eval/golden/<video_id>.skeleton.json`` and NEVER overwrites a
hand-authored ``<video_id>.json`` — rename the skeleton to that once corrected.

Usage:
    python -m backend.eval.make_golden <video_id> [--topic "the derivative"]
"""
from __future__ import annotations

import json
import sys

from .. import config
from ..adapters import select_adapter
from ..pipeline.sentences import build_sentence_index, sentences_from_chunks
from ..pipeline.understand import build_structure
from .golden import GOLDEN_DIR


def _sentences(transcript):
    s = build_sentence_index(transcript)
    if transcript.get("source") == "supadata":
        frac = (sum(1 for x in s if x.ends_with_period) / len(s)) if s else 0.0
        avg = (sum(x.end - x.start for x in s) / len(s)) if s else 999.0
        if len(s) < 5 or frac < 0.3 or avg > 40.0:
            s = sentences_from_chunks(transcript.get("chunks", []))
    return s


def make_skeleton(video_id: str, topic: str | None = None) -> dict:
    tpath = config.WORK_DIR / video_id / "transcript.json"
    if not tpath.exists():
        raise SystemExit(f"no cached transcript for {video_id} at {tpath}")
    transcript = json.loads(tpath.read_text(encoding="utf-8"))
    transcript.setdefault("title", "")
    sents = _sentences(transcript)
    settings = dict(config.DEFAULTS)
    adapter, det = select_adapter(transcript, settings)
    st = build_structure(video_id, transcript, sents, adapter, det, settings, None)

    ref_concepts = sorted({c for u in st.units for c in u.concepts_introduced})[:40]
    return {
        "video_id": video_id,
        "url": f"https://youtu.be/{video_id}",
        "domain": det.domain,
        "content_type": det.content_type,
        "topics": [topic] if topic else [],
        "reference_concepts": ref_concepts,
        "units": [{
            "start": round(u.start, 2), "end": round(u.end, 2), "role": u.role,
            "concepts_introduced": u.concepts_introduced, "concepts_required": u.concepts_required,
            "is_anchor": adapter.is_anchor_role(u.role),
        } for u in st.units],
        "anchors": [{
            "anchor_role": u.role, "start": round(u.start, 2), "end": round(u.end, 2),
            "required_elements_present": adapter.required_elements(u.role),
            "prerequisites": u.concepts_required, "must_understand_without_source": True,
        } for u in st.units if adapter.is_anchor_role(u.role)],
        "_note": "SKELETON of PREDICTED structure — correct roles/concepts/anchors by hand, then "
                 "rename to <video_id>.json to use as ground truth.",
    }


def main(argv: list[str]) -> None:
    args = [a for a in argv if not a.startswith("--")]
    if not args:
        raise SystemExit('usage: python -m backend.eval.make_golden <video_id> [--topic "..."]')
    topic = None
    if "--topic" in argv:
        i = argv.index("--topic")
        topic = argv[i + 1] if i + 1 < len(argv) else None
    video_id = args[0]
    skeleton = make_skeleton(video_id, topic)
    GOLDEN_DIR.mkdir(parents=True, exist_ok=True)
    out = GOLDEN_DIR / f"{video_id}.skeleton.json"
    out.write_text(json.dumps(skeleton, indent=2), encoding="utf-8")
    print(f"wrote {out}  ({len(skeleton['units'])} units, {len(skeleton['anchors'])} anchors, "
          f"domain={skeleton['domain']})")


if __name__ == "__main__":
    main(sys.argv[1:])

"""Golden-set loading + time alignment (spec §14).

A golden file (``eval/golden/<video_id>.json``) carries human labels:
    {
      "video_id", "url", "domain", "content_type",
      "topics": ["projectile motion"],
      "reference_concepts": ["kinematics", ...],
      "units":   [{"start","end","role","concepts_introduced","concepts_required","is_anchor"}],
      "anchors": [{"anchor_role","start","end","required_elements_present","prerequisites",
                   "must_understand_without_source"}]
    }
All fields are optional except video_id — label-free metrics work with none of them.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

GOLDEN_DIR = Path(__file__).resolve().parent / "golden"


def load_golden(video_id: str) -> Optional[dict]:
    p = GOLDEN_DIR / f"{video_id}.json"
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def iou(a_start: float, a_end: float, b_start: float, b_end: float) -> float:
    inter = max(0.0, min(a_end, b_end) - max(a_start, b_start))
    union = (a_end - a_start) + (b_end - b_start) - inter
    return inter / union if union > 0 else 0.0


def best_match(start: float, end: float, items: list[dict], thresh: float = 0.5) -> Optional[dict]:
    best, best_iou = None, thresh
    for it in items:
        s = iou(start, end, float(it.get("start", 0)), float(it.get("end", 0)))
        if s >= best_iou:
            best, best_iou = it, s
    return best

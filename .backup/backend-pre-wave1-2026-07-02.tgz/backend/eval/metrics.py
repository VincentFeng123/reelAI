"""Metrics (spec §14).

Label-free metrics (need only the predicted clips + units + sentences): the headline
comprehension rate (the clip-only judge), ends-on-period, unresolved-reference, grounding.
Gold-based metrics (need a golden file): role accuracy, anchor recall.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..pipeline.assemble.validate import judge_clip
from .golden import best_match, iou


@dataclass
class Report:
    video_id: str
    n_clips: int
    metrics: dict = field(default_factory=dict)


def _clip_text(spec: dict, sentences) -> str:
    i0 = spec.get("sentence_start_idx", 0)
    i1 = spec.get("sentence_end_idx", i0)
    i0 = max(0, min(i0, len(sentences) - 1))
    i1 = max(i0, min(i1, len(sentences) - 1))
    return " ".join((sentences[i].text or "") for i in range(i0, i1 + 1)).strip()


# ── label-free ───────────────────────────────────────────────────────────────
def comprehension(specs, sentences, adapter, topic, threshold=0.7) -> tuple[float, float, int, int]:
    """(mean judge score, fraction ≥ threshold, n_judged, n_error). Clip-only — the headline.
    Error verdicts (judge outage) are EXCLUDED from mean/rate so outages can never inflate
    comprehension; the caller reports them via judge_error_rate."""
    if not specs:
        return 0.0, 0.0, 0, 0
    scores, ok, n_error = [], 0, 0
    for s in specs:
        v = judge_clip(_clip_text(s, sentences), s.get("role", ""), adapter,
                       visual_summary="", topic=topic, context_card=s.get("context_card", ""))
        if v.error:
            n_error += 1
            continue
        scores.append(v.score)
        ok += 1 if v.score >= threshold else 0
    if not scores:
        return 0.0, 0.0, 0, n_error
    return sum(scores) / len(scores), ok / len(scores), len(scores), n_error


def ends_on_period_rate(specs, sentences) -> float:
    if not specs:
        return 0.0
    good = 0
    for s in specs:
        es = next((x for x in sentences if abs(x.end - s["end"]) < 0.3), None)
        good += 1 if (es and es.ends_with_period) else 0
    return good / len(specs)


def unresolved_reference_rate(specs, units_by_id) -> float:
    """Fraction of clips assuming a required concept neither introduced in-clip nor carded."""
    if not specs:
        return 0.0
    bad = 0
    for s in specs:
        units = [units_by_id[u] for u in s.get("unit_ids", []) if u in units_by_id]
        introduced = set().union(*[set(u.concepts_introduced) for u in units]) if units else set()
        required = set().union(*[set(u.concepts_required) for u in units]) if units else set()
        card = (s.get("context_card", "") or "").lower()
        missing = [c for c in (required - introduced) if c and c not in card]
        bad += 1 if missing else 0
    return bad / len(specs)


def grounding_ok_rate(specs) -> float:
    """Fraction of non-empty context cards (empty == omitted-not-hallucinated is fine)."""
    carded = [s for s in specs if s.get("context_card")]
    return len(carded) / len(specs) if specs else 0.0


def grounding_precision(specs, units_by_id) -> float:
    """Fraction of context-card SENTENCES entailed by one of the clip's own source units
    (anchor + referential). Independently re-verifies the card generator's grounding guarantee
    — vs. grounding_ok_rate/carded_rate which only measure card presence. NaN when no cards."""
    import re

    from ..pipeline.assemble.context_card import _grounded
    total, ok = 0, 0
    for s in specs:
        card = (s.get("context_card") or "").strip()
        if not card:
            continue
        ids = [s.get("anchor_id", "")] + [uid for uid, _rel in s.get("referential", [])]
        allowed = [units_by_id[u] for u in ids if u in units_by_id]
        if not allowed:
            continue
        for sent in (p.strip() for p in re.split(r"(?<=[.!?])\s+", card) if p.strip()):
            total += 1
            ok += 1 if any(_grounded(sent, u) for u in allowed) else 0
    return ok / total if total else float("nan")


# ── contract / prerequisite / visual / sequence (spec §14 additions) ─────────
_PROBLEM_ANCHORS = frozenset({"result", "solution", "derivation", "worked_example", "calculation",
                              "implementation", "debugging_step", "cooking_action"})


def _clip_units(spec, units_by_id):
    return [units_by_id[u] for u in spec.get("unit_ids", []) if u in units_by_id]


def _required_satisfied(spec, units_by_id, adapter) -> bool:
    """Every 'required' contract element for the clip's anchor role is covered by a clip unit's role."""
    c = adapter.contract_for(spec.get("role", "")) if adapter else None
    if not c:
        return True                                        # no contract → vacuously complete
    roles = {u.role for u in _clip_units(spec, units_by_id)}
    return all(any(r in roles for r in el.roles) for el in c.elements if el.necessity == "required")


def context_complete_rate(specs, units_by_id, adapter) -> float:
    """Fraction of clips whose anchor-role contract has all required elements present in-clip."""
    if not specs:
        return 0.0
    return sum(1 for s in specs if _required_satisfied(s, units_by_id, adapter)) / len(specs)


def prerequisite_gap_rate(specs, units_by_id) -> float:
    """Fraction of clips assuming a concept not introduced in-clip, not carded, and not introduced
    by an EARLIER clip in the (chronological) sequence."""
    if not specs:
        return 0.0
    ordered = sorted(specs, key=lambda s: s.get("start", 0.0))
    introduced_so_far: set = set()
    bad = 0
    for s in ordered:
        units = _clip_units(s, units_by_id)
        intro = set().union(*[set(u.concepts_introduced) for u in units]) if units else set()
        req = set().union(*[set(u.concepts_required) for u in units]) if units else set()
        card = (s.get("context_card", "") or "").lower()
        gap = [c for c in req if c and c not in intro and c not in introduced_so_far and c not in card]
        bad += 1 if gap else 0
        introduced_so_far |= intro
    return bad / len(specs)


def worked_example_completeness(specs, units_by_id, adapter) -> float:
    """For problem-shaped anchors: required contract elements present AND in position order
    (before ≤ within ≤ after by first satisfying unit's start). NaN if no such anchors."""
    targets = [s for s in specs if s.get("role") in _PROBLEM_ANCHORS and adapter.contract_for(s.get("role", ""))]
    if not targets:
        return float("nan")
    pos_rank = {"before": 0, "within": 1, "after": 2}
    ok = 0
    for s in targets:
        c = adapter.contract_for(s["role"])
        units = _clip_units(s, units_by_id)
        seq, complete = [], True
        for el in c.elements:
            if el.necessity != "required":
                continue
            starts = [u.start for u in units if u.role in el.roles]
            if not starts:
                complete = False
                break
            seq.append((pos_rank.get(el.position, 1), min(starts)))
        if complete:
            # every lower-position element must start no later than every higher-position one
            # (compare ALL cross-band pairs, not just adjacent — a same-position plateau, e.g. two
            # 'within' elements, would otherwise skip the before≤after check).
            complete = all(seq[i][1] <= seq[j][1] + 1e-6
                           for i in range(len(seq)) for j in range(len(seq)) if seq[i][0] < seq[j][0])
        ok += 1 if complete else 0
    return ok / len(targets)


def visual_completeness(specs, units_by_id) -> float:
    """Fraction of clips whose declared visual_dependencies are ALL linked to a real on-screen
    event. NaN when no clip references a visual (transcript-only / no perception)."""
    relevant, ok = 0, 0
    for s in specs:
        deps = [d for u in _clip_units(s, units_by_id) for d in u.visual_dependencies]
        if not deps:
            continue
        relevant += 1
        ok += 1 if all(d.visual_event_id for d in deps) else 0
    return ok / relevant if relevant else float("nan")


def sequence_coherence(specs, units_by_id) -> float:
    """Fraction of clips (chronological) with NO forward reference: they don't require a concept
    whose earliest introducer is a LATER clip, unless it's introduced in-clip or carded."""
    if not specs:
        return 0.0
    ordered = sorted(specs, key=lambda s: s.get("start", 0.0))
    per_clip, intro_idx = [], {}
    for i, s in enumerate(ordered):
        units = _clip_units(s, units_by_id)
        intro = set().union(*[set(u.concepts_introduced) for u in units]) if units else set()
        req = set().union(*[set(u.concepts_required) for u in units]) if units else set()
        per_clip.append((intro, req, (s.get("context_card", "") or "").lower()))
        for c in intro:
            intro_idx.setdefault(c, i)                      # earliest introducer index
    ok = 0
    for i, (intro, req, card) in enumerate(per_clip):
        fwd = [c for c in req if c and c not in intro and c not in card and intro_idx.get(c, -1) > i]
        ok += 1 if not fwd else 0
    return ok / len(ordered)


def judge_failures(specs, sentences, adapter, topic):
    """Per-clip judge verdicts for --verbose: list of (role, score, [failure kinds], error)."""
    out = []
    for s in specs:
        v = judge_clip(_clip_text(s, sentences), s.get("role", ""), adapter,
                       visual_summary=s.get("visual_summary", ""), topic=topic,
                       context_card=s.get("context_card", ""))
        out.append((s.get("role", ""), round(v.score, 2), [f.kind for f in v.failure_reasons],
                    bool(v.error)))
    return out


# ── gold-based ───────────────────────────────────────────────────────────────
def role_accuracy(pred_units, gold_units) -> float:
    if not gold_units:
        return float("nan")
    matched, correct = 0, 0
    for gu in gold_units:
        pm = best_match(float(gu["start"]), float(gu["end"]),
                        [{"start": u.start, "end": u.end, "role": u.role} for u in pred_units])
        if pm:
            matched += 1
            correct += 1 if pm["role"] == gu.get("role") else 0
    return correct / matched if matched else float("nan")


def anchor_recall(gold_anchors, specs) -> float:
    if not gold_anchors:
        return float("nan")
    covered = 0
    for ga in gold_anchors:
        hit = any(iou(float(ga["start"]), float(ga["end"]), s["start"], s["end"]) >= 0.5 for s in specs)
        covered += 1 if hit else 0
    return covered / len(gold_anchors)


def boundary_error(gold_anchors, specs) -> float:
    """Mean boundary offset (seconds) of predicted clips vs their best-matching gold anchor:
    mean(|Δstart| + |Δend|) over clips that match a gold span (IoU≥0.5). NaN when nothing matches."""
    if not gold_anchors or not specs:
        return float("nan")
    gold_items = [{"start": float(g["start"]), "end": float(g["end"])} for g in gold_anchors]
    errs = []
    for s in specs:
        m = best_match(float(s["start"]), float(s["end"]), gold_items)
        if m:
            errs.append(abs(float(s["start"]) - m["start"]) + abs(float(s["end"]) - m["end"]))
    return sum(errs) / len(errs) if errs else float("nan")
